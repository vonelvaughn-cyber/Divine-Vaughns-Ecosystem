// DV Coin Configuration - divinevaughnstoken.net
// Admin: Devaughn Parker (vonelvaughn@gmail.com)
// GitHub: vonelvaughn@cyber.github
// Philosophy: "This is value that remembers life. This is for people who build, not speculate."

import DOMAIN_CONFIG from './domain.config';

export const APP_CONFIG = {
  // Domain Settings (from domain.config.ts)
  domain: DOMAIN_CONFIG.primary,
  fullDomain: `https://${DOMAIN_CONFIG.primary}`,
  wwwDomain: `https://${DOMAIN_CONFIG.www}`,
  domainConfig: DOMAIN_CONFIG,
  
  // Admin Info
  admin: {
    name: 'Devaughn Parker',
    email: 'vonelvaughn@gmail.com',
    github: 'vonelvaughn@cyber.github',
    githubUsername: 'vonelvaughn',
    wallet: '0xBDc4DC1f855371F29F0449b206620BD0BD24aC0C' // Treasury/Admin wallet
  },
  
  // Smart Contract Addresses (Base Mainnet)
  contracts: {
    // Core DV Token
    dvToken: '0x804Ed08fd4f33570DF8d1b69E4FC2da12f14f8B6',
    
    // AIC (AI Catalyst) Token
    aicToken: '0x3B62b6b3958C128574b3dAd6cC94d41432617B60',
    
    // Tier-based Access Control
    dvTierGate: '0x44e6C229e054381eC831B483AB0475F3C062DB01',
    
    // DV Swap Router (0.3% fee to treasury)
    dvRouter: '0x463C776637632c7A1Bd8A89e11761625B1A9a17E',
    
    // DV/AIC Uniswap V3 Pool
    dvAicPool: '0xd183852247134036b07f5E1190977b291AaD6355',
    
    // DV/WETH Uniswap V3 Pool
    dvWethPool: '0xfb7188595FB6F627E3e4E54F7ECB3F7E3F3f9a29',
    
    // AI Engine (dynamic pricing, AIC burn)
    dvAiEngine: '0x00a02f49fFAeF61F94Daf9b0Bd50307392b4Ed2b',
    
    // Staking Vault (30-day lock, stDV3 rewards)
    dvStakingVault: '0x2cE5f8dbE858Df390A06EdA02a7B379818607546',
    
    // Staked DV Token (non-transferable)
    stDvToken: '0x55adc6f25a41a7Da59eA410d914340e96f602f1d',
    
    // Staked DV3 Token (90-day reward, non-transferable)
    stDv3Token: '0xd801Ca5972a3EdD3911282B7aD1A22EC88b00413',
    
    // Treasury (receives fees)
    treasury: '0xBDc4DC1f855371F29F0449b206620BD0BD24aC0C',
    
    // Uniswap V3 Router on Base
    uniswapV3Router: '0x2626664c2603336E57B271c5C0b26F421741e481'
  },
  
  // Network Configuration
  network: {
    name: 'Base Mainnet',
    chainId: 8453,
    rpcUrl: 'https://mainnet.base.org',
    explorer: 'https://basescan.org',
    currency: 'ETH',
    dvExplorer: 'https://basescan.org/token/0x804Ed08fd4f33570DF8d1b69E4FC2da12f14f8B6'
  },
  
  // Tier Requirements
  tiers: {
    0: { name: 'No Tier', minBalance: 0, features: [] },
    1: { 
      name: 'Bronze', 
      minBalance: 1, 
      features: ['market_access', 'basic_swap'],
      description: 'View crypto market data'
    },
    2: { 
      name: 'Silver', 
      minBalance: 100, 
      features: ['profile_creation', 'full_swap', 'content_creation'],
      description: 'Create profile, full swap access, content coins'
    },
    3: { 
      name: 'Gold', 
      minBalance: 1000, 
      features: ['storage_wallet', 'ai_chat', 'live_streaming'],
      description: 'Cold storage, AI chat, live streaming'
    },
    4: { 
      name: 'Platinum', 
      minBalance: 10000, 
      features: ['governance', 'priority_support', 'early_access'],
      description: 'Governance voting, priority support'
    }
  },
  
  // Feature Settings
  features: {
    // Cold Storage Wallet
    coldStorageAmount: 500, // 500 DV to create storage wallet
    
    // Market Access
    marketAccessThreshold: 1, // 1 DV minimum
    
    // AI Chat
    aiCostPerMessage: 0.001, // 0.001 AIC per message (target $1 USD)
    aiTargetUsdPrice: 1, // $1 USD target per message
    
    // Swap
    swapFeeBps: 30, // 0.30% fee
    
    // Staking
    stakingLockPeriod: 30 * 24 * 60 * 60, // 30 days in seconds
    stakingEarlyPenalty: 2000, // 20% early withdrawal penalty
    stakingRewardCycle: 90 * 24 * 60 * 60, // 90 days for stDV3 rewards
    
    // Content Coins
    contentCreatorShare: 90, // 90% to creator
    contentAppShare: 10, // 10% to platform
    
    // Session
    sessionTimeout: 30 * 24 * 60 * 60 * 1000, // 30 days
    
    // Multi-sig
    multiSigThreshold: 0.6, // 60% threshold
    deactivationGracePeriod: 7 * 24 * 60 * 60 * 1000 // 7 days
  },
  
  // Economic Safeguards (stDV3 Anti-Inflation)
  economics: {
    stDv3: {
      maxSupply: 10000000, // 10 million hard cap
      rewardRateBps: 250, // 2.5% per 90-day cycle
      halvingCycles: 4, // Halve every 4 cycles (1 year)
      minStakeForRewards: 100, // 100 DV minimum
      maxEmissionPerCycle: 100000 // 100k stDV3 per cycle max
    }
  },
  
  // Token Logos
  logos: {
    dv: '/logos/dv-logo.png',
    aic: '/logos/aic-logo.png',
    stdv: '/logos/stdv-logo.png',
    stdv3: '/logos/stdv3-logo.png'
  },
  
  // API Endpoints
  api: {
    base: 'https://divinevaughnstoken.net/api',
    ws: 'wss://divinevaughnstoken.net/ws'
  },
  
  // Social Links
  social: {
    github: 'https://github.com/vonelvaughn',
    twitter: 'https://twitter.com/divinevaughns',
    discord: 'https://discord.gg/divinevaughns'
  },
  
  // Metadata
  metadata: {
    title: 'Divine Vaughns - Memory Anchor for Human Contribution',
    description: 'A Web3 ecosystem that remembers life, contribution, and continuity. Built for builders, not speculators.',
    keywords: 'DV, Divine Vaughns, Web3, Staking, DeFi, Base, Ethereum',
    author: 'Devaughn Parker'
  }
};

export default APP_CONFIG;
