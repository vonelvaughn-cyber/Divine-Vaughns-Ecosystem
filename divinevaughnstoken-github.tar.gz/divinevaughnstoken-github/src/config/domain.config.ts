// Domain Forwarding Configuration
// divinevaughnstoken.net
// Admin: Devaughn Parker (vonelvaughn@gmail.com)

const DOMAIN_CONFIG = {
  // Primary Domain
  primary: 'divinevaughnstoken.net',
  www: 'www.divinevaughnstoken.net',
  
  // Redirect Rules
  redirects: {
    // Redirect HTTP to HTTPS
    forceSSL: true,
    
    // Redirect www to non-www (or vice versa)
    wwwToNonWww: true,
    
    // Redirect old paths
    oldPaths: {
      '/old-app': '/app',
      '/wallet': '/storage',
      '/staking': '/stake'
    }
  },
  
  // DNS Records (configured at your registrar)
  dns: {
    A: ['@', 'www'],
    TXT: [
      'v=spf1 include:_spf.google.com ~all',
      'divine-vaughns-token-verification=ACTIVE'
    ],
    CNAME: ['app', 'api']
  },
  
  // SSL Certificate
  ssl: {
    provider: 'letsencrypt',
    autoRenew: true,
    wildcard: false
  }
};

// Export for use in app
export default DOMAIN_CONFIG;
