import { useReadContract } from 'wagmi';
import { useAccount } from 'wagmi';
import { DV_TIER_GATE_ADDRESS, DV_TIER_GATE_ABI, DV_TOKEN_ABI, DV_TOKEN_ADDRESS, CONSTANTS, formatDVAmount, getTierName, getTierColor } from '@/lib/web3';
import { useState, useEffect, useCallback } from 'react';

// Hook to get user's tier from DVTierGate contract
export function useDVTier() {
  const { address, isConnected } = useAccount();
  
  // Read tier from DVTierGate contract
  const { data: tier, isLoading: tierLoading, refetch: refetchTier } = useReadContract({
    address: DV_TIER_GATE_ADDRESS as `0x${string}`,
    abi: DV_TIER_GATE_ABI,
    functionName: 'getTier',
    args: address ? [address] : undefined,
    query: {
      enabled: isConnected && !!address,
    },
  });

  // Read DV token balance
  const { data: balance, isLoading: balanceLoading, refetch: refetchBalance } = useReadContract({
    address: DV_TOKEN_ADDRESS as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: {
      enabled: isConnected && !!address,
    },
  });

  const userTier = tier ?? 0;
  const userBalance = balance ?? 0n;
  
  // Market access requires Tier 1+ (1+ DV) - view market data
  const hasMarketAccess = userTier >= 1;
  
  // Profile access requires Tier 2+ (100+ DV) - Silver
  const hasProfileAccess = userTier >= 2;
  
  // DV Swap requires Tier 2+ (100+ DV) - Silver
  const hasSwapAccess = userTier >= 2;
  
  // Storage Wallet requires Tier 3+ (1,000+ DV) - Gold
  const hasStorageAccess = userTier >= 3;
  
  // Bot access requires Tier 3+ (1,000+ DV) - Gold
  const hasBotAccess = userTier >= 3;
  
  // Premium/Admin access requires Tier 4 (10,000+ DV) - Platinum
  const hasPremiumAccess = userTier >= 4;

  return {
    tier: userTier,
    tierName: getTierName(userTier),
    tierColor: getTierColor(userTier),
    balance: userBalance,
    formattedBalance: formatDVAmount(userBalance),
    hasMarketAccess,
    hasProfileAccess,
    hasSwapAccess,
    hasStorageAccess,
    hasBotAccess,
    hasPremiumAccess,
    isLoading: tierLoading || balanceLoading,
    refetch: async () => {
      await refetchTier();
      await refetchBalance();
    },
  };
}

// Hook for bot access management
export function useBotAccess() {
  const { isConnected } = useAccount();
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [lastPurchaseTime, setLastPurchaseTime] = useState<number | null>(null);
  const [purchaseCount, setPurchaseCount] = useState(0);

  // Check if user is within cooldown period
  const isInCooldown = useCallback((): { inCooldown: boolean; timeRemaining: number; canPurchase: boolean } => {
    if (!lastPurchaseTime) {
      return { inCooldown: false, timeRemaining: 0, canPurchase: true };
    }

    const cooldownEnd = lastPurchaseTime + CONSTANTS.BOT_COOLDOWN_PERIOD * 1000;
    const timeRemaining = Math.max(0, cooldownEnd - Date.now());
    const inCooldown = timeRemaining > 0;

    // Abuse detection: if more than 3 purchases in cooldown period
    const isAbusing = purchaseCount >= 3 && inCooldown;

    return {
      inCooldown,
      timeRemaining,
      canPurchase: !inCooldown && !isAbusing,
    };
  }, [lastPurchaseTime, purchaseCount]);

  // Purchase bot access with 1000 DV
  const purchaseBotAccess = useCallback(async () => {
    if (!isConnected) {
      throw new Error('Wallet not connected');
    }

    setIsPurchasing(true);
    try {
      // Simulate purchase - in production this would call the smart contract
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setLastPurchaseTime(Date.now());
      setPurchaseCount(prev => prev + 1);
      
      return true;
    } catch (error) {
      console.error('Purchase error:', error);
      throw error;
    } finally {
      setIsPurchasing(false);
    }
  }, [isConnected]);

  // Reset abuse counter after cooldown
  useEffect(() => {
    if (!lastPurchaseTime) return;

    const cooldownEnd = lastPurchaseTime + CONSTANTS.BOT_COOLDOWN_PERIOD * 1000;
    const timeRemaining = Math.max(0, cooldownEnd - Date.now());

    if (timeRemaining === 0) {
      setPurchaseCount(0);
    }
  }, [lastPurchaseTime]);

  return {
    purchaseBotAccess,
    isPurchasing,
    isInCooldown,
    lastPurchaseTime,
    purchaseCount,
  };
}

// Hook for staking functionality
export function useStaking() {
  const { isConnected } = useAccount();
  const [isStaking, setIsStaking] = useState(false);

  // Stake DV tokens
  const stake = useCallback(async (_amount: bigint, _lockPeriod: number) => {
    if (!isConnected) {
      throw new Error('Wallet not connected');
    }

    setIsStaking(true);
    try {
      // Simulate staking - in production this would call the smart contract
      await new Promise(resolve => setTimeout(resolve, 2000));
    } finally {
      setIsStaking(false);
    }
  }, [isConnected]);

  // Unstake DV tokens
  const unstake = useCallback(async (_amount: bigint) => {
    if (!isConnected) {
      throw new Error('Wallet not connected');
    }

    // Simulate unstaking
    await new Promise(resolve => setTimeout(resolve, 2000));
  }, [isConnected]);

  // Calculate potential rewards
  const calculateRewards = useCallback((amount: bigint, lockPeriod: number): bigint => {
    let rate: number;
    switch (lockPeriod) {
      case CONSTANTS.STAKING_PERIODS.THREE_MONTHS:
        rate = CONSTANTS.REWARD_RATES.THREE_MONTHS;
        break;
      case CONSTANTS.STAKING_PERIODS.SIX_MONTHS:
        rate = CONSTANTS.REWARD_RATES.SIX_MONTHS;
        break;
      case CONSTANTS.STAKING_PERIODS.ONE_YEAR:
        rate = CONSTANTS.REWARD_RATES.ONE_YEAR;
        break;
      default:
        rate = 0;
    }

    const timeInYears = BigInt(lockPeriod) / BigInt(365 * 24 * 60 * 60);
    return (amount * BigInt(rate) * timeInYears) / 10000n;
  }, []);

  return {
    stake,
    unstake,
    calculateRewards,
    isStaking,
  };
}

// Hook for dynamic pricing (maintain $1 = 1000 DV)
export function useDynamicPricing() {
  const [dvPriceUSD, setDvPriceUSD] = useState<number>(CONSTANTS.DV_PRICE_USD);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch current DV price from DEX/API
  useEffect(() => {
    const fetchPrice = async () => {
      setIsLoading(true);
      try {
        // In production, this would fetch from DEX (e.g., Uniswap on Base)
        setDvPriceUSD(CONSTANTS.DV_PRICE_USD);
      } catch (error) {
        console.error('Error fetching DV price:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPrice();
    const interval = setInterval(fetchPrice, 60000);
    return () => clearInterval(interval);
  }, []);

  // Calculate DV amount needed for target USD amount
  const calculateDVForUSD = useCallback((usdAmount: number): bigint => {
    const dvAmount = Math.ceil(usdAmount / dvPriceUSD);
    return BigInt(dvAmount) * 10n ** 18n;
  }, [dvPriceUSD]);

  // Calculate USD value of DV amount
  const calculateUSDForDV = useCallback((dvAmount: bigint): number => {
    const dvWhole = Number(dvAmount) / 10 ** 18;
    return dvWhole * dvPriceUSD;
  }, [dvPriceUSD]);

  return {
    dvPriceUSD,
    dvAmountForOneDollar: Math.ceil(1 / dvPriceUSD),
    isLoading,
    calculateDVForUSD,
    calculateUSDForDV,
  };
}

// Hook for staked DV balance (mock for now)
export function useStakedDV() {
  const stakedBalance = 2000n * 10n ** 18n;
  const stakingStartTime = Date.now() - 30 * 24 * 60 * 60 * 1000;

  return {
    stakedBalance,
    formattedStakedBalance: formatDVAmount(stakedBalance),
    stakingStartTime,
    isLoading: false,
    refetch: () => {},
  };
}
