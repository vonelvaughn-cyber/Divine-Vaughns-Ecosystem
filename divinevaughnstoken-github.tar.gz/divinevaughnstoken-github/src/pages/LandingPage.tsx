import { useState, useEffect } from 'react';
import { HeroSection } from '@/sections/HeroSection';
import { PhilosophySection } from '@/sections/PhilosophySection';
import { BridgeSection } from '@/sections/BridgeSection';
import { BuildersManifesto } from '@/sections/BuildersManifesto';
import { Web3Platform } from '@/sections/Web3Platform';
import { Button } from '@/components/ui/button';
import { DVLogo } from '@/components/TokenLogos';
import { ArrowRight, ExternalLink, Github, MessageCircle, ChevronLeft } from 'lucide-react';

export function LandingPage() {
  const [showApp, setShowApp] = useState(false);

  // Listen for launchApp event from BuildersManifesto
  useEffect(() => {
    const handleLaunchApp = () => setShowApp(true);
    window.addEventListener('launchApp', handleLaunchApp);
    return () => window.removeEventListener('launchApp', handleLaunchApp);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (showApp) {
    return (
      <div className="min-h-screen bg-[#0a0a0f]">
        {/* App Navigation */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-md border-b border-white/5">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <button 
              onClick={() => setShowApp(false)}
              className="flex items-center gap-2 text-white/60 hover:text-white transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
            <div className="flex items-center gap-3">
              <DVLogo size="sm" />
              <span className="text-white font-semibold">Divine Vaughns</span>
            </div>
            <div className="w-24" /> {/* Spacer for balance */}
          </div>
        </nav>
        
        {/* App Content */}
        <div className="pt-20">
          <Web3Platform />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0f]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DVLogo size="sm" />
            <span className="text-white font-semibold">Divine Vaughns</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => scrollToSection('philosophy')}
              className="text-white/60 hover:text-white transition-colors"
            >
              Philosophy
            </button>
            <button 
              onClick={() => scrollToSection('bridge')}
              className="text-white/60 hover:text-white transition-colors"
            >
              Bridge
            </button>
            <button 
              onClick={() => scrollToSection('builders')}
              className="text-white/60 hover:text-white transition-colors"
            >
              Builders
            </button>
          </div>
          <Button
            size="sm"
            onClick={() => setShowApp(true)}
            className="bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-medium hover:from-amber-400 hover:to-yellow-500"
          >
            Launch App
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        <HeroSection onLaunchApp={() => setShowApp(true)} />
        
        <div id="philosophy">
          <PhilosophySection />
        </div>
        
        <div id="bridge">
          <BridgeSection />
        </div>
        
        <div id="builders">
          <BuildersManifesto />
        </div>
      </main>

      {/* Footer */}
      <footer className="py-16 px-6 border-t border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <DVLogo size="md" />
                <span className="text-white font-semibold text-lg">Divine Vaughns</span>
              </div>
              <p className="text-white/50 max-w-md mb-4">
                A memory anchor for human effort that restores life, creativity, 
                and balance. Built for builders, not speculators.
              </p>
              <div className="flex gap-4">
                <a 
                  href="https://github.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <Github className="w-5 h-5 text-white/60" />
                </a>
                <a 
                  href="https://t.me" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <MessageCircle className="w-5 h-5 text-white/60" />
                </a>
                <a 
                  href="https://docs.divinevaughnstoken.net" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <ExternalLink className="w-5 h-5 text-white/60" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-medium mb-4">Platform</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => setShowApp(true)}
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    AI Chat
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowApp(true)}
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    Content Feed
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowApp(true)}
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    Live Streaming
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowApp(true)}
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    DV Swap
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-medium mb-4">Resources</h4>
              <ul className="space-y-2">
                <li>
                  <a 
                    href="#" 
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    Documentation
                  </a>
                </li>
                <li>
                  <a 
                    href="#" 
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    Whitepaper
                  </a>
                </li>
                <li>
                  <a 
                    href="#" 
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    Contract Addresses
                  </a>
                </li>
                <li>
                  <a 
                    href="#" 
                    className="text-white/50 hover:text-white transition-colors"
                  >
                    Bridge
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/40 text-sm">
              © 2026 Divine Vaughns. A memory anchor for builders.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-white/40 hover:text-white transition-colors">Privacy</a>
              <a href="#" className="text-white/40 hover:text-white transition-colors">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
