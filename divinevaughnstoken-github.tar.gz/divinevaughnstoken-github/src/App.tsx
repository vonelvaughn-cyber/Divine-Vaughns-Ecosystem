import { useState, useEffect } from 'react';
import { APP_CONFIG } from './config/app.config';
import { permanentStorage } from './services/permanentStorage';
import { txManager } from './services/transactionManager';
import { Web3Platform } from './sections/Web3Platform';
import { MultiWalletConnect } from './components/MultiWalletConnect';
import { User, Shield, Sparkles, ExternalLink } from 'lucide-react';
import './App.css';

function App() {
  const [user, setUser] = useState<{
    email: string;
    walletAddress?: string;
    balance?: number;
    hasAccess?: boolean;
    profile?: any;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('home');

  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    try {
      await txManager.initialize();
      const session = await recoverSession();
      if (session) {
        const profile = await permanentStorage.getProfile();
        setUser({ email: session.email, profile });
      }
    } catch (err) {
      console.error('Init error:', err);
    }
    setLoading(false);
  };

  const recoverSession = async () => {
    const saved = localStorage.getItem('dv_session');
    if (!saved) return null;
    try {
      const { email } = JSON.parse(saved);
      const profile = await permanentStorage.getProfile(email);
      if (profile) {
        permanentStorage.setUserContext(email, profile.walletAddress);
        return { email };
      }
    } catch {
      localStorage.removeItem('dv_session');
    }
    return null;
  };

  const connect = async (email: string) => {
    setLoading(true);
    try {
      const { address, balance, hasAccess } = await txManager.connectWallet();
      permanentStorage.setUserContext(email, address);
      
      let profile = await permanentStorage.getProfile();
      if (!profile) {
        profile = await permanentStorage.createProfile({ displayName: email.split('@')[0] });
      }
      
      setUser({ email, walletAddress: address, balance, hasAccess, profile });
    } catch (err: any) {
      alert(err.message);
    }
    setLoading(false);
  };

  if (loading) return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center">
      <div className="text-center">
        <Sparkles className="w-12 h-12 text-amber-400 mx-auto mb-4 animate-pulse" />
        <p className="text-white text-lg">Loading DV Coin...</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800">
      <header className="border-b border-white/10 bg-slate-900/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center">
              <span className="text-black font-bold text-lg">DV</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">DV Coin</h1>
              <span className="text-xs text-amber-400">{APP_CONFIG.domain}</span>
            </div>
          </div>
          
          {user && (
            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-400 flex items-center gap-2">
                <User className="w-4 h-4" />
                {user.email}
              </span>
              <span className="text-sm text-emerald-400">
                {user.balance?.toFixed(2)} DV
              </span>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {!user ? (
          <Login onConnect={connect} />
        ) : (
          <Dashboard user={user} setView={setView} view={view} />
        )}
      </main>

      <footer className="border-t border-white/10 mt-auto">
        <div className="max-w-7xl mx-auto px-6 py-6 text-center">
          <p className="text-slate-400 text-sm">
            © 2024 DV Coin | {APP_CONFIG.admin.name}
          </p>
          <p className="text-slate-500 text-xs mt-1">
            {APP_CONFIG.domain} | {APP_CONFIG.admin.email}
          </p>
          <div className="flex justify-center gap-4 mt-3">
            <a 
              href={`https://github.com/${APP_CONFIG.admin.githubUsername}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-500 hover:text-white text-xs flex items-center gap-1"
            >
              <ExternalLink className="w-3 h-3" />
              GitHub
            </a>
            <a 
              href={APP_CONFIG.network.explorer}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-500 hover:text-white text-xs flex items-center gap-1"
            >
              <ExternalLink className="w-3 h-3" />
              BaseScan
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

const Login = ({ onConnect }: { onConnect: (email: string) => void }) => {
  const [email, setEmail] = useState('');
  
  return (
    <div className="max-w-md mx-auto mt-20">
      <div className="bg-slate-800/50 border border-white/10 rounded-2xl p-8 text-center">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center mx-auto mb-6">
          <span className="text-4xl">✨</span>
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Welcome to DV Coin</h2>
        <p className="text-slate-400 mb-6">Permanent profiles on {APP_CONFIG.domain}</p>
        
        <div className="space-y-4">
          <input 
            type="email" 
            value={email} 
            onChange={e => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
          
          <div className="flex justify-center">
            <MultiWalletConnect onConnect={() => email && onConnect(email)} />
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-white/10">
          <p className="text-xs text-slate-500">
            Supports MetaMask, WalletConnect, Coinbase & more
          </p>
        </div>
      </div>
    </div>
  );
};

const Dashboard = ({ user, view, setView }: { 
  user: any; 
  view: string; 
  setView: (v: string) => void;
}) => {
  const [coldWallets, setColdWallets] = useState<any[]>([]);
  const [creating, setCreating] = useState(false);
  
  useEffect(() => {
    loadWallets();
  }, []);

  const loadWallets = async () => {
    const wallets = await permanentStorage.getColdStorageWallets();
    setColdWallets(wallets);
  };

  const createCold = async () => {
    if (creating) return;
    setCreating(true);
    try {
      await txManager.stakeDV(500);
      const wallet = await permanentStorage.createColdStorage({
        amount: 500,
        label: 'My Cold Storage'
      });
      setColdWallets([...coldWallets, wallet]);
    } catch (err: any) {
      alert('Failed to create cold storage: ' + err.message);
    }
    setCreating(false);
  };

  return (
    <div className="space-y-6">
      {/* User Info Card */}
      <div className="bg-slate-800/50 border border-white/10 rounded-2xl p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">{user.profile?.displayName}</h3>
            <p className="text-sm text-slate-400">{user.email}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-slate-700/50 rounded-xl p-4">
            <p className="text-xs text-slate-400 mb-1">Wallet</p>
            <p className="text-sm text-white font-mono">
              {user.walletAddress?.slice(0, 10)}...{user.walletAddress?.slice(-4)}
            </p>
          </div>
          <div className="bg-slate-700/50 rounded-xl p-4">
            <p className="text-xs text-slate-400 mb-1">Balance</p>
            <p className="text-lg text-emerald-400 font-semibold">
              {user.balance?.toFixed(4)} DV
            </p>
          </div>
          <div className="bg-slate-700/50 rounded-xl p-4">
            <p className="text-xs text-slate-400 mb-1">Market Access</p>
            <p className="text-lg">
              {user.hasAccess ? (
                <span className="text-emerald-400">✅ Enabled</span>
              ) : (
                <span className="text-amber-400">❌ Need 1 DV</span>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex gap-2">
        <button 
          onClick={() => setView('profile')} 
          className={`px-4 py-2 rounded-xl font-medium transition-all ${
            view === 'profile' 
              ? 'bg-amber-500 text-black' 
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          Profile
        </button>
        <button 
          onClick={() => setView('storage')} 
          className={`px-4 py-2 rounded-xl font-medium transition-all flex items-center gap-2 ${
            view === 'storage' 
              ? 'bg-amber-500 text-black' 
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          <Shield className="w-4 h-4" />
          Cold Storage ({coldWallets.length})
        </button>
        <button 
          onClick={() => setView('platform')} 
          className={`px-4 py-2 rounded-xl font-medium transition-all ${
            view === 'platform' 
              ? 'bg-amber-500 text-black' 
              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
          }`}
        >
          Full Platform
        </button>
      </nav>
      
      {/* Views */}
      {view === 'profile' && (
        <div className="bg-slate-800/50 border border-white/10 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Profile Details</h3>
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">Display Name</span>
              <span className="text-white">{user.profile?.displayName}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">Email</span>
              <span className="text-white">{user.email}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">Wallet Address</span>
              <span className="text-white font-mono text-sm">{user.walletAddress}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">DV Balance</span>
              <span className="text-emerald-400">{user.balance?.toFixed(4)} DV</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-400">Tier Status</span>
              <span className={user.hasAccess ? 'text-emerald-400' : 'text-amber-400'}>
                {user.hasAccess ? 'Bronze+' : 'No Tier'}
              </span>
            </div>
          </div>
        </div>
      )}
      
      {view === 'storage' && (
        <div className="bg-slate-800/50 border border-white/10 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Cold Storage Wallets</h3>
            <span className="text-sm text-slate-400">500 DV required per wallet</span>
          </div>
          
          {coldWallets.length === 0 ? (
            <p className="text-slate-500 text-center py-8">No cold storage wallets yet</p>
          ) : (
            <div className="space-y-3 mb-6">
              {coldWallets.map(w => (
                <div key={w.id} className="bg-slate-700/50 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">{w.label}</p>
                    <p className="text-sm text-slate-400">
                      Created {new Date(w.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-emerald-400 font-semibold">{w.amount} DV</p>
                    <span className={`text-xs px-2 py-1 rounded ${
                      w.status === 'active' 
                        ? 'bg-emerald-500/20 text-emerald-400' 
                        : 'bg-slate-600 text-slate-400'
                    }`}>
                      {w.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <button 
            onClick={createCold}
            disabled={creating || (user.balance || 0) < 500}
            className="w-full py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold rounded-xl hover:from-emerald-400 hover:to-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            {creating ? 'Creating...' : 'Create Cold Storage (500 DV)'}
          </button>
        </div>
      )}

      {view === 'platform' && <Web3Platform />}
    </div>
  );
};

export default App;
