import { ethers } from 'ethers';
import { APP_CONFIG } from '../config/app.config';
import { permanentStorage } from './permanentStorage';

declare global {
  interface Window {
    ethereum?: any;
  }
}

const DV_TOKEN_ABI = [
  "function stake(uint256 amount) external",
  "function unstake(uint256 amount) external",
  "function balanceOf(address account) external view returns (uint256)",
  "function approve(address spender, uint256 amount) external returns (bool)",
  "function allowance(address owner, address spender) external view returns (uint256)"
];

const SWAP_ABI = [
  "function executeSwap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut) external payable returns (uint256)"
];

const STAKING_VAULT_ABI = [
  "function stake(uint256 amount) external",
  "function unstake(uint256 amount) external",
  "function claim3MonthReward() external",
  "function users(address) external view returns (uint256 staked, uint256 depositTime, uint256 lastClaimTime)",
  "function LOCK_PERIOD() external view returns (uint256)",
  "function REWARD_CYCLE() external view returns (uint256)",
  "function EARLY_PENALTY() external view returns (uint256)"
];

class TransactionManager {
  private provider: ethers.JsonRpcProvider | ethers.BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;
  private contracts: Record<string, any> = {};

  constructor() {
    this.initialize();
  }

  async initialize() {
    this.provider = new ethers.JsonRpcProvider(APP_CONFIG.network.rpcUrl);
    this.contracts = {
      dvToken: new ethers.Contract(APP_CONFIG.contracts.dvToken, DV_TOKEN_ABI, this.provider) as ethers.Contract,
      swap: new ethers.Contract(APP_CONFIG.contracts.dvRouter, SWAP_ABI, this.provider) as ethers.Contract,
      stakingVault: new ethers.Contract(APP_CONFIG.contracts.dvStakingVault, STAKING_VAULT_ABI, this.provider) as ethers.Contract
    };
  }

  async connectWallet(): Promise<{ address: string; balance: number; hasAccess: boolean }> {
    if (!window.ethereum) throw new Error('Install MetaMask');
    
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    
    // Switch to Base
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${APP_CONFIG.network.chainId.toString(16)}` }]
      });
    } catch {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: `0x${APP_CONFIG.network.chainId.toString(16)}`,
          chainName: APP_CONFIG.network.name,
          nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
          rpcUrls: [APP_CONFIG.network.rpcUrl],
          blockExplorerUrls: [APP_CONFIG.network.explorer]
        }]
      });
    }

    this.provider = new ethers.BrowserProvider(window.ethereum);
    this.signer = await this.provider.getSigner();
    const address = await this.signer.getAddress();

    // Connect contracts to signer
    if (this.contracts.dvToken) {
      this.contracts.dvToken = this.contracts.dvToken.connect(this.signer);
    }
    if (this.contracts.swap) {
      this.contracts.swap = this.contracts.swap.connect(this.signer);
    }
    if (this.contracts.stakingVault) {
      this.contracts.stakingVault = this.contracts.stakingVault.connect(this.signer);
    }

    const balance = await this.getDVBalance(address);
    
    // Set user context in permanent storage
    permanentStorage.setUserContext('user@dv.app', address);
    
    return { address, balance, hasAccess: balance >= APP_CONFIG.features.marketAccessThreshold };
  }

  async stakeDV(amount: number): Promise<{ success: boolean; hash: string }> {
    if (!this.signer || !this.contracts.stakingVault) {
      throw new Error('Wallet not connected');
    }

    const tx = await this.contracts.stakingVault.stake(ethers.parseUnits(amount.toString(), 18));
    
    await permanentStorage.recordTransaction({
      type: 'stake',
      amount,
      token: 'DV',
      txHash: tx.hash,
      status: 'pending'
    });

    await tx.wait();
    
    await permanentStorage.recordTransaction({
      type: 'stake',
      amount,
      token: 'DV',
      txHash: tx.hash,
      status: 'confirmed'
    });

    return { success: true, hash: tx.hash };
  }

  async unstakeDV(amount: number): Promise<{ success: boolean; hash: string }> {
    if (!this.signer || !this.contracts.stakingVault) {
      throw new Error('Wallet not connected');
    }

    const tx = await this.contracts.stakingVault.unstake(ethers.parseUnits(amount.toString(), 18));
    
    await permanentStorage.recordTransaction({
      type: 'unstake',
      amount,
      token: 'DV',
      txHash: tx.hash,
      status: 'pending'
    });

    await tx.wait();
    
    await permanentStorage.recordTransaction({
      type: 'unstake',
      amount,
      token: 'DV',
      txHash: tx.hash,
      status: 'confirmed'
    });

    return { success: true, hash: tx.hash };
  }

  async claimStakingReward(): Promise<{ success: boolean; hash: string }> {
    if (!this.signer || !this.contracts.stakingVault) {
      throw new Error('Wallet not connected');
    }

    const tx = await this.contracts.stakingVault.claim3MonthReward();
    
    await permanentStorage.recordTransaction({
      type: 'claim',
      amount: 0,
      token: 'stDV3',
      txHash: tx.hash,
      status: 'pending'
    });

    await tx.wait();
    
    await permanentStorage.recordTransaction({
      type: 'claim',
      amount: 0,
      token: 'stDV3',
      txHash: tx.hash,
      status: 'confirmed'
    });

    return { success: true, hash: tx.hash };
  }

  async executeSwap(tokenIn: string, tokenOut: string, amountIn: number): Promise<{ success: boolean; hash: string; receipt?: ethers.TransactionReceipt }> {
    if (!this.signer || !this.contracts.swap) {
      throw new Error('Wallet not connected');
    }

    const isETH = tokenIn === ethers.ZeroAddress;
    const tx = await this.contracts.swap.executeSwap(
      tokenIn, 
      tokenOut, 
      ethers.parseUnits(amountIn.toString(), 18),
      0, // minAmountOut (should use slippage in production)
      { value: isETH ? ethers.parseUnits(amountIn.toString(), 18) : 0 }
    );

    await permanentStorage.recordTransaction({
      type: 'swap',
      amount: amountIn,
      token: 'DV',
      txHash: tx.hash,
      status: 'pending'
    });

    const receipt = await tx.wait();
    
    await permanentStorage.recordTransaction({
      type: 'swap',
      amount: amountIn,
      token: 'DV',
      txHash: tx.hash,
      status: 'confirmed'
    });

    return { success: true, hash: tx.hash, receipt };
  }

  async approveToken(tokenAddress: string, spender: string, amount: number): Promise<{ success: boolean; hash: string }> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }

    const tokenContract = new ethers.Contract(tokenAddress, DV_TOKEN_ABI, this.signer);
    const tx = await tokenContract.approve(spender, ethers.parseUnits(amount.toString(), 18));
    
    await tx.wait();
    
    return { success: true, hash: tx.hash };
  }

  async getDVBalance(address: string): Promise<number> {
    if (!this.contracts.dvToken) {
      throw new Error('Contract not initialized');
    }
    const balance = await this.contracts.dvToken.balanceOf(address);
    return parseFloat(ethers.formatUnits(balance, 18));
  }

  async getStakingInfo(address: string): Promise<{ staked: number; depositTime: number; lastClaimTime: number }> {
    if (!this.contracts.stakingVault) {
      throw new Error('Contract not initialized');
    }
    const info = await this.contracts.stakingVault.users(address);
    return {
      staked: parseFloat(ethers.formatUnits(info.staked, 18)),
      depositTime: Number(info.depositTime) * 1000, // Convert to milliseconds
      lastClaimTime: Number(info.lastClaimTime) * 1000
    };
  }

  async getAllowance(tokenAddress: string, owner: string, spender: string): Promise<number> {
    if (!this.provider) {
      throw new Error('Provider not initialized');
    }
    const tokenContract = new ethers.Contract(tokenAddress, DV_TOKEN_ABI, this.provider);
    const allowance = await tokenContract.allowance(owner, spender);
    return parseFloat(ethers.formatUnits(allowance, 18));
  }

  disconnect(): void {
    this.signer = null;
  }

  isConnected(): boolean {
    return this.signer !== null;
  }

  getSignerAddress(): Promise<string | null> {
    if (!this.signer) return Promise.resolve(null);
    return this.signer.getAddress();
  }
}

export const txManager = new TransactionManager();
export default TransactionManager;
