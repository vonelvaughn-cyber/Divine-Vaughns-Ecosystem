import { openDB } from 'idb';
import CryptoJS from 'crypto-js';
import { APP_CONFIG } from '../config/app.config';

const ENCRYPTION_KEY = import.meta.env.VITE_STORAGE_KEY || 'dv-secure-key';

class PermanentStorage {
  private db: any = null;
  private userContext: {
    email: string;
    walletAddress: string;
    sessionId: string;
  } | null = null;

  constructor() {
    this.init();
  }

  async init() {
    this.db = await openDB('DVPermanentDB', 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('userProfiles')) {
          db.createObjectStore('userProfiles', { keyPath: 'email' });
        }
        if (!db.objectStoreNames.contains('coldStorage')) {
          const coldStore = db.createObjectStore('coldStorage', { keyPath: 'id' });
          coldStore.createIndex('userEmail', 'userEmail');
        }
        if (!db.objectStoreNames.contains('transactions')) {
          db.createObjectStore('transactions', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('aiConversations')) {
          const convoStore = db.createObjectStore('aiConversations', { keyPath: 'id' });
          convoStore.createIndex('userEmail', 'userEmail');
        }
        if (!db.objectStoreNames.contains('contentCoins')) {
          const coinStore = db.createObjectStore('contentCoins', { keyPath: 'id' });
          coinStore.createIndex('creatorEmail', 'creatorEmail');
        }
      }
    });
  }

  setUserContext(email: string, walletAddress?: string) {
    this.userContext = {
      email: email.toLowerCase().trim(),
      walletAddress: walletAddress?.toLowerCase() || '',
      sessionId: CryptoJS.SHA256(`${email}-${Date.now()}`).toString()
    };
    localStorage.setItem('dv_session', JSON.stringify({
      email: this.userContext.email,
      sessionId: this.userContext.sessionId,
      timestamp: Date.now()
    }));
  }

  getUserContext() {
    return this.userContext;
  }

  isAuthenticated(): boolean {
    return !!this.userContext;
  }

  encrypt(data: any): string | null {
    if (!this.userContext) return null;
    return CryptoJS.AES.encrypt(
      JSON.stringify(data), 
      `${ENCRYPTION_KEY}-${this.userContext.email}`
    ).toString();
  }

  decrypt(encryptedData: string): any | null {
    if (!this.userContext) return null;
    try {
      const bytes = CryptoJS.AES.decrypt(
        encryptedData, 
        `${ENCRYPTION_KEY}-${this.userContext.email}`
      );
      return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    } catch {
      return null;
    }
  }

  // Profile Management
  async createProfile(profileData: {
    displayName?: string;
    bio?: string;
    avatar?: string;
  }) {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const profile = {
      email: this.userContext.email,
      walletAddress: this.userContext.walletAddress,
      displayName: profileData.displayName || this.userContext.email.split('@')[0],
      bio: profileData.bio || '',
      avatar: profileData.avatar || '',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      status: 'active',
      tier: 0,
      preferences: {
        theme: 'dark',
        notifications: true,
        language: 'en'
      }
    };
    
    await this.db.put('userProfiles', profile);
    return profile;
  }

  async getProfile(email: string = this.userContext?.email || '') {
    if (!email) return null;
    return await this.db.get('userProfiles', email.toLowerCase().trim());
  }

  async updateProfile(updates: Partial<{
    displayName: string;
    bio: string;
    avatar: string;
    preferences: object;
  }>) {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const profile = await this.getProfile();
    if (!profile) throw new Error('Profile not found');

    const updated = {
      ...profile,
      ...updates,
      updatedAt: Date.now()
    };
    
    await this.db.put('userProfiles', updated);
    return updated;
  }

  // Cold Storage Wallets
  async createColdStorage(config: {
    amount: number;
    lockPeriod?: number;
    encryptionKey?: string;
    label?: string;
  }) {
    if (!this.userContext) throw new Error('Not authenticated');
    if (config.amount !== APP_CONFIG.features.coldStorageAmount) {
      throw new Error(`Requires exactly ${APP_CONFIG.features.coldStorageAmount} DV`);
    }

    const wallet = {
      id: `cold-${Date.now()}`,
      userEmail: this.userContext.email,
      amount: APP_CONFIG.features.coldStorageAmount,
      status: 'active',
      createdAt: Date.now(),
      unlocksAt: Date.now() + (config.lockPeriod || 30 * 24 * 60 * 60 * 1000), // Default 30 days
      encryptionKey: this.encrypt(config.encryptionKey || CryptoJS.lib.WordArray.random(32).toString()),
      label: config.label || 'Cold Storage',
      chainId: APP_CONFIG.network.chainId
    };

    await this.db.put('coldStorage', wallet);
    return wallet;
  }

  async getColdStorageWallets(email: string = this.userContext?.email || '') {
    if (!email) return [];
    const tx = this.db.transaction('coldStorage', 'readonly');
    const index = tx.store.index('userEmail');
    return await index.getAll(email.toLowerCase().trim());
  }

  async withdrawFromColdStorage(walletId: string) {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const wallet = await this.db.get('coldStorage', walletId);
    if (!wallet) throw new Error('Wallet not found');
    if (wallet.userEmail !== this.userContext.email) throw new Error('Unauthorized');
    if (wallet.status !== 'active') throw new Error('Wallet not active');
    if (Date.now() < wallet.unlocksAt) throw new Error('Lock period not complete');

    wallet.status = 'withdrawn';
    wallet.withdrawnAt = Date.now();
    await this.db.put('coldStorage', wallet);
    return wallet;
  }

  // Transaction History
  async recordTransaction(txData: {
    type: 'stake' | 'unstake' | 'swap' | 'claim' | 'ai_use' | 'storage_create' | 'storage_withdraw';
    amount: number;
    token: 'DV' | 'AIC' | 'stDV' | 'stDV3';
    status: 'pending' | 'confirmed' | 'failed';
    txHash?: string;
    metadata?: object;
  }) {
    if (!this.userContext) return;
    
    const record = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userEmail: this.userContext.email,
      walletAddress: this.userContext.walletAddress,
      ...txData,
      timestamp: Date.now(),
      basescanUrl: txData.txHash ? `${APP_CONFIG.network.explorer}/tx/${txData.txHash}` : null
    };
    
    await this.db.put('transactions', record);
    return record;
  }

  async getTransactions(email: string = this.userContext?.email || '', limit: number = 50) {
    if (!email) return [];
    const all = await this.db.getAll('transactions');
    return all
      .filter((t: any) => t.userEmail === email.toLowerCase().trim())
      .sort((a: any, b: any) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }

  // AI Conversation History
  async saveAIConversation(messages: Array<{role: string; content: string}>, metadata?: object) {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const conversation = {
      id: `ai-${Date.now()}`,
      userEmail: this.userContext.email,
      messages: this.encrypt(messages),
      metadata: metadata || {},
      timestamp: Date.now()
    };
    
    await this.db.put('aiConversations', conversation);
    return conversation;
  }

  async getAIConversations(email: string = this.userContext?.email || '') {
    if (!email) return [];
    const tx = this.db.transaction('aiConversations', 'readonly');
    const index = tx.store.index('userEmail');
    const conversations = await index.getAll(email.toLowerCase().trim());
    return conversations.map((c: any) => ({
      ...c,
      messages: this.decrypt(c.messages)
    })).sort((a: any, b: any) => b.timestamp - a.timestamp);
  }

  // Content Coins
  async createContentCoin(coinData: {
    name: string;
    symbol: string;
    totalSupply: number;
    price: number;
    description?: string;
  }) {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const coin = {
      id: `coin-${Date.now()}`,
      creatorEmail: this.userContext.email,
      creatorWallet: this.userContext.walletAddress,
      ...coinData,
      createdAt: Date.now(),
      status: 'active',
      sales: 0,
      revenue: 0
    };
    
    await this.db.put('contentCoins', coin);
    return coin;
  }

  async getContentCoins(creatorEmail: string = this.userContext?.email || '') {
    if (!creatorEmail) return [];
    const tx = this.db.transaction('contentCoins', 'readonly');
    const index = tx.store.index('creatorEmail');
    return await index.getAll(creatorEmail.toLowerCase().trim());
  }

  // Account Deactivation
  async requestDeactivation(reason: string) {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const profile = await this.getProfile();
    if (!profile) return;

    // Check for active cold storage
    const wallets = await this.getColdStorageWallets();
    if (wallets.some((w: any) => w.status === 'active')) {
      throw new Error('Withdraw from cold storage first');
    }

    profile.status = 'deactivation_requested';
    profile.deactivationDate = Date.now() + APP_CONFIG.features.deactivationGracePeriod;
    profile.deactivationReason = reason;
    await this.db.put('userProfiles', profile);
    
    return profile.deactivationDate;
  }

  // Session Management
  validateSession(): boolean {
    const session = localStorage.getItem('dv_session');
    if (!session) return false;
    
    try {
      const parsed = JSON.parse(session);
      const age = Date.now() - (parsed.timestamp || 0);
      return age < APP_CONFIG.features.sessionTimeout;
    } catch {
      return false;
    }
  }

  clearSession() {
    this.userContext = null;
    localStorage.removeItem('dv_session');
  }

  // Clear all data (for deactivation)
  async clearAllUserData() {
    if (!this.userContext) throw new Error('Not authenticated');
    
    const email = this.userContext.email;
    
    // Delete profile
    await this.db.delete('userProfiles', email);
    
    // Delete cold storage
    const wallets = await this.getColdStorageWallets(email);
    for (const wallet of wallets) {
      await this.db.delete('coldStorage', wallet.id);
    }
    
    // Delete transactions
    const txs = await this.getTransactions(email, 1000);
    for (const tx of txs) {
      await this.db.delete('transactions', tx.id);
    }
    
    // Delete AI conversations
    const convos = await this.getAIConversations(email);
    for (const convo of convos) {
      await this.db.delete('aiConversations', convo.id);
    }
    
    // Delete content coins
    const coins = await this.getContentCoins(email);
    for (const coin of coins) {
      await this.db.delete('contentCoins', coin.id);
    }
    
    this.clearSession();
  }
}

export const permanentStorage = new PermanentStorage();
export default permanentStorage;
