import { useState, useEffect } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { 
  Droplets, 
  TrendingUp, 
  Percent, 
  Gift, 
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { APP_CONFIG } from '@/config/app.config';
import { toast } from 'sonner';

// Liquidation Pool Contract ABI (placeholder - replace with actual deployed contract)
const LIQUIDATION_POOL_ABI = [
  {
    inputs: [],
    name: 'totalLiquidity',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'user', type: 'address' }],
    name: 'userContributions',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'user', type: 'address' }],
    name: 'userEarnings',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'uint256', name: 'amount', type: 'uint256' }],
    name: 'contribute',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [],
    name: 'withdrawEarnings',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: 'address', name: 'user', type: 'address' },
      { indexed: false, internalType: 'uint256', name: 'amount', type: 'uint256' },
      { indexed: false, internalType: 'uint256', name: 'commission', type: 'uint256' },
      { indexed: false, internalType: 'uint256', name: 'stDv3Reward', type: 'uint256' }
    ],
    name: 'ContributionMade',
    type: 'event'
  }
] as const;

// ERC20 ABI for approvals
const ERC20_ABI = [
  {
    inputs: [
      { internalType: 'address', name: 'owner', type: 'address' },
      { internalType: 'address', name: 'spender', type: 'address' }
    ],
    name: 'allowance',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'address', name: 'spender', type: 'address' },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'approve',
    outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function'
  }
] as const;

// Placeholder contract address - will need to be deployed
const LIQUIDATION_POOL_ADDRESS = '0x...'; // TODO: Deploy and update

export function LiquidationPool() {
  const { address, isConnected } = useAccount();
  const [contributionAmount, setContributionAmount] = useState('');
  const [isApproving, setIsApproving] = useState(false);
  const [isContributing, setIsContributing] = useState(false);

  // Get DV balance
  const { data: dvBalanceRaw } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: [
      { inputs: [{ internalType: 'address', name: 'account', type: 'address' }], name: 'balanceOf', outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }], stateMutability: 'view', type: 'function' }
    ],
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  // Get stDV3 balance
  const { data: stDv3BalanceRaw } = useReadContract({
    address: APP_CONFIG.contracts.stDv3Token as `0x${string}`,
    abi: [
      { inputs: [{ internalType: 'address', name: 'account', type: 'address' }], name: 'balanceOf', outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }], stateMutability: 'view', type: 'function' }
    ],
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  // Get user's contribution (placeholder - will work when contract deployed)
  const { data: userContribution } = useReadContract({
    address: LIQUIDATION_POOL_ADDRESS as `0x${string}`,
    abi: LIQUIDATION_POOL_ABI,
    functionName: 'userContributions',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && LIQUIDATION_POOL_ADDRESS !== '0x...' }
  });

  // Get user's earnings (placeholder)
  const { data: userEarnings } = useReadContract({
    address: LIQUIDATION_POOL_ADDRESS as `0x${string}`,
    abi: LIQUIDATION_POOL_ABI,
    functionName: 'userEarnings',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && LIQUIDATION_POOL_ADDRESS !== '0x...' }
  });

  // Get total pool liquidity (placeholder)
  const { data: totalLiquidity } = useReadContract({
    address: LIQUIDATION_POOL_ADDRESS as `0x${string}`,
    abi: LIQUIDATION_POOL_ABI,
    functionName: 'totalLiquidity',
    query: { enabled: LIQUIDATION_POOL_ADDRESS !== '0x...' }
  });

  // Calculate commission and rewards
  const contributionValue = parseFloat(contributionAmount) || 0;
  const commissionEarned = contributionValue * 0.05; // 5% commission
  const stDv3Reward = contributionValue * 0.5; // 0.5 stDV3 per DV contributed

  // Check DV allowance
  const { data: dvAllowance, refetch: refetchAllowance } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: address && LIQUIDATION_POOL_ADDRESS !== '0x...' ? [address, LIQUIDATION_POOL_ADDRESS] : undefined,
    query: { enabled: isConnected && LIQUIDATION_POOL_ADDRESS !== '0x...' }
  });

  const needsApproval = LIQUIDATION_POOL_ADDRESS !== '0x...' && 
    dvAllowance !== undefined && 
    contributionAmount && 
    BigInt(dvAllowance) < parseUnits(contributionAmount, 18);

  // Approval
  const { writeContract: approveDV, data: approveHash } = useWriteContract();
  const { isSuccess: approveSuccess } = useWaitForTransactionReceipt({ hash: approveHash });

  useEffect(() => {
    if (approveSuccess) {
      setIsApproving(false);
      refetchAllowance();
      toast.success('DV approved for liquidation pool');
    }
  }, [approveSuccess, refetchAllowance]);

  // Contribution
  const { writeContract: contribute, data: contributeHash, error: contributeError } = useWriteContract();
  const { isSuccess: contributeSuccess } = useWaitForTransactionReceipt({ hash: contributeHash });

  useEffect(() => {
    if (contributeSuccess) {
      setIsContributing(false);
      setContributionAmount('');
      toast.success(`Contributed ${contributionAmount} DV! Earned ${commissionEarned.toFixed(2)} DV commission + ${stDv3Reward.toFixed(2)} stDV3`);
    }
  }, [contributeSuccess, contributionAmount, commissionEarned, stDv3Reward]);

  useEffect(() => {
    if (contributeError) {
      setIsContributing(false);
      toast.error('Contribution failed: ' + (contributeError as Error).message);
    }
  }, [contributeError]);

  const handleApprove = async () => {
    if (!contributionAmount || LIQUIDATION_POOL_ADDRESS === '0x...') return;
    setIsApproving(true);
    approveDV({
      address: APP_CONFIG.contracts.dvToken as `0x${string}`,
      abi: ERC20_ABI,
      functionName: 'approve',
      args: [LIQUIDATION_POOL_ADDRESS, parseUnits(contributionAmount, 18)]
    });
  };

  const handleContribute = async () => {
    if (!contributionAmount || LIQUIDATION_POOL_ADDRESS === '0x...') {
      toast.info('Liquidation pool contract coming soon!');
      return;
    }
    setIsContributing(true);
    contribute({
      address: LIQUIDATION_POOL_ADDRESS as `0x${string}`,
      abi: LIQUIDATION_POOL_ABI,
      functionName: 'contribute',
      args: [parseUnits(contributionAmount, 18)]
    });
  };

  const formatBalance = (value: bigint | undefined) => {
    if (!value) return '0';
    return formatUnits(value, 18);
  };

  return (
    <TooltipProvider>
      <Card className="w-full max-w-lg mx-auto bg-gradient-to-br from-slate-900 to-slate-800 border-emerald-500/30">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mb-4">
            <Droplets className="w-8 h-8 text-emerald-400" />
          </div>
          <CardTitle className="text-2xl text-white">Liquidation Pool</CardTitle>
          <p className="text-slate-400 text-sm mt-2">
            Contribute DV to the liquidation pool and earn commissions + stDV3 rewards
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Pool Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-800/50 rounded-xl p-4 text-center">
              <p className="text-sm text-slate-400 mb-1">Total Pool Liquidity</p>
              <p className="text-xl font-bold text-emerald-400">
                {formatBalance(totalLiquidity as bigint)} DV
              </p>
            </div>
            <div className="bg-slate-800/50 rounded-xl p-4 text-center">
              <p className="text-sm text-slate-400 mb-1">Your Contribution</p>
              <p className="text-xl font-bold text-cyan-400">
                {formatBalance(userContribution as bigint)} DV
              </p>
            </div>
          </div>

          {/* Your Earnings */}
          <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 rounded-xl p-4 border border-emerald-500/20">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-300 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                Your Earnings
              </span>
              <Badge className="bg-emerald-500/20 text-emerald-400">
                {formatBalance(userEarnings as bigint)} DV
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-300 flex items-center gap-2">
                <Gift className="w-4 h-4 text-purple-400" />
                stDV3 Balance
              </span>
              <Badge className="bg-purple-500/20 text-purple-400">
                {formatBalance(stDv3BalanceRaw as bigint)} stDV3
              </Badge>
            </div>
          </div>

          {/* Contribution Input */}
          <div className="space-y-4">
            <div className="bg-slate-800/50 rounded-xl p-4">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-slate-400">Contribution Amount</span>
                <span className="text-sm text-slate-500">
                  Balance: {formatBalance(dvBalanceRaw as bigint)} DV
                </span>
              </div>
              <div className="flex gap-3">
                <Input
                  type="number"
                  placeholder="0.0"
                  value={contributionAmount}
                  onChange={(e) => setContributionAmount(e.target.value)}
                  className="flex-1 bg-slate-700 border-slate-600 text-white"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const max = formatBalance(dvBalanceRaw as bigint);
                    setContributionAmount(max);
                  }}
                  className="border-slate-600 text-slate-300"
                >
                  MAX
                </Button>
              </div>
            </div>

            {/* Reward Preview */}
            {contributionValue > 0 && (
              <div className="bg-slate-800/30 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400 flex items-center gap-2">
                    <Percent className="w-4 h-4 text-emerald-400" />
                    Commission (5%)
                  </span>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="w-4 h-4 text-slate-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Earn 5% commission on your contribution amount</p>
                    </TooltipContent>
                  </Tooltip>
                  <span className="text-emerald-400 font-medium">+{commissionEarned.toFixed(4)} DV</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400 flex items-center gap-2">
                    <Gift className="w-4 h-4 text-purple-400" />
                    stDV3 Reward (0.5x)
                  </span>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="w-4 h-4 text-slate-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Receive 0.5 stDV3 for every DV contributed</p>
                    </TooltipContent>
                  </Tooltip>
                  <span className="text-purple-400 font-medium">+{stDv3Reward.toFixed(4)} stDV3</span>
                </div>
                <div className="border-t border-slate-700 pt-3 mt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-300">Total Value</span>
                    <span className="text-white font-bold">
                      {contributionValue + commissionEarned} DV + {stDv3Reward} stDV3
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            {LIQUIDATION_POOL_ADDRESS === '0x...' ? (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-center">
                <AlertCircle className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <p className="text-amber-400 font-medium">Coming Soon</p>
                <p className="text-sm text-amber-400/70">
                  Liquidation pool contract is being deployed
                </p>
              </div>
            ) : needsApproval ? (
              <Button
                onClick={handleApprove}
                disabled={isApproving || !contributionAmount}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold"
              >
                {isApproving ? 'Approving DV...' : 'Approve DV'}
              </Button>
            ) : (
              <Button
                onClick={handleContribute}
                disabled={isContributing || !contributionAmount || parseFloat(contributionAmount) <= 0}
                className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold"
              >
                {isContributing ? 'Contributing...' : 'Contribute to Pool'}
              </Button>
            )}

            {contributeSuccess && (
              <div className="flex items-center gap-2 text-emerald-400 text-sm justify-center">
                <CheckCircle className="w-4 h-4" />
                Contribution successful! Check your earnings.
              </div>
            )}

            {contributeHash && (
              <a
                href={`${APP_CONFIG.network.explorer}/tx/${contributeHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-emerald-400 hover:text-emerald-300 text-center block"
              >
                View on BaseScan →
              </a>
            )}
          </div>

          {/* How It Works */}
          <div className="bg-slate-800/30 rounded-xl p-4">
            <h4 className="text-sm font-medium text-white mb-3">How It Works</h4>
            <div className="space-y-2 text-sm text-slate-400">
              <div className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-emerald-400 mt-0.5" />
                <span>Contribute DV to help maintain pool liquidity</span>
              </div>
              <div className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-emerald-400 mt-0.5" />
                <span>Earn 5% commission on your contribution instantly</span>
              </div>
              <div className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-purple-400 mt-0.5" />
                <span>Receive 0.5 stDV3 per DV contributed (90-day locked)</span>
              </div>
              <div className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-cyan-400 mt-0.5" />
                <span>Withdraw earnings anytime - no lock on commissions</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
}

export default LiquidationPool;
