import { useState } from 'react';
import { useAccount } from 'wagmi';
import { useDVTier } from '@/hooks/useDVTier';
import { formatDVAmount } from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Wallet, 
  Lock, 
  Key, 
  Shield, 
  CheckCircle, 
  AlertTriangle,
  Copy,
  Eye,
  EyeOff,
  RefreshCw,
  Download
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface StorageWallet {
  id: string;
  name: string;
  address: string;
  storageCode: string;
  createdAt: number;
  balance: bigint;
}

const STORAGE_WALLET_COST = 500n * 10n ** 18n; // 500 DV

export function StorageCodeWallet() {
  const { isConnected } = useAccount();
  const { balance, formattedBalance, hasStorageAccess } = useDVTier();
  
  const [wallets, setWallets] = useState<StorageWallet[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [walletName, setWalletName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [newWallet, setNewWallet] = useState<StorageWallet | null>(null);
  const [showCode, setShowCode] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateStorageCode = () => {
    // Generate a secure 24-word storage code
    const words = [
      'quantum', 'nebula', 'crystal', 'phoenix', 'dragon', 'tiger', 'eagle', 'wolf',
      'thunder', 'lightning', 'storm', 'ocean', 'mountain', 'forest', 'desert', 'river',
      'diamond', 'emerald', 'sapphire', 'ruby', 'golden', 'silver', 'bronze', 'platinum'
    ];
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 12).join(' ');
  };

  const generateWalletAddress = () => {
    // Generate a mock wallet address
    return '0x' + Array(40).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
  };

  const handleCreateWallet = async () => {
    if (!walletName || !hasStorageAccess) return;
    
    setIsCreating(true);
    
    // Simulate wallet creation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const storageCode = generateStorageCode();
    const wallet: StorageWallet = {
      id: Math.random().toString(36).substr(2, 9),
      name: walletName,
      address: generateWalletAddress(),
      storageCode,
      createdAt: Date.now(),
      balance: 0n,
    };
    
    setNewWallet(wallet);
    setWallets(prev => [...prev, wallet]);
    setIsCreating(false);
    setShowCreateModal(false);
    setShowCodeModal(true);
    setWalletName('');
  };

  const copyCode = () => {
    if (newWallet) {
      navigator.clipboard.writeText(newWallet.storageCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadBackup = () => {
    if (!newWallet) return;
    
    const backupData = {
      walletName: newWallet.name,
      address: newWallet.address,
      storageCode: newWallet.storageCode,
      createdAt: new Date(newWallet.createdAt).toISOString(),
      warning: 'KEEP THIS CODE SECURE - NEVER SHARE WITH ANYONE',
    };
    
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `storage-wallet-${newWallet.name}-backup.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Wallet className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to create storage code wallets</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <Key className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">Storage Code Wallet</CardTitle>
                <CardDescription className="text-white/50">
                  Create secure backup wallets with recovery codes
                </CardDescription>
              </div>
            </div>
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              <Shield className="w-3 h-3 mr-1" />
              Secure
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Tier Requirement */}
          {!hasStorageAccess && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-400">Tier 3 Required</p>
                  <p className="text-sm text-white/60">
                    You need <span className="text-yellow-400 font-medium">Gold Tier (1,000+ DV)</span> to create storage wallets
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Pricing Info */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-emerald-400" />
                <span className="text-white font-medium">Storage Wallet Creation</span>
              </div>
              <Badge variant="outline" className="border-emerald-500/30 text-emerald-400">
                {formatDVAmount(STORAGE_WALLET_COST)} DV
              </Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Cost</span>
                <span className="text-emerald-400 font-semibold">
                  {formatDVAmount(STORAGE_WALLET_COST)} DV
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Your Balance</span>
                <span className={balance >= STORAGE_WALLET_COST ? 'text-emerald-400' : 'text-red-400'}>
                  {formattedBalance} DV
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Wallets Created</span>
                <span className="text-white">{wallets.length}</span>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="space-y-2">
            <p className="text-sm text-white/60 mb-3">What You Get</p>
            {[
              'Secure 12-word storage code',
              'Unique wallet address',
              'Encrypted backup option',
              'Full ownership control',
              'Compatible with MetaMask',
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-white/70">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                {feature}
              </div>
            ))}
          </div>

          {/* Create Button */}
          <Button
            onClick={() => setShowCreateModal(true)}
            disabled={!hasStorageAccess || balance < STORAGE_WALLET_COST}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 disabled:opacity-50"
          >
            {!hasStorageAccess ? (
              <>
                <Lock className="w-4 h-4 mr-2" />
                Tier 3 Required
              </>
            ) : balance < STORAGE_WALLET_COST ? (
              <>
                <AlertTriangle className="w-4 h-4 mr-2" />
                Insufficient DV (Need {formatDVAmount(STORAGE_WALLET_COST)})
              </>
            ) : (
              <>
                <Key className="w-4 h-4 mr-2" />
                Create Storage Wallet ({formatDVAmount(STORAGE_WALLET_COST)} DV)
              </>
            )}
          </Button>

          {/* Existing Wallets */}
          {wallets.length > 0 && (
            <div className="space-y-3">
              <p className="text-sm text-white/60">Your Storage Wallets</p>
              <div className="space-y-2">
                {wallets.map((wallet) => (
                  <div
                    key={wallet.id}
                    className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                        <Wallet className="w-5 h-5 text-emerald-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">{wallet.name}</p>
                        <p className="text-xs text-white/40 font-mono">{wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}</p>
                      </div>
                    </div>
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      Active
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Wallet Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Create Storage Wallet</DialogTitle>
            <DialogDescription className="text-white/60">
              Create a secure backup wallet with recovery code
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-white/5 space-y-3">
              <div className="flex justify-between">
                <span className="text-white/60">Creation Cost</span>
                <span className="text-emerald-400 font-medium">{formatDVAmount(STORAGE_WALLET_COST)} DV</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Your Balance After</span>
                <span className="text-white font-medium">
                  {formatDVAmount(balance - STORAGE_WALLET_COST)} DV
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="walletName" className="text-white/70">Wallet Name</Label>
              <Input
                id="walletName"
                placeholder="e.g., Backup Wallet, Savings, etc."
                value={walletName}
                onChange={(e) => setWalletName(e.target.value)}
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="text-sm text-white/70">
                  <p className="font-medium text-amber-400 mb-1">Important</p>
                  <p>You will receive a 12-word storage code. Write it down and keep it secure. 
                  Anyone with this code can access your wallet. We do not store or recover codes.</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 border-white/10 hover:bg-white/5"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateWallet}
                disabled={!walletName || isCreating}
                className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90"
              >
                {isCreating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create Wallet'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Storage Code Modal */}
      <Dialog open={showCodeModal} onOpenChange={setShowCodeModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-emerald-400 flex items-center gap-2">
              <CheckCircle className="w-6 h-6" />
              Wallet Created!
            </DialogTitle>
            <DialogDescription className="text-white/60">
              Save your storage code securely - it cannot be recovered
            </DialogDescription>
          </DialogHeader>

          {newWallet && (
            <div className="space-y-4 mt-4">
              <div className="p-4 rounded-xl bg-white/5">
                <p className="text-sm text-white/60 mb-1">Wallet Name</p>
                <p className="text-white font-medium">{newWallet.name}</p>
              </div>

              <div className="p-4 rounded-xl bg-white/5">
                <p className="text-sm text-white/60 mb-1">Wallet Address</p>
                <p className="text-white font-mono text-sm">{newWallet.address}</p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm text-emerald-400 font-medium flex items-center gap-2">
                    <Key className="w-4 h-4" />
                    Storage Code
                  </p>
                  <button
                    onClick={() => setShowCode(!showCode)}
                    className="text-white/50 hover:text-white"
                  >
                    {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                
                <div className="relative">
                  <p className={`text-lg font-mono leading-relaxed ${showCode ? 'text-white' : 'text-transparent bg-white/10 rounded blur-sm select-none'}`}>
                    {newWallet.storageCode}
                  </p>
                  {!showCode && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-white/50 text-sm">Click eye icon to reveal</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-4">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={copyCode}
                    className="flex-1 border-white/10 hover:bg-white/5"
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2 text-emerald-400" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Code
                      </>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={downloadBackup}
                    className="flex-1 border-white/10 hover:bg-white/5"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Backup
                  </Button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
                  <div className="text-sm text-white/70">
                    <p className="font-medium text-red-400 mb-1">Security Warning</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Never share your storage code with anyone</li>
                      <li>Store it in a secure, offline location</li>
                      <li>We cannot recover lost or forgotten codes</li>
                      <li>Anyone with this code has full access to your wallet</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button
                onClick={() => {
                  setShowCodeModal(false);
                  setNewWallet(null);
                  setShowCode(false);
                }}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90"
              >
                <Shield className="w-4 h-4 mr-2" />
                I Have Saved My Code
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
