import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { useReadContract } from 'wagmi';
import { 
  DV_TOKEN_ADDRESS,
  AIC_TOKEN_ADDRESS,
  DV_TOKEN_ABI,
  AIC_TOKEN_ABI,
  CONSTANTS,
  formatDVAmount,
  formatTokenAmount
} from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  Coins, 
  Flame, 
  Zap,
  BarChart3,
  ArrowRightLeft,
  Cloud,
  DollarSign,
  Activity
} from 'lucide-react';

interface PoolMetrics {
  dvLiquidity: bigint;
  aicLiquidity: bigint;
  totalVolume24h: bigint;
  feesGenerated24h: bigint;
  aicBurned24h: bigint;
  cloudRevenue: number;
}

// Actual DV/AIC Pool data from Uniswap V3
// Pool: 0xd183852247134036b07f5E1190977b291AaD6355
// Fee: 0.3%
// Current liquidity: ~80,000 AIC / ~40,000 DV
const usePoolMetrics = () => {
  const [metrics] = useState<PoolMetrics>({
    dvLiquidity: 39999n * 10n ** 18n,    // ~40,000 DV
    aicLiquidity: 80000n * 10n ** 18n,   // ~80,000 AIC
    totalVolume24h: 1500000n * 10n ** 18n, // 1.5M DV volume
    feesGenerated24h: 4500n * 10n ** 18n,  // 0.3% fees
    aicBurned24h: 500n * 10n ** 15n,      // 500 messages * 0.001 AIC
    cloudRevenue: 1250.50,
  });

  const [isLoading, setIsLoading] = useState(false);

  const refetch = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
  };

  return { metrics, isLoading, refetch };
};

export function DVAICPool() {
  const { isConnected, address } = useAccount();
  const { metrics, isLoading, refetch } = usePoolMetrics();

  // Get user's DV balance
  const { data: dvBalance } = useReadContract({
    address: DV_TOKEN_ADDRESS as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address },
  });

  // Get user's AIC balance
  const { data: aicBalance } = useReadContract({
    address: AIC_TOKEN_ADDRESS as `0x${string}`,
    abi: AIC_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address },
  });

  const userDVBalance = dvBalance || 0n;
  const userAICBalance = aicBalance || 0n;

  // Calculate pool ratio
  const dvAICRatio = Number(metrics.dvLiquidity) / Number(metrics.aicLiquidity);
  
  // Calculate user's share of pool (if they provided liquidity)
  const userPoolShare = 0.05; // Mock 5% share
  const userEstimatedEarnings = metrics.cloudRevenue * userPoolShare;

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000);
    return () => clearInterval(interval);
  }, [refetch]);

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <ArrowRightLeft className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to view DV/AIC Pool</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-br from-emerald-500/10 to-purple-500/10 border-emerald-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-purple-600 flex items-center justify-center">
                <ArrowRightLeft className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-xl">DV/AIC Revenue Pool</CardTitle>
                <CardDescription className="text-white/50">
                  Paired liquidity for cloud revenue generation
                </CardDescription>
              </div>
            </div>
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              <Cloud className="w-3 h-3 mr-1" />
              Active
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Pool Ratio */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            Pool Ratio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center gap-4 py-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-white">0.5</p>
              <p className="text-sm text-white/50">DV</p>
            </div>
            <div className="text-white/30 text-2xl">≈</div>
            <div className="text-center">
              <p className="text-3xl font-bold text-purple-400">1</p>
              <p className="text-sm text-white/50">AIC</p>
            </div>
          </div>
          <div className="text-center">
            <p className="text-xs text-white/40">
              Current ratio: ~{dvAICRatio.toFixed(3)} DV per AIC
            </p>
            <p className="text-xs text-emerald-400/70 mt-1">
              Pool: 0xd183...D6355 | Fee: 0.3%
            </p>
          </div>
          <p className="text-center text-sm text-white/40 mt-2">
            Current ratio: {dvAICRatio.toFixed(2)}:1
          </p>
        </CardContent>
      </Card>

      {/* Pool Liquidity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-white/[0.02] border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <Coins className="w-5 h-5 text-emerald-400" />
              <Badge className="bg-emerald-500/20 text-emerald-400">DV</Badge>
            </div>
            <p className="text-sm text-white/50 mb-1">DV Liquidity</p>
            <p className="text-2xl font-bold text-white">{formatDVAmount(metrics.dvLiquidity)}</p>
            <p className="text-xs text-white/40 mt-1">
              Your balance: {formatDVAmount(userDVBalance)} DV
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white/[0.02] border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <Zap className="w-5 h-5 text-purple-400" />
              <Badge className="bg-purple-500/20 text-purple-400">AIC</Badge>
            </div>
            <p className="text-sm text-white/50 mb-1">AIC Liquidity</p>
            <p className="text-2xl font-bold text-purple-400">{formatTokenAmount(metrics.aicLiquidity, 18)}</p>
            <p className="text-xs text-white/40 mt-1">
              Your balance: {formatTokenAmount(userAICBalance, 18)} AIC
            </p>
          </CardContent>
        </Card>
      </div>

      {/* 24h Stats */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-aether-blue" />
            24h Statistics
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-sm text-white/50 mb-1">Trading Volume</p>
              <p className="text-lg font-semibold text-white">{formatDVAmount(metrics.totalVolume24h)} DV</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-sm text-white/50 mb-1">Fees Generated</p>
              <p className="text-lg font-semibold text-emerald-400">{formatDVAmount(metrics.feesGenerated24h)} DV</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-sm text-white/50 mb-1">AIC Burned</p>
              <p className="text-lg font-semibold text-orange-400">{formatTokenAmount(metrics.aicBurned24h, 18)} AIC</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-sm text-white/50 mb-1">Messages</p>
              <p className="text-lg font-semibold text-purple-400">
                {Number(metrics.aicBurned24h / CONSTANTS.AI_COST_PER_MESSAGE).toLocaleString()}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cloud Revenue */}
      <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/20">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <Cloud className="w-5 h-5 text-amber-400" />
            Cloud Revenue Generated
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-5xl font-bold text-amber-400 mb-2">
              ${metrics.cloudRevenue.toLocaleString()}
            </p>
            <p className="text-white/50">Total cloud revenue (24h)</p>
          </div>
          
          <div className="mt-4 p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex justify-between items-center mb-2">
              <span className="text-white/60">Your Pool Share</span>
              <span className="text-white font-medium">{(userPoolShare * 100).toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/60">Your Earnings (24h)</span>
              <span className="text-emerald-400 font-medium">${userEstimatedEarnings.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Revenue Breakdown */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            Revenue Sources
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
            <div className="flex items-center gap-2">
              <ArrowRightLeft className="w-4 h-4 text-pink-400" />
              <span className="text-white/70">DV Swap Fees (0.3%)</span>
            </div>
            <span className="text-white font-medium">45%</span>
          </div>
          <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-400" />
              <span className="text-white/70">AIC Burn Engine</span>
            </div>
            <span className="text-white font-medium">35%</span>
          </div>
          <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-aether-blue" />
              <span className="text-white/70">Staking Rewards</span>
            </div>
            <span className="text-white font-medium">20%</span>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90"
        >
          <Coins className="w-4 h-4 mr-2" />
          Add DV Liquidity
        </Button>
        <Button
          className="bg-gradient-to-r from-purple-500 to-pink-600 hover:opacity-90"
        >
          <Zap className="w-4 h-4 mr-2" />
          Add AIC Liquidity
        </Button>
      </div>

      {/* Refresh */}
      <div className="text-center">
        <Button
          variant="outline"
          size="sm"
          onClick={() => refetch()}
          disabled={isLoading}
          className="border-white/10 hover:bg-white/5"
        >
          <TrendingUp className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh Data
        </Button>
      </div>
    </div>
  );
}
