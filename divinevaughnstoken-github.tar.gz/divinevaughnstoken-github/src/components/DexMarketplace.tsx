import { useState, useEffect } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { ArrowDown, RefreshCw, Settings, AlertTriangle, CheckCircle, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { APP_CONFIG } from '@/config/app.config';
import { UNISWAP_V3_ROUTER, POOL_FEES } from '@/lib/web3';

// Popular tokens on Base
const MARKET_TOKENS = [
  { symbol: 'ETH', name: 'Ethereum', address: '0x4200000000000000000000000000000000000006', decimals: 18, logo: '🔷' },
  { symbol: 'USDC', name: 'USD Coin', address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', decimals: 6, logo: '💵' },
  { symbol: 'cbETH', name: 'Coinbase Wrapped ETH', address: '0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22', decimals: 18, logo: '🔶' },
  { symbol: 'USDbC', name: 'USD Base Coin', address: '0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA', decimals: 6, logo: '💲' },
  { symbol: 'DV', name: 'Divine Vaughns', address: APP_CONFIG.contracts.dvToken, decimals: 18, logo: '✨' },
  { symbol: 'AIC', name: 'AI Catalyst', address: APP_CONFIG.contracts.aicToken, decimals: 18, logo: '🤖' },
];

// Uniswap V3 Quoter address on Base
const UNISWAP_V3_QUOTER = '0x3d4e44Eb1374240CE5F1B871ab261CD16335CB61';

const QUOTER_ABI = [
  {
    inputs: [
      { internalType: 'address', name: 'tokenIn', type: 'address' },
      { internalType: 'address', name: 'tokenOut', type: 'address' },
      { internalType: 'uint24', name: 'fee', type: 'uint24' },
      { internalType: 'uint256', name: 'amountIn', type: 'uint256' },
      { internalType: 'uint160', name: 'sqrtPriceLimitX96', type: 'uint160' }
    ],
    name: 'quoteExactInputSingle',
    outputs: [{ internalType: 'uint256', name: 'amountOut', type: 'uint256' }],
    stateMutability: 'nonpayable',
    type: 'function'
  }
] as const;

const ROUTER_ABI = [
  {
    inputs: [
      {
        components: [
          { internalType: 'address', name: 'tokenIn', type: 'address' },
          { internalType: 'address', name: 'tokenOut', type: 'address' },
          { internalType: 'uint24', name: 'fee', type: 'uint24' },
          { internalType: 'address', name: 'recipient', type: 'address' },
          { internalType: 'uint256', name: 'deadline', type: 'uint256' },
          { internalType: 'uint256', name: 'amountIn', type: 'uint256' },
          { internalType: 'uint256', name: 'amountOutMinimum', type: 'uint256' },
          { internalType: 'uint160', name: 'sqrtPriceLimitX96', type: 'uint160' }
        ],
        internalType: 'struct IV3SwapRouter.ExactInputSingleParams',
        name: 'params',
        type: 'tuple'
      }
    ],
    name: 'exactInputSingle',
    outputs: [{ internalType: 'uint256', name: 'amountOut', type: 'uint256' }],
    stateMutability: 'payable',
    type: 'function'
  }
] as const;

const ERC20_ABI = [
  { inputs: [{ internalType: 'address', name: 'owner', type: 'address' }, { internalType: 'address', name: 'spender', type: 'address' }], name: 'allowance', outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }], stateMutability: 'view', type: 'function' },
  { inputs: [{ internalType: 'address', name: 'spender', type: 'address' }, { internalType: 'uint256', name: 'amount', type: 'uint256' }], name: 'approve', outputs: [{ internalType: 'bool', name: '', type: 'bool' }], stateMutability: 'nonpayable', type: 'function' }
] as const;

interface DexMarketplaceProps {
  onClose?: () => void;
}

export function DexMarketplace({ onClose }: DexMarketplaceProps) {
  const { address, isConnected } = useAccount();
  
  // Access control check - use readContract for token balances
  const { data: dvBalanceRaw } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: [
      { inputs: [{ internalType: 'address', name: 'account', type: 'address' }], name: 'balanceOf', outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }], stateMutability: 'view', type: 'function' }
    ],
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });
  
  const { data: aicBalanceRaw } = useReadContract({
    address: APP_CONFIG.contracts.aicToken as `0x${string}`,
    abi: [
      { inputs: [{ internalType: 'address', name: 'account', type: 'address' }], name: 'balanceOf', outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }], stateMutability: 'view', type: 'function' }
    ],
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });
  
  // Format balances
  const dvBalance = dvBalanceRaw ? { value: dvBalanceRaw as bigint } : undefined;
  const aicBalance = aicBalanceRaw ? { value: aicBalanceRaw as bigint } : undefined;

  const hasAccess = isConnected && 
    dvBalance && BigInt(dvBalance.value) >= BigInt(100 * 10**18) &&
    aicBalance && BigInt(aicBalance.value) >= BigInt(200 * 10**18);

  // Swap state
  const [fromToken, setFromToken] = useState(MARKET_TOKENS[4]); // DV default
  const [toToken, setToToken] = useState(MARKET_TOKENS[1]); // USDC default
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [slippage, setSlippage] = useState(0.5);
  const [showSettings, setShowSettings] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  const [swapSuccess, setSwapSuccess] = useState(false);

  // Get quote
  const { data: quoteAmount } = useReadContract({
    address: UNISWAP_V3_QUOTER,
    abi: QUOTER_ABI,
    functionName: 'quoteExactInputSingle',
    args: fromAmount && parseFloat(fromAmount) > 0 ? [
      fromToken.address as `0x${string}`,
      toToken.address as `0x${string}`,
      POOL_FEES.MEDIUM,
      parseUnits(fromAmount, fromToken.decimals),
      0n
    ] : undefined,
    query: { enabled: !!fromAmount && parseFloat(fromAmount) > 0 }
  });

  useEffect(() => {
    if (quoteAmount) {
      setToAmount(formatUnits(quoteAmount, toToken.decimals));
    }
  }, [quoteAmount, toToken.decimals]);

  // Check allowance
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: fromToken.address as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: address ? [address, UNISWAP_V3_ROUTER] : undefined,
    query: { enabled: isConnected && fromToken.symbol !== 'ETH' }
  });

  const needsApproval = fromToken.symbol !== 'ETH' && 
    allowance !== undefined && 
    fromAmount && 
    BigInt(allowance) < parseUnits(fromAmount, fromToken.decimals);

  // Approval
  const { writeContract: approveToken, data: approveHash } = useWriteContract();
  const { isSuccess: approveSuccess } = useWaitForTransactionReceipt({ hash: approveHash });

  useEffect(() => {
    if (approveSuccess) {
      setIsApproving(false);
      refetchAllowance();
    }
  }, [approveSuccess, refetchAllowance]);

  // Swap
  const { writeContract: executeSwap, data: swapHash, error: swapError } = useWriteContract();
  const { isSuccess: swapConfirmed } = useWaitForTransactionReceipt({ hash: swapHash });

  useEffect(() => {
    if (swapConfirmed) {
      setIsSwapping(false);
      setSwapSuccess(true);
      setFromAmount('');
      setToAmount('');
      setTimeout(() => setSwapSuccess(false), 5000);
    }
  }, [swapConfirmed]);

  useEffect(() => {
    if (swapError) {
      setIsSwapping(false);
    }
  }, [swapError]);

  const handleApprove = async () => {
    if (!fromAmount) return;
    setIsApproving(true);
    approveToken({
      address: fromToken.address as `0x${string}`,
      abi: ERC20_ABI,
      functionName: 'approve',
      args: [UNISWAP_V3_ROUTER, parseUnits(fromAmount, fromToken.decimals)]
    });
  };

  const handleSwap = async () => {
    if (!fromAmount || !address) return;
    setIsSwapping(true);

    const amountIn = parseUnits(fromAmount, fromToken.decimals);
    const amountOutMin = quoteAmount ? 
      (quoteAmount * BigInt(Math.floor((100 - slippage) * 100))) / 10000n : 
      0n;

    executeSwap({
      address: UNISWAP_V3_ROUTER,
      abi: ROUTER_ABI,
      functionName: 'exactInputSingle',
      args: [{
        tokenIn: fromToken.address as `0x${string}`,
        tokenOut: toToken.address as `0x${string}`,
        fee: POOL_FEES.MEDIUM,
        recipient: address,
        deadline: BigInt(Math.floor(Date.now() / 1000) + 300),
        amountIn,
        amountOutMinimum: amountOutMin,
        sqrtPriceLimitX96: 0n
      }],
      value: fromToken.symbol === 'ETH' ? amountIn : 0n
    });
  };

  const switchTokens = () => {
    setFromToken(toToken);
    setToToken(fromToken);
    setFromAmount(toAmount);
    setToAmount(fromAmount);
  };

  // Access denied view
  if (!hasAccess) {
    return (
      <Card className="w-full max-w-lg mx-auto bg-gradient-to-br from-slate-900 to-slate-800 border-amber-500/30">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center mb-4">
            <Lock className="w-8 h-8 text-amber-400" />
          </div>
          <CardTitle className="text-2xl text-white">DEX Marketplace Locked</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-slate-300 text-center">
            Access to the full DEX marketplace requires holding both DV and AIC tokens.
          </p>
          
          <div className="bg-slate-800/50 rounded-lg p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Required DV</span>
              <div className="flex items-center gap-2">
                <span className={dvBalance && BigInt(dvBalance.value) >= BigInt(100 * 10**18) ? 'text-green-400' : 'text-red-400'}>
                  {dvBalance ? formatUnits(dvBalance.value, 18) : '0'}
                </span>
                <span className="text-slate-500">/ 100 DV</span>
                {dvBalance && BigInt(dvBalance.value) >= BigInt(100 * 10**18) && <CheckCircle className="w-4 h-4 text-green-400" />}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Required AIC</span>
              <div className="flex items-center gap-2">
                <span className={aicBalance && BigInt(aicBalance.value) >= BigInt(200 * 10**18) ? 'text-green-400' : 'text-red-400'}>
                  {aicBalance ? formatUnits(aicBalance.value, 18) : '0'}
                </span>
                <span className="text-slate-500">/ 200 AIC</span>
                {aicBalance && BigInt(aicBalance.value) >= BigInt(200 * 10**18) && <CheckCircle className="w-4 h-4 text-green-400" />}
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1 border-amber-500/50 text-amber-400 hover:bg-amber-500/10"
              onClick={onClose}
            >
              Go Back
            </Button>
            <Button 
              className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold hover:from-amber-400 hover:to-amber-500"
              onClick={() => window.open('https://app.uniswap.org/#/swap?chain=base', '_blank')}
            >
              Get Tokens
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-lg mx-auto bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/30">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl text-white flex items-center gap-2">
          <RefreshCw className="w-5 h-5 text-cyan-400" />
          DEX Marketplace
        </CardTitle>
        <div className="flex items-center gap-2">
          <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded">✓ Access Granted</span>
          <Button variant="ghost" size="icon" onClick={() => setShowSettings(true)}>
            <Settings className="w-5 h-5 text-slate-400" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* From Token */}
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-slate-400">From</span>
            <span className="text-sm text-slate-500">
              Balance: {fromToken.symbol === 'ETH' ? 'ETH Balance' : 'Token Balance'}
            </span>
          </div>
          <div className="flex gap-3">
            <select
              value={fromToken.symbol}
              onChange={(e) => setFromToken(MARKET_TOKENS.find(t => t.symbol === e.target.value) || MARKET_TOKENS[0])}
              className="bg-slate-700 text-white px-3 py-2 rounded-lg border border-slate-600"
            >
              {MARKET_TOKENS.map(token => (
                <option key={token.symbol} value={token.symbol}>
                  {token.logo} {token.symbol}
                </option>
              ))}
            </select>
            <Input
              type="number"
              placeholder="0.0"
              value={fromAmount}
              onChange={(e) => setFromAmount(e.target.value)}
              className="flex-1 bg-slate-700 border-slate-600 text-white text-right"
            />
          </div>
        </div>

        {/* Switch Button */}
        <div className="flex justify-center -my-2 relative z-10">
          <Button
            variant="outline"
            size="icon"
            onClick={switchTokens}
            className="rounded-full bg-slate-700 border-slate-600 hover:bg-slate-600"
          >
            <ArrowDown className="w-4 h-4 text-cyan-400" />
          </Button>
        </div>

        {/* To Token */}
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-slate-400">To</span>
            <span className="text-sm text-slate-500">Estimated</span>
          </div>
          <div className="flex gap-3">
            <select
              value={toToken.symbol}
              onChange={(e) => setToToken(MARKET_TOKENS.find(t => t.symbol === e.target.value) || MARKET_TOKENS[0])}
              className="bg-slate-700 text-white px-3 py-2 rounded-lg border border-slate-600"
            >
              {MARKET_TOKENS.map(token => (
                <option key={token.symbol} value={token.symbol}>
                  {token.logo} {token.symbol}
                </option>
              ))}
            </select>
            <Input
              type="text"
              placeholder="0.0"
              value={toAmount}
              readOnly
              className="flex-1 bg-slate-700 border-slate-600 text-white text-right"
            />
          </div>
        </div>

        {/* Swap Details */}
        {fromAmount && toAmount && (
          <div className="bg-slate-800/30 rounded-lg p-3 space-y-2 text-sm">
            <div className="flex justify-between text-slate-400">
              <span>Rate</span>
              <span className="text-white">
                1 {fromToken.symbol} ≈ {(parseFloat(toAmount) / parseFloat(fromAmount)).toFixed(6)} {toToken.symbol}
              </span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Slippage Tolerance</span>
              <span className="text-white">{slippage}%</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Network Fee</span>
              <span className="text-white">~$0.50</span>
            </div>
          </div>
        )}

        {/* Action Button */}
        {needsApproval ? (
          <Button
            onClick={handleApprove}
            disabled={isApproving || !fromAmount}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold hover:from-amber-400 hover:to-amber-500"
          >
            {isApproving ? 'Approving...' : `Approve ${fromToken.symbol}`}
          </Button>
        ) : (
          <Button
            onClick={handleSwap}
            disabled={isSwapping || !fromAmount || !toAmount}
            className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 text-white font-semibold hover:from-cyan-400 hover:to-cyan-500"
          >
            {isSwapping ? 'Swapping...' : swapSuccess ? 'Swap Successful!' : 'Swap'}
          </Button>
        )}

        {swapSuccess && (
          <div className="flex items-center gap-2 text-green-400 text-sm justify-center">
            <CheckCircle className="w-4 h-4" />
            Swap completed successfully!
          </div>
        )}

        {swapHash && (
          <a
            href={`${APP_CONFIG.network.explorer}/tx/${swapHash}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-cyan-400 hover:text-cyan-300 text-center block"
          >
            View on BaseScan →
          </a>
        )}
      </CardContent>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="bg-slate-900 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">Swap Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400">Slippage Tolerance</label>
              <div className="flex gap-2 mt-2">
                {[0.5, 1, 2, 3].map((val) => (
                  <Button
                    key={val}
                    variant={slippage === val ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSlippage(val)}
                    className={slippage === val ? 'bg-cyan-500' : 'border-slate-600'}
                  >
                    {val}%
                  </Button>
                ))}
              </div>
            </div>
            <div className="text-xs text-slate-500">
              <AlertTriangle className="w-4 h-4 inline mr-1" />
              Higher slippage increases success rate but may result in less favorable rates.
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

export default DexMarketplace;
