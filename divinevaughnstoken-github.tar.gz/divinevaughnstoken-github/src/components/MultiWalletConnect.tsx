import { useState } from 'react';
import { useAccount, useConnect, useDisconnect } from 'wagmi';
import { 
  Wallet, 
  X, 
  ChevronRight,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';

// Wallet icons (using emojis as placeholders - can be replaced with actual icons)
const WALLET_ICONS: Record<string, string> = {
  'MetaMask': '🦊',
  'WalletConnect': '🔗',
  'Coinbase Wallet': '📱',
  'Rainbow': '🌈',
  'Trust Wallet': '🔒',
  'Phantom': '👻',
  'OKX Wallet': '⭕',
  'Brave Wallet': '🦁',
};

interface MultiWalletConnectProps {
  onConnect?: () => void;
}

export function MultiWalletConnect({ onConnect }: MultiWalletConnectProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [connecting, setConnecting] = useState<string | null>(null);
  
  const { address, isConnected, connector } = useAccount();
  const { connect, connectors, error } = useConnect();
  const { disconnect } = useDisconnect();

  const handleConnect = async (connectorId: string) => {
    setConnecting(connectorId);
    const selectedConnector = connectors.find(c => c.id === connectorId);
    
    if (selectedConnector) {
      try {
        await connect({ connector: selectedConnector });
        setShowDialog(false);
        onConnect?.();
        toast.success('Wallet connected successfully!');
      } catch (err: any) {
        toast.error(err.message || 'Failed to connect wallet');
      }
    }
    setConnecting(null);
  };

  const handleDisconnect = () => {
    disconnect();
    toast.info('Wallet disconnected');
  };

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  // Filter out duplicate connectors and get unique ones
  const uniqueConnectors = connectors.filter((connector, index, self) => 
    index === self.findIndex(c => c.name === connector.name)
  );

  if (isConnected && address) {
    return (
      <Card className="w-full max-w-sm bg-gradient-to-br from-slate-900 to-slate-800 border-emerald-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <span className="text-xl">{WALLET_ICONS[connector?.name || 'MetaMask'] || '💼'}</span>
              </div>
              <div>
                <p className="text-white font-medium">{connector?.name}</p>
                <p className="text-sm text-emerald-400 font-mono">
                  {formatAddress(address)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
              <button 
                onClick={handleDisconnect}
                className="p-2 hover:bg-red-500/20 rounded-lg transition-colors"
                title="Disconnect"
              >
                <X className="w-4 h-4 text-red-400" />
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Button
        onClick={() => setShowDialog(true)}
        className="bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold hover:from-amber-400 hover:to-amber-500"
      >
        <Wallet className="w-4 h-4 mr-2" />
        Connect Wallet
      </Button>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-slate-900 border-slate-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white text-center">Connect Wallet</DialogTitle>
            <p className="text-slate-400 text-center text-sm">
              Choose your preferred wallet to connect
            </p>
          </DialogHeader>

          <div className="space-y-2 mt-4">
            {uniqueConnectors.map((connector) => {
              const isReady = connector.ready;
              const isConnecting = connecting === connector.id;
              
              return (
                <button
                  key={connector.id}
                  onClick={() => isReady && handleConnect(connector.id)}
                  disabled={!isReady || isConnecting}
                  className={`w-full p-4 rounded-xl border transition-all flex items-center justify-between ${
                    isReady 
                      ? 'bg-slate-800 border-slate-700 hover:border-amber-500/50 hover:bg-slate-700' 
                      : 'bg-slate-800/50 border-slate-800 opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center">
                      <span className="text-xl">
                        {WALLET_ICONS[connector.name] || '💼'}
                      </span>
                    </div>
                    <div className="text-left">
                      <p className="text-white font-medium">{connector.name}</p>
                      {!isReady && (
                        <p className="text-xs text-slate-500">Not installed</p>
                      )}
                    </div>
                  </div>
                  
                  {isConnecting ? (
                    <div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                  ) : isReady ? (
                    <ChevronRight className="w-5 h-5 text-slate-500" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-slate-600" />
                  )}
                </button>
              );
            })}
          </div>

          {error && (
            <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
              <p className="text-red-400 text-sm text-center">
                {error.message}
              </p>
            </div>
          )}

          <div className="mt-4 pt-4 border-t border-slate-800">
            <p className="text-xs text-slate-500 text-center">
              New to crypto?{' '}
              <a 
                href="https://metamask.io/download/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-amber-400 hover:text-amber-300"
              >
                Get MetaMask
              </a>
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default MultiWalletConnect;
