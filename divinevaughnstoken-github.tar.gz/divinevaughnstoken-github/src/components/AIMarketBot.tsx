import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { useDVTier, useBotAccess, useDynamicPricing } from '@/hooks/useDVTier';
import { CONSTANTS, formatDVAmount } from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Bot, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  Shield, 
  Zap,
  Timer,
  DollarSign,
  Lock,
  Crown,
  Star,
  Gem
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface BotSession {
  id: string;
  startTime: number;
  endTime: number;
  dvAmount: bigint;
  status: 'active' | 'expired' | 'cancelled';
}

const tierIcons: Record<number, typeof Crown> = {
  0: Lock,
  1: Star,
  2: Star,
  3: Crown,
  4: Gem,
};

const tierColors: Record<number, string> = {
  0: 'text-gray-400',
  1: 'text-amber-400',
  2: 'text-slate-300',
  3: 'text-yellow-400',
  4: 'text-cyan-400',
};

export function AIMarketBot() {
  const { isConnected } = useAccount();
  const { tier, tierName, balance, formattedBalance, hasBotAccess } = useDVTier();
  const { purchaseBotAccess, isPurchasing, isInCooldown } = useBotAccess();
  const { dvPriceUSD, isLoading: priceLoading, calculateDVForUSD } = useDynamicPricing();
  
  const [activeSession, setActiveSession] = useState<BotSession | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);

  const TierIcon = tierIcons[tier] || Lock;

  // Calculate DV needed for 2 hours (target $1 USD)
  const dvNeededForSession = calculateDVForUSD(1);

  // Check for active session and update timer
  useEffect(() => {
    if (!activeSession) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const remaining = Math.max(0, activeSession.endTime - now);
      setTimeRemaining(remaining);

      if (remaining === 0) {
        setActiveSession(null);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [activeSession]);

  // Handle purchase
  const handlePurchase = async () => {
    if (!hasBotAccess) return;
    
    const cooldown = isInCooldown();
    if (!cooldown.canPurchase) return;

    try {
      await purchaseBotAccess();
      
      const now = Date.now();
      const newSession: BotSession = {
        id: Math.random().toString(36).substr(2, 9),
        startTime: now,
        endTime: now + CONSTANTS.BOT_ACCESS_DURATION * 1000,
        dvAmount: dvNeededForSession,
        status: 'active',
      };

      setActiveSession(newSession);
      setShowPurchaseModal(false);
    } catch (error) {
      console.error('Purchase failed:', error);
    }
  };

  // Format time remaining
  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Check cooldown status
  const cooldownStatus = isInCooldown();

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Bot className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to access AI Market Bot</p>
        </CardContent>
      </Card>
    );
  }

  // Active session view
  if (activeSession && timeRemaining > 0) {
    return (
      <Card className="bg-white/[0.02] border-emerald-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <Bot className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <CardTitle className="text-white">AI Market Bot Active</CardTitle>
                <CardDescription className="text-emerald-400">
                  Your bot is running and analyzing markets
                </CardDescription>
              </div>
            </div>
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 animate-pulse">
              LIVE
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Timer */}
          <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-center">
            <p className="text-sm text-white/60 mb-2">Time Remaining</p>
            <p className="text-5xl font-bold text-emerald-400 font-mono">
              {formatTime(timeRemaining)}
            </p>
            <Progress 
              value={(timeRemaining / (CONSTANTS.BOT_ACCESS_DURATION * 1000)) * 100} 
              className="mt-4 h-2 bg-white/10"
            />
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-white/5 text-center">
              <TrendingUp className="w-5 h-5 text-aether-blue mx-auto mb-2" />
              <p className="text-lg font-semibold text-white">24</p>
              <p className="text-xs text-white/50">Signals Sent</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5 text-center">
              <Zap className="w-5 h-5 text-amber-400 mx-auto mb-2" />
              <p className="text-lg font-semibold text-emerald-400">+12.5%</p>
              <p className="text-xs text-white/50">Avg. ROI</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5 text-center">
              <Shield className="w-5 h-5 text-aether-purple mx-auto mb-2" />
              <p className="text-lg font-semibold text-white">98%</p>
              <p className="text-xs text-white/50">Accuracy</p>
            </div>
          </div>

          {/* Features */}
          <div className="space-y-2">
            <p className="text-sm text-white/60 mb-3">Active Features</p>
            {[
              'Real-time market analysis',
              'Trend detection algorithms',
              'Risk management alerts',
              'Entry/exit signal notifications',
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-white/70">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                {feature}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-aether-blue to-aether-purple flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">AI Market Bot</CardTitle>
                <CardDescription className="text-white/50">
                  Advanced trading signals powered by AI
                </CardDescription>
              </div>
            </div>
            <Badge className={`bg-white/10 ${tierColors[tier]}`}>
              <TierIcon className="w-3 h-3 mr-1" />
              {tierName}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Tier Requirement Info */}
          {!hasBotAccess && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-3">
                <Crown className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-400">Tier 3 Required</p>
                  <p className="text-sm text-white/60">
                    You need <span className="text-yellow-400 font-medium">Gold Tier (1,000+ DV)</span> to access the AI Market Bot
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Pricing Info */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-aether-blue/10 to-aether-purple/10 border border-aether-blue/20">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-aether-blue" />
                <span className="text-white font-medium">2 Hours Access</span>
              </div>
              <Badge variant="outline" className="border-emerald-500/30 text-emerald-400">
                <DollarSign className="w-3 h-3 mr-1" />
                $1.00 USD
              </Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Current DV Price</span>
                <span className="text-white">${dvPriceUSD.toFixed(4)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">DV Required</span>
                <span className="text-aether-blue font-semibold">
                  {formatDVAmount(dvNeededForSession)} DV
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Your Balance</span>
                <span className={balance >= dvNeededForSession ? 'text-emerald-400' : 'text-red-400'}>
                  {formattedBalance} DV
                </span>
              </div>
            </div>
          </div>

          {/* Cooldown Warning */}
          {cooldownStatus.inCooldown && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
              <div className="flex items-center gap-2 mb-2">
                <Timer className="w-5 h-5 text-red-400" />
                <span className="text-sm font-medium text-red-400">Cooldown Active</span>
              </div>
              <p className="text-sm text-white/60 mb-2">
                Please wait before purchasing again to prevent abuse
              </p>
              <p className="text-2xl font-bold text-red-400 font-mono">
                {formatTime(cooldownStatus.timeRemaining)}
              </p>
            </div>
          )}

          {/* Purchase Button */}
          <Button
            onClick={() => setShowPurchaseModal(true)}
            disabled={
              !hasBotAccess || 
              balance < dvNeededForSession || 
              cooldownStatus.inCooldown ||
              priceLoading
            }
            className="w-full bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90 disabled:opacity-50"
          >
            {priceLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                Loading Price...
              </>
            ) : cooldownStatus.inCooldown ? (
              <>
                <Timer className="w-4 h-4 mr-2" />
                Cooldown Active
              </>
            ) : balance < dvNeededForSession ? (
              <>
                <AlertTriangle className="w-4 h-4 mr-2" />
                Insufficient DV
              </>
            ) : !hasBotAccess ? (
              <>
                <Lock className="w-4 h-4 mr-2" />
                Tier 3 Required
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Purchase Access ({formatDVAmount(dvNeededForSession)} DV)
              </>
            )}
          </Button>

          {/* Features List */}
          <div className="space-y-2">
            <p className="text-sm text-white/60 mb-3">What You Get</p>
            {[
              'Real-time market analysis & signals',
              'AI-powered trend predictions',
              'Risk management recommendations',
              'Instant entry/exit alerts',
              'Portfolio optimization tips',
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-white/70">
                <CheckCircle className="w-4 h-4 text-aether-blue" />
                {feature}
              </div>
            ))}
          </div>

          {/* Tier Benefits */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <p className="text-sm text-white/60 mb-3">Tier Benefits</p>
            <div className="space-y-2">
              <div className={`flex items-center gap-2 text-sm ${tier >= 2 ? 'text-emerald-400' : 'text-white/40'}`}>
                <CheckCircle className="w-4 h-4" />
                Tier 2 (100 DV): Profile Creation
              </div>
              <div className={`flex items-center gap-2 text-sm ${tier >= 3 ? 'text-emerald-400' : 'text-white/40'}`}>
                <CheckCircle className="w-4 h-4" />
                Tier 3 (1,000 DV): AI Bot Access
              </div>
              <div className={`flex items-center gap-2 text-sm ${tier >= 4 ? 'text-emerald-400' : 'text-white/40'}`}>
                <CheckCircle className="w-4 h-4" />
                Tier 4 (10,000 DV): Premium Features
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Purchase Confirmation Modal */}
      <Dialog open={showPurchaseModal} onOpenChange={setShowPurchaseModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Confirm Purchase</DialogTitle>
            <DialogDescription className="text-white/60">
              You are about to purchase AI Market Bot access
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-white/5 space-y-3">
              <div className="flex justify-between">
                <span className="text-white/60">Duration</span>
                <span className="text-white font-medium">2 Hours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">USD Value</span>
                <span className="text-emerald-400 font-medium">$1.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">DV Amount</span>
                <span className="text-aether-blue font-medium">
                  {formatDVAmount(dvNeededForSession)} DV
                </span>
              </div>
              <div className="border-t border-white/10 pt-3 flex justify-between">
                <span className="text-white/60">Your Balance After</span>
                <span className="text-white font-medium">
                  {formatDVAmount(balance - dvNeededForSession)} DV
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="text-sm text-white/70">
                  <p className="font-medium text-amber-400 mb-1">Important</p>
                  <p>After purchase, you must wait 4 hours before buying again. 
                  Abuse detection is active to ensure fair usage.</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowPurchaseModal(false)}
                className="flex-1 border-white/10 hover:bg-white/5"
              >
                Cancel
              </Button>
              <Button
                onClick={handlePurchase}
                disabled={isPurchasing}
                className="flex-1 bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
              >
                {isPurchasing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  'Confirm Purchase'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
