import { useState, useEffect, useCallback } from 'react';
import { useAccount } from 'wagmi';
import { useDVTier } from '@/hooks/useDVTier';
import { 
  DV_ROUTER_ADDRESS,
  DV_TREASURY_ADDRESS,
  formatDVAmount
} from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Brain,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Shield,
  Activity,
  DollarSign,
  BarChart3,
  Settings,
  Zap,
  Lock,
  Unlock,
  Eye
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MarketMetrics {
  dvPriceUSD: number;
  totalSupply: bigint;
  circulatingSupply: bigint;
  treasuryBalance: bigint;
  dailySwapVolume: bigint;
  dailyFeesCollected: bigint;
  inflationRate: number;
  priceStability: number;
}

interface AIRecommendation {
  id: string;
  type: 'warning' | 'info' | 'action';
  title: string;
  description: string;
  action?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
}

// Mock market data - in production this would come from on-chain oracles/DEX APIs
const useMarketMetrics = () => {
  const [metrics] = useState<MarketMetrics>({
    dvPriceUSD: 0.001,
    totalSupply: 1000000000n * 10n ** 18n, // 1B DV
    circulatingSupply: 250000000n * 10n ** 18n, // 250M DV
    treasuryBalance: 5000000n * 10n ** 18n, // 5M DV
    dailySwapVolume: 10000000n * 10n ** 18n, // 10M DV
    dailyFeesCollected: 30000n * 10n ** 18n, // 30K DV (0.3%)
    inflationRate: 0.05, // 5% annual
    priceStability: 92, // 92% stable
  });

  const [isLoading, setIsLoading] = useState(false);

  const refetch = useCallback(async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
  }, []);

  return { metrics, isLoading, refetch };
};

// AI Recommendation Engine
const generateRecommendations = (metrics: MarketMetrics): AIRecommendation[] => {
  const recommendations: AIRecommendation[] = [];
  const now = Date.now();

  // Inflation monitoring
  if (metrics.inflationRate > 0.1) {
    recommendations.push({
      id: 'inf-1',
      type: 'warning',
      title: 'High Inflation Detected',
      description: `Current inflation rate (${(metrics.inflationRate * 100).toFixed(1)}%) exceeds safe threshold. Consider increasing swap fees or reducing rewards.`,
      action: 'Increase swap fee to 0.50%',
      severity: 'high',
      timestamp: now,
    });
  }

  // Price stability check
  if (metrics.priceStability < 80) {
    recommendations.push({
      id: 'price-1',
      type: 'warning',
      title: 'Price Volatility Alert',
      description: `DV price stability is at ${metrics.priceStability}%. High volatility may indicate liquidity issues.`,
      action: 'Add liquidity to primary pools',
      severity: 'medium',
      timestamp: now,
    });
  }

  // Treasury health
  const treasuryRatio = Number(metrics.treasuryBalance) / Number(metrics.totalSupply);
  if (treasuryRatio < 0.001) {
    recommendations.push({
      id: 'treasury-1',
      type: 'action',
      title: 'Treasury Balance Low',
      description: `Treasury holds only ${(treasuryRatio * 100).toFixed(3)}% of supply. Fees may need adjustment.`,
      action: 'Maintain current 0.30% fee',
      severity: 'medium',
      timestamp: now,
    });
  }

  // Volume analysis
  const volumeToSupplyRatio = Number(metrics.dailySwapVolume) / Number(metrics.circulatingSupply);
  if (volumeToSupplyRatio > 0.1) {
    recommendations.push({
      id: 'vol-1',
      type: 'info',
      title: 'High Trading Volume',
      description: `Daily volume is ${(volumeToSupplyRatio * 100).toFixed(1)}% of circulating supply. Market is active.`,
      severity: 'low',
      timestamp: now,
    });
  }

  // Optimal state
  if (recommendations.length === 0) {
    recommendations.push({
      id: 'opt-1',
      type: 'info',
      title: 'System Operating Optimally',
      description: 'All metrics are within healthy ranges. No immediate action required.',
      severity: 'low',
      timestamp: now,
    });
  }

  return recommendations;
};

export function AIAppManager() {
  const { isConnected } = useAccount();
  const { tier } = useDVTier();
  const { metrics, isLoading, refetch } = useMarketMetrics();
  
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [showRecommendationModal, setShowRecommendationModal] = useState(false);
  const [selectedRecommendation, setSelectedRecommendation] = useState<AIRecommendation | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionLog, setExecutionLog] = useState<string[]>([]);
  const [autoMode, setAutoMode] = useState(false);

  // Generate AI recommendations based on metrics
  useEffect(() => {
    const recs = generateRecommendations(metrics);
    setRecommendations(recs);
  }, [metrics]);

  // Auto-refresh metrics every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000);
    return () => clearInterval(interval);
  }, [refetch]);

  const handleExecuteAction = async (recommendation: AIRecommendation) => {
    setIsExecuting(true);
    setExecutionLog(prev => [...prev, `[${new Date().toLocaleTimeString()}] Executing: ${recommendation.action}...`]);
    
    // Simulate execution
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setExecutionLog(prev => [
      ...prev,
      `[${new Date().toLocaleTimeString()}] ✓ Action completed successfully`,
      `[${new Date().toLocaleTimeString()}] Parameters updated on-chain`
    ]);
    
    setIsExecuting(false);
    setShowRecommendationModal(false);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-500/20 border-red-500/30';
      case 'high': return 'text-orange-400 bg-orange-500/20 border-orange-500/30';
      case 'medium': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30';
      default: return 'text-emerald-400 bg-emerald-500/20 border-emerald-500/30';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertTriangle className="w-4 h-4" />;
      case 'action': return <Zap className="w-4 h-4" />;
      default: return <CheckCircle className="w-4 h-4" />;
    }
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Brain className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to access AI App Manager</p>
        </CardContent>
      </Card>
    );
  }

  // Only admin (Tier 4) can access AI Manager
  if (tier < 4) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Lock className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <p className="text-white font-medium mb-2">Platinum Tier Required</p>
          <p className="text-white/50">Only admin (10,000+ DV) can access AI App Manager</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-xl">AI App Manager</CardTitle>
                <CardDescription className="text-white/50">
                  Automated DV tokenomics monitoring & inflation control
                </CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge className={autoMode ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-white/60'}>
                {autoMode ? 'Auto-Mode ON' : 'Manual Mode'}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoMode(!autoMode)}
                className="border-white/10 hover:bg-white/5"
              >
                {autoMode ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-white/[0.02] border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="w-5 h-5 text-emerald-400" />
              <Badge className="bg-emerald-500/20 text-emerald-400">Live</Badge>
            </div>
            <p className="text-sm text-white/50 mb-1">DV Price</p>
            <p className="text-2xl font-bold text-white">${metrics.dvPriceUSD.toFixed(4)}</p>
            <p className="text-xs text-white/40 mt-1">Target: $0.001</p>
          </CardContent>
        </Card>

        <Card className="bg-white/[0.02] border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-5 h-5 text-amber-400" />
              <Badge className={metrics.inflationRate > 0.1 ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}>
                {metrics.inflationRate > 0.1 ? 'High' : 'Normal'}
              </Badge>
            </div>
            <p className="text-sm text-white/50 mb-1">Inflation Rate</p>
            <p className="text-2xl font-bold text-white">{(metrics.inflationRate * 100).toFixed(1)}%</p>
            <p className="text-xs text-white/40 mt-1">Annual</p>
          </CardContent>
        </Card>

        <Card className="bg-white/[0.02] border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <Shield className="w-5 h-5 text-purple-400" />
              <Badge className="bg-purple-500/20 text-purple-400">Protected</Badge>
            </div>
            <p className="text-sm text-white/50 mb-1">Price Stability</p>
            <p className="text-2xl font-bold text-white">{metrics.priceStability}%</p>
            <Progress value={metrics.priceStability} className="mt-2 h-1" />
          </CardContent>
        </Card>
      </div>

      {/* Supply Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-white/[0.02] border-white/10">
          <CardHeader>
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-aether-blue" />
              Supply Overview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-white/60">Total Supply</span>
              <span className="text-white font-medium">{formatDVAmount(metrics.totalSupply)} DV</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/60">Circulating</span>
              <span className="text-white font-medium">{formatDVAmount(metrics.circulatingSupply)} DV</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/60">Treasury</span>
              <span className="text-emerald-400 font-medium">{formatDVAmount(metrics.treasuryBalance)} DV</span>
            </div>
            <div className="pt-2 border-t border-white/10">
              <div className="flex justify-between items-center">
                <span className="text-white/60">Daily Swap Volume</span>
                <span className="text-aether-blue font-medium">{formatDVAmount(metrics.dailySwapVolume)} DV</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/60">Daily Fees (0.3%)</span>
              <span className="text-pink-400 font-medium">{formatDVAmount(metrics.dailyFeesCollected)} DV</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/[0.02] border-white/10">
          <CardHeader>
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Settings className="w-5 h-5 text-amber-400" />
              Swap Parameters
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between items-center mb-1">
                <span className="text-white/60 text-sm">Swap Fee</span>
                <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">Optimal</Badge>
              </div>
              <p className="text-white font-medium">0.30%</p>
              <p className="text-xs text-white/40">Recommended: 0.30%</p>
            </div>
            <div className="p-3 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between items-center mb-1">
                <span className="text-white/60 text-sm">Treasury Recipient</span>
                <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">Active</Badge>
              </div>
              <p className="text-white font-mono text-xs">{DV_TREASURY_ADDRESS.slice(0, 10)}...{DV_TREASURY_ADDRESS.slice(-8)}</p>
            </div>
            <div className="p-3 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between items-center mb-1">
                <span className="text-white/60 text-sm">Router Contract</span>
                <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">Verified</Badge>
              </div>
              <p className="text-white font-mono text-xs">{DV_ROUTER_ADDRESS.slice(0, 10)}...{DV_ROUTER_ADDRESS.slice(-8)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Recommendations */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              AI Recommendations
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              disabled={isLoading}
              className="border-white/10 hover:bg-white/5"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recommendations.map((rec) => (
              <div
                key={rec.id}
                className={`p-4 rounded-xl border ${getSeverityColor(rec.severity)} cursor-pointer hover:opacity-80 transition-opacity`}
                onClick={() => {
                  setSelectedRecommendation(rec);
                  setShowRecommendationModal(true);
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getTypeIcon(rec.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium">{rec.title}</p>
                      <Badge className={`text-xs ${getSeverityColor(rec.severity)}`}>
                        {rec.severity}
                      </Badge>
                    </div>
                    <p className="text-sm opacity-80">{rec.description}</p>
                    {rec.action && (
                      <p className="text-sm mt-2 font-medium">
                        Suggested: {rec.action}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Execution Log */}
      {executionLog.length > 0 && (
        <Card className="bg-white/[0.02] border-white/10">
          <CardHeader>
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Eye className="w-5 h-5 text-aether-blue" />
              Execution Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-32 rounded-lg bg-black/30 p-3">
              <div className="space-y-1 font-mono text-xs">
                {executionLog.map((log, i) => (
                  <p key={i} className="text-white/60">{log}</p>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Recommendation Modal */}
      <Dialog open={showRecommendationModal} onOpenChange={setShowRecommendationModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              {selectedRecommendation?.type === 'warning' ? (
                <AlertTriangle className="w-5 h-5 text-amber-400" />
              ) : (
                <Brain className="w-5 h-5 text-purple-400" />
              )}
              {selectedRecommendation?.title}
            </DialogTitle>
            <DialogDescription className="text-white/60">
              AI-Generated Recommendation
            </DialogDescription>
          </DialogHeader>

          {selectedRecommendation && (
            <div className="space-y-4 mt-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <p className="text-white/80">{selectedRecommendation.description}</p>
              </div>

              {selectedRecommendation.action && (
                <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20">
                  <p className="text-sm text-white/60 mb-1">Suggested Action</p>
                  <p className="text-white font-medium">{selectedRecommendation.action}</p>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowRecommendationModal(false)}
                  className="flex-1 border-white/10 hover:bg-white/5"
                >
                  Dismiss
                </Button>
                {selectedRecommendation.action && (
                  <Button
                    onClick={() => handleExecuteAction(selectedRecommendation)}
                    disabled={isExecuting}
                    className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:opacity-90"
                  >
                    {isExecuting ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Executing...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Execute
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
