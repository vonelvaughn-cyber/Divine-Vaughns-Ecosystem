import { useState, useCallback } from 'react';
import { useAccount } from 'wagmi';
import { useDVTier, useStaking } from '@/hooks/useDVTier';
import { CONSTANTS, formatDVAmount } from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Trophy, 
  Clock, 
  TrendingUp, 
  Lock, 
  AlertTriangle,
  CheckCircle,
  Users,
  Zap,
  Crown,
  Gem,
  Star,
  Award
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface StakingTier {
  id: string;
  name: string;
  duration: number;
  durationLabel: string;
  apr: number;
  minStake: bigint;
  color: string;
  icon: typeof Trophy;
}

const STAKING_TIERS: StakingTier[] = [
  {
    id: '3month',
    name: 'Silver Staker',
    duration: CONSTANTS.STAKING_PERIODS.THREE_MONTHS,
    durationLabel: '3 Months',
    apr: 5,
    minStake: 100n * 10n ** 18n,
    color: 'from-slate-400 to-slate-500',
    icon: Trophy,
  },
  {
    id: '6month',
    name: 'Gold Staker',
    duration: CONSTANTS.STAKING_PERIODS.SIX_MONTHS,
    durationLabel: '6 Months',
    apr: 10,
    minStake: 1000n * 10n ** 18n,
    color: 'from-amber-400 to-amber-500',
    icon: Trophy,
  },
  {
    id: '1year',
    name: 'Diamond Staker',
    duration: CONSTANTS.STAKING_PERIODS.ONE_YEAR,
    durationLabel: '1 Year',
    apr: 20,
    minStake: 10000n * 10n ** 18n,
    color: 'from-cyan-400 to-blue-500',
    icon: Trophy,
  },
];

// Mock leaderboard data
const LEADERBOARD = [
  { rank: 1, address: '0x742d...8a3e', amount: '500,000', tier: 'Diamond', reward: '100,000 DV' },
  { rank: 2, address: '0x8f3a...2b1c', amount: '350,000', tier: 'Diamond', reward: '70,000 DV' },
  { rank: 3, address: '0x1a9e...7d4f', amount: '200,000', tier: 'Gold', reward: '40,000 DV' },
  { rank: 4, address: '0x3c7b...9e2a', amount: '150,000', tier: 'Gold', reward: '30,000 DV' },
  { rank: 5, address: '0x9d2f...4c8b', amount: '100,000', tier: 'Silver', reward: '20,000 DV' },
];

const tierIcons: Record<number, typeof Crown> = {
  0: Lock,
  1: Star,
  2: Award,
  3: Crown,
  4: Gem,
};

const tierColors: Record<number, string> = {
  0: 'text-gray-400',
  1: 'text-amber-400',
  2: 'text-slate-300',
  3: 'text-yellow-400',
  4: 'text-cyan-400',
};

export function StakingCompetition() {
  const { isConnected } = useAccount();
  const { tier, tierName, balance, formattedBalance, hasProfileAccess } = useDVTier();
  const { stake, calculateRewards, isStaking } = useStaking();
  
  const [activeTab, setActiveTab] = useState('stake');
  const [selectedTier, setSelectedTier] = useState<StakingTier>(STAKING_TIERS[0]);
  const [stakeAmount, setStakeAmount] = useState('');
  const [showStakeModal, setShowStakeModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [estimatedReward, setEstimatedReward] = useState<bigint>(0n);

  const TierIcon = tierIcons[tier] || Lock;

  // Calculate estimated rewards
  const calculateEstimatedReward = useCallback((amount: string) => {
    if (!amount || isNaN(Number(amount))) {
      setEstimatedReward(0n);
      return;
    }
    const amountBigInt = BigInt(Math.floor(Number(amount) * 10 ** 18));
    const reward = calculateRewards(amountBigInt, selectedTier.duration);
    setEstimatedReward(reward);
  }, [selectedTier, calculateRewards]);

  const handleAmountChange = (value: string) => {
    setStakeAmount(value);
    calculateEstimatedReward(value);
  };

  const handleStake = async () => {
    if (!stakeAmount || !hasProfileAccess) return;
    
    const amountBigInt = BigInt(Math.floor(Number(stakeAmount) * 10 ** 18));
    
    try {
      await stake(amountBigInt, selectedTier.duration);
      setShowStakeModal(false);
      setShowSuccessModal(true);
      setStakeAmount('');
    } catch (error) {
      console.error('Staking error:', error);
    }
  };

  const formatDuration = (seconds: number) => {
    const days = Math.floor(seconds / (24 * 60 * 60));
    if (days >= 365) return `${Math.floor(days / 365)} Year${days >= 730 ? 's' : ''}`;
    if (days >= 30) return `${Math.floor(days / 30)} Months`;
    return `${days} Days`;
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Trophy className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to participate in staking</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/[0.02] border-white/10">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-white">Staking Competition</CardTitle>
              <CardDescription className="text-white/50">
                Earn rewards by holding and staking DV
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className={`bg-white/10 ${tierColors[tier]}`}>
              <TierIcon className="w-3 h-3 mr-1" />
              {tierName}
            </Badge>
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              <Zap className="w-3 h-3 mr-1" />
              Up to 20% APR
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full bg-white/5 border border-white/10 mb-6">
            <TabsTrigger value="stake" className="data-[state=active]:bg-white/10">
              <Lock className="w-4 h-4 mr-2" />
              Stake
            </TabsTrigger>
            <TabsTrigger value="tiers" className="data-[state=active]:bg-white/10">
              <TrendingUp className="w-4 h-4 mr-2" />
              Tiers
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="data-[state=active]:bg-white/10">
              <Users className="w-4 h-4 mr-2" />
              Leaderboard
            </TabsTrigger>
          </TabsList>

          {/* Stake Tab */}
          <TabsContent value="stake" className="space-y-6">
            {/* Tier Requirement Notice */}
            {!hasProfileAccess && (
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <div className="flex items-start gap-3">
                  <Lock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-amber-400">Tier 2 Required</p>
                    <p className="text-sm text-white/60">
                      You need <span className="text-slate-300 font-medium">Silver Tier (100+ DV)</span> to stake
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Balance Display */}
            <div className="p-4 rounded-xl bg-white/5">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <TierIcon className={`w-5 h-5 ${tierColors[tier]}`} />
                  <span className="text-white/60">{tierName} Member</span>
                </div>
                <span className="text-2xl font-bold text-white">{formattedBalance} DV</span>
              </div>
            </div>

            {/* Tier Selection */}
            <div className="space-y-3">
              <Label className="text-white/70">Select Staking Period</Label>
              <div className="grid grid-cols-3 gap-3">
                {STAKING_TIERS.map((stakingTier) => {
                  const Icon = stakingTier.icon;
                  const isLocked = tier < 2; // Need Tier 2+ to stake
                  return (
                    <button
                      key={stakingTier.id}
                      onClick={() => !isLocked && setSelectedTier(stakingTier)}
                      disabled={isLocked}
                      className={`p-4 rounded-xl border transition-all ${
                        isLocked 
                          ? 'bg-white/5 border-white/5 opacity-50 cursor-not-allowed'
                          : selectedTier.id === stakingTier.id
                            ? 'border-aether-blue bg-aether-blue/10'
                            : 'border-white/10 bg-white/5 hover:border-white/20'
                      }`}
                    >
                      <Icon className={`w-6 h-6 mx-auto mb-2 ${
                        selectedTier.id === stakingTier.id ? 'text-aether-blue' : 'text-white/50'
                      }`} />
                      <p className={`text-sm font-medium ${
                        selectedTier.id === stakingTier.id ? 'text-white' : 'text-white/70'
                      }`}>{stakingTier.durationLabel}</p>
                      <p className="text-xs text-emerald-400">{stakingTier.apr}% APR</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Tier Details */}
            <div className={`p-4 rounded-xl bg-gradient-to-br ${selectedTier.color} bg-opacity-10 border border-white/10`}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-white font-medium">{selectedTier.name}</span>
                <Badge className="bg-white/20 text-white">{selectedTier.apr}% APR</Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-white/60">Lock Period</span>
                  <span className="text-white">{formatDuration(selectedTier.duration)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Minimum Stake</span>
                  <span className="text-white">{formatDVAmount(selectedTier.minStake)} DV</span>
                </div>
              </div>
            </div>

            {/* Stake Amount Input */}
            <div className="space-y-3">
              <Label className="text-white/70">Stake Amount</Label>
              <div className="relative">
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={stakeAmount}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  disabled={!hasProfileAccess}
                  className="bg-white/5 border-white/10 text-white pr-16 disabled:opacity-50"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 text-sm">DV</span>
              </div>
              {hasProfileAccess && (
                <div className="flex justify-between text-sm">
                  <button 
                    onClick={() => handleAmountChange((Number(balance) / 10 ** 18 * 0.25).toFixed(2))}
                    className="text-aether-blue hover:underline"
                  >
                    25%
                  </button>
                  <button 
                    onClick={() => handleAmountChange((Number(balance) / 10 ** 18 * 0.5).toFixed(2))}
                    className="text-aether-blue hover:underline"
                  >
                    50%
                  </button>
                  <button 
                    onClick={() => handleAmountChange((Number(balance) / 10 ** 18 * 0.75).toFixed(2))}
                    className="text-aether-blue hover:underline"
                  >
                    75%
                  </button>
                  <button 
                    onClick={() => handleAmountChange((Number(balance) / 10 ** 18).toFixed(2))}
                    className="text-aether-blue hover:underline"
                  >
                    Max
                  </button>
                </div>
              )}
            </div>

            {/* Estimated Rewards */}
            {estimatedReward > 0n && hasProfileAccess && (
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <span className="text-sm font-medium text-emerald-400">Estimated Rewards</span>
                </div>
                <p className="text-2xl font-bold text-emerald-400">
                  {formatDVAmount(estimatedReward)} DV
                </p>
                <p className="text-sm text-white/60">
                  After {formatDuration(selectedTier.duration)} at {selectedTier.apr}% APR
                </p>
              </div>
            )}

            {/* Stake Button */}
            <Button
              onClick={() => setShowStakeModal(true)}
              disabled={
                !hasProfileAccess ||
                !stakeAmount ||
                Number(stakeAmount) <= 0 ||
                BigInt(Math.floor(Number(stakeAmount) * 10 ** 18)) > balance ||
                BigInt(Math.floor(Number(stakeAmount) * 10 ** 18)) < selectedTier.minStake
              }
              className="w-full bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90 disabled:opacity-50"
            >
              {!hasProfileAccess ? (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Tier 2 Required
                </>
              ) : !stakeAmount ? (
                'Enter Amount'
              ) : Number(stakeAmount) > 0 && BigInt(Math.floor(Number(stakeAmount) * 10 ** 18)) < selectedTier.minStake ? (
                <>
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Min {formatDVAmount(selectedTier.minStake)} DV Required
                </>
              ) : BigInt(Math.floor(Number(stakeAmount) * 10 ** 18)) > balance ? (
                <>
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Insufficient Balance
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Stake {stakeAmount} DV
                </>
              )}
            </Button>
          </TabsContent>

          {/* Tiers Tab */}
          <TabsContent value="tiers" className="space-y-4">
            {STAKING_TIERS.map((stakingTier) => {
              const Icon = stakingTier.icon;
              return (
                <div
                  key={stakingTier.id}
                  className={`p-6 rounded-xl bg-gradient-to-r ${stakingTier.color} bg-opacity-5 border border-white/10`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stakingTier.color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-white">{stakingTier.name}</h4>
                        <div className="flex items-center gap-4 mt-1">
                          <span className="flex items-center gap-1 text-sm text-white/60">
                            <Clock className="w-4 h-4" />
                            {stakingTier.durationLabel}
                          </span>
                          <span className="flex items-center gap-1 text-sm text-emerald-400">
                            <TrendingUp className="w-4 h-4" />
                            {stakingTier.apr}% APR
                          </span>
                        </div>
                      </div>
                    </div>
                    <Badge className="bg-white/10 text-white">
                      Min {formatDVAmount(stakingTier.minStake)} DV
                    </Badge>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-white/10">
                    <div className="flex justify-between text-sm">
                      <span className="text-white/60">Lock Period</span>
                      <span className="text-white">{formatDuration(stakingTier.duration)}</span>
                    </div>
                    <div className="flex justify-between text-sm mt-2">
                      <span className="text-white/60">Early Unstake Fee</span>
                      <span className="text-amber-400">10%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </TabsContent>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard" className="space-y-4">
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 mb-4">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                <span className="text-sm font-medium text-amber-400">Competition Active</span>
              </div>
              <p className="text-sm text-white/60 mt-1">
                Top stakers earn bonus rewards at the end of each period
              </p>
            </div>

            <div className="space-y-3">
              {LEADERBOARD.map((entry) => (
                <div
                  key={entry.rank}
                  className={`flex items-center justify-between p-4 rounded-xl ${
                    entry.rank === 1 
                      ? 'bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/30' 
                      : entry.rank === 2 
                        ? 'bg-gradient-to-r from-slate-400/20 to-slate-500/10 border border-slate-400/30'
                        : entry.rank === 3
                          ? 'bg-gradient-to-r from-orange-600/20 to-orange-700/10 border border-orange-600/30'
                          : 'bg-white/5 border border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                      entry.rank === 1 
                        ? 'bg-amber-500 text-white' 
                        : entry.rank === 2 
                          ? 'bg-slate-400 text-white'
                          : entry.rank === 3
                            ? 'bg-orange-600 text-white'
                            : 'bg-white/10 text-white'
                    }`}>
                      {entry.rank}
                    </div>
                    <div>
                      <p className="font-mono text-sm text-white">{entry.address}</p>
                      <Badge variant="outline" className="text-xs border-white/20 text-white/60">
                        {entry.tier}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-semibold">{entry.amount} DV</p>
                    <p className="text-xs text-emerald-400">+{entry.reward}</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Stake Confirmation Modal */}
      <Dialog open={showStakeModal} onOpenChange={setShowStakeModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Confirm Stake</DialogTitle>
            <DialogDescription className="text-white/60">
              Lock your DV tokens to earn rewards
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-white/5 space-y-3">
              <div className="flex justify-between">
                <span className="text-white/60">Tier</span>
                <span className="text-white font-medium">{selectedTier.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Amount</span>
                <span className="text-white font-medium">{stakeAmount} DV</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Lock Period</span>
                <span className="text-white font-medium">{formatDuration(selectedTier.duration)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">APR</span>
                <span className="text-emerald-400 font-medium">{selectedTier.apr}%</span>
              </div>
              <div className="border-t border-white/10 pt-3 flex justify-between">
                <span className="text-white/60">Est. Reward</span>
                <span className="text-emerald-400 font-medium">{formatDVAmount(estimatedReward)} DV</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-2">
                <Lock className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="text-sm text-white/70">
                  <p className="font-medium text-amber-400 mb-1">Lock Notice</p>
                  <p>Your tokens will be locked for {formatDuration(selectedTier.duration)}. 
                  Early withdrawal incurs a 10% fee.</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowStakeModal(false)}
                className="flex-1 border-white/10 hover:bg-white/5"
              >
                Cancel
              </Button>
              <Button
                onClick={handleStake}
                disabled={isStaking}
                className="flex-1 bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
              >
                {isStaking ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    Staking...
                  </>
                ) : (
                  'Confirm Stake'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Success Modal */}
      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white text-center">
          <div className="py-8">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Staking Successful!</h3>
            <p className="text-white/60 mb-4">
              You have successfully staked {stakeAmount} DV for {formatDuration(selectedTier.duration)}
            </p>
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <p className="text-sm text-white/60">Estimated Reward</p>
              <p className="text-2xl font-bold text-emerald-400">{formatDVAmount(estimatedReward)} DV</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
