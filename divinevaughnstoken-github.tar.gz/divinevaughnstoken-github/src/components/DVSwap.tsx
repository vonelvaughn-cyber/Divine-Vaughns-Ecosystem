import { useState, useCallback } from 'react';
import { useAccount } from 'wagmi';
import { useDVTier } from '@/hooks/useDVTier';
import { 
  DV_ROUTER_ADDRESS, 
  DV_TREASURY_ADDRESS,
  DV_ROUTER_ABI, 
  DV_TOKEN_ABI,
  TOKENS, 
  POOL_FEES, 
  formatDVAmount,
  formatTokenAmount,
  parseDVAmount,
  calculateSwapFee 
} from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowRightLeft, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Lock,
  RefreshCw,
  Percent,
  ArrowDown
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useReadContract, useWriteContract } from 'wagmi';

interface Token {
  symbol: string;
  name: string;
  address: string;
  decimals: number;
  logo: string;
}

const SUPPORTED_TOKENS: Token[] = [
  { 
    symbol: 'DV', 
    name: 'Divine Vaughns', 
    address: TOKENS.DV, 
    decimals: 18,
    logo: '💎'
  },
  { 
    symbol: 'WETH', 
    name: 'Wrapped ETH', 
    address: TOKENS.WETH, 
    decimals: 18,
    logo: 'Ξ'
  },
  { 
    symbol: 'USDC', 
    name: 'USD Coin', 
    address: TOKENS.USDC, 
    decimals: 6,
    logo: '$'
  },
  { 
    symbol: 'USDbC', 
    name: 'USD Base Coin', 
    address: TOKENS.USDbC, 
    decimals: 6,
    logo: '💵'
  },
];

export function DVSwap() {
  const { isConnected, address } = useAccount();
  const { balance: dvBalance, formattedBalance, hasSwapAccess } = useDVTier();
  
  const [fromToken, setFromToken] = useState<Token>(SUPPORTED_TOKENS[0]); // DV
  const [toToken, setToToken] = useState<Token>(SUPPORTED_TOKENS[2]); // USDC
  const [amountIn, setAmountIn] = useState('');
  const [amountOut, setAmountOut] = useState('');
  const [isCalculating, setIsCalculating] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Get token balance
  const { data: tokenBalance } = useReadContract({
    address: fromToken.address as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address && fromToken.symbol !== 'DV' },
  });

  // Get allowance
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: fromToken.address as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'allowance',
    args: address && DV_ROUTER_ADDRESS ? [address, DV_ROUTER_ADDRESS] : undefined,
    query: { enabled: isConnected && !!address },
  });

  const { writeContract: approveToken } = useWriteContract();
  const { writeContract: swapTokens } = useWriteContract();

  const currentBalance = fromToken.symbol === 'DV' ? dvBalance : (tokenBalance || 0n);
  const formattedCurrentBalance = fromToken.symbol === 'DV' 
    ? formattedBalance 
    : formatTokenAmount(tokenBalance || 0n, fromToken.decimals);

  // Calculate swap fee
  const feeAmount = amountIn ? calculateSwapFee(parseDVAmount(amountIn)) : 0n;
  const amountAfterFee = amountIn ? parseDVAmount(amountIn) - feeAmount : 0n;

  // Calculate expected output (mock for now)
  const calculateOutput = useCallback(async (input: string) => {
    if (!input || isNaN(Number(input))) {
      setAmountOut('');
      return;
    }
    
    setIsCalculating(true);
    
    // Mock calculation - in production this would call the DEX for a quote
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const inputAmount = parseFloat(input);
    let rate = 1;
    
    if (fromToken.symbol === 'DV' && toToken.symbol === 'USDC') {
      rate = 0.001; // 1 DV = $0.001
    } else if (fromToken.symbol === 'USDC' && toToken.symbol === 'DV') {
      rate = 1000; // $1 = 1000 DV
    } else if (fromToken.symbol === 'DV' && toToken.symbol === 'WETH') {
      rate = 0.0000003; // Approximate
    } else if (fromToken.symbol === 'WETH' && toToken.symbol === 'DV') {
      rate = 3333333;
    }
    
    const output = (inputAmount * rate * (1 - 0.003)).toFixed(6); // 0.3% fee
    setAmountOut(output);
    setIsCalculating(false);
  }, [fromToken, toToken]);

  const handleAmountChange = (value: string) => {
    setAmountIn(value);
    calculateOutput(value);
  };

  const switchTokens = () => {
    setFromToken(toToken);
    setToToken(fromToken);
    setAmountIn(amountOut);
    setAmountOut(amountIn);
  };

  const handleApprove = async () => {
    if (!amountIn) return;
    
    try {
      await approveToken({
        address: fromToken.address as `0x${string}`,
        abi: DV_TOKEN_ABI,
        functionName: 'approve',
        args: [DV_ROUTER_ADDRESS as `0x${string}`, parseDVAmount(amountIn)],
      });
      await refetchAllowance();
    } catch (error) {
      console.error('Approval error:', error);
    }
  };

  const handleSwap = async () => {
    if (!amountIn || !hasSwapAccess) return;
    
    setIsSwapping(true);
    
    try {
      // Use MEDIUM pool fee (0.3%) for all DV pairs as required by the router
      const poolFee = POOL_FEES.MEDIUM;

      await swapTokens({
        address: DV_ROUTER_ADDRESS as `0x${string}`,
        abi: DV_ROUTER_ABI,
        functionName: 'swapDVPair',
        args: [
          fromToken.address as `0x${string}`,
          toToken.address as `0x${string}`,
          poolFee,
          parseDVAmount(amountIn),
          0n, // amountOutMinimum - should be calculated in production
        ],
      });
      
      setShowConfirmModal(false);
      setShowSuccessModal(true);
      setAmountIn('');
      setAmountOut('');
    } catch (error) {
      console.error('Swap error:', error);
    } finally {
      setIsSwapping(false);
    }
  };

  const needsApproval = allowance !== undefined && parseDVAmount(amountIn || '0') > (allowance as bigint);

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <ArrowRightLeft className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to swap DV tokens</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                <ArrowRightLeft className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">DV Swap</CardTitle>
                <CardDescription className="text-white/50">
                  Swap DV with other tokens on Base
                </CardDescription>
              </div>
            </div>
            <Badge className="bg-pink-500/20 text-pink-400 border-pink-500/30">
              <Percent className="w-3 h-3 mr-1" />
              0.30% Fee
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Tier Requirement */}
          {!hasSwapAccess && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-400">Tier 2 Required</p>
                  <p className="text-sm text-white/60">
                    You need <span className="text-slate-300 font-medium">Silver Tier (100+ DV)</span> to swap
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* From Token */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex justify-between mb-2">
              <Label className="text-white/70">From</Label>
              <span className="text-sm text-white/50">
                Balance: {formattedCurrentBalance} {fromToken.symbol}
              </span>
            </div>
            <div className="flex gap-2">
              <select
                value={fromToken.symbol}
                onChange={(e) => {
                  const token = SUPPORTED_TOKENS.find(t => t.symbol === e.target.value);
                  if (token) setFromToken(token);
                }}
                disabled={!hasSwapAccess}
                className="px-3 py-2 rounded-lg bg-white/10 border border-white/10 text-white disabled:opacity-50"
              >
                {SUPPORTED_TOKENS.map(token => (
                  <option key={token.symbol} value={token.symbol} className="bg-aether-dark">
                    {token.logo} {token.symbol}
                  </option>
                ))}
              </select>
              <Input
                type="number"
                placeholder="0.0"
                value={amountIn}
                onChange={(e) => handleAmountChange(e.target.value)}
                disabled={!hasSwapAccess}
                className="flex-1 bg-transparent border-0 text-right text-2xl font-bold text-white placeholder:text-white/30 disabled:opacity-50"
              />
            </div>
            <div className="flex justify-end gap-2 mt-2">
              {['25%', '50%', '75%', 'Max'].map((pct) => (
                <button
                  key={pct}
                  onClick={() => {
                    const multiplier = pct === 'Max' ? 1 : parseInt(pct) / 100;
                    const maxAmount = Number(formattedCurrentBalance) * multiplier;
                    handleAmountChange(maxAmount.toFixed(6));
                  }}
                  disabled={!hasSwapAccess}
                  className="text-xs text-pink-400 hover:text-pink-300 disabled:opacity-50"
                >
                  {pct}
                </button>
              ))}
            </div>
          </div>

          {/* Switch Button */}
          <div className="flex justify-center -my-2 relative z-10">
            <button
              onClick={switchTokens}
              disabled={!hasSwapAccess}
              className="w-10 h-10 rounded-full bg-aether-dark border border-white/20 flex items-center justify-center hover:border-pink-500/50 hover:bg-pink-500/10 transition-all disabled:opacity-50"
            >
              <ArrowDown className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* To Token */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex justify-between mb-2">
              <Label className="text-white/70">To (estimated)</Label>
              {isCalculating && (
                <RefreshCw className="w-4 h-4 text-white/50 animate-spin" />
              )}
            </div>
            <div className="flex gap-2">
              <select
                value={toToken.symbol}
                onChange={(e) => {
                  const token = SUPPORTED_TOKENS.find(t => t.symbol === e.target.value);
                  if (token) setToToken(token);
                }}
                disabled={!hasSwapAccess}
                className="px-3 py-2 rounded-lg bg-white/10 border border-white/10 text-white disabled:opacity-50"
              >
                {SUPPORTED_TOKENS.filter(t => t.symbol !== fromToken.symbol).map(token => (
                  <option key={token.symbol} value={token.symbol} className="bg-aether-dark">
                    {token.logo} {token.symbol}
                  </option>
                ))}
              </select>
              <Input
                type="text"
                placeholder="0.0"
                value={amountOut}
                readOnly
                className="flex-1 bg-transparent border-0 text-right text-2xl font-bold text-white placeholder:text-white/30"
              />
            </div>
          </div>

          {/* Fee Info */}
          {amountIn && (
            <div className="p-4 rounded-xl bg-pink-500/10 border border-pink-500/20">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-white/60">Swap Fee (0.30%)</span>
                  <span className="text-pink-400">{formatDVAmount(feeAmount)} {fromToken.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Amount After Fee</span>
                  <span className="text-white">{formatDVAmount(amountAfterFee)} {fromToken.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Minimum Received</span>
                  <span className="text-white/80">{amountOut} {toToken.symbol}</span>
                </div>
                <div className="pt-2 mt-2 border-t border-white/10">
                  <div className="flex justify-between items-center">
                    <span className="text-white/40 text-xs">Fee Recipient (Treasury)</span>
                    <span className="text-white/40 text-xs font-mono">
                      {DV_TREASURY_ADDRESS.slice(0, 6)}...{DV_TREASURY_ADDRESS.slice(-4)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* DV Required Notice */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-pink-400" />
              <span className="text-sm font-medium text-white">DV Required in Swap</span>
            </div>
            <p className="text-sm text-white/60">
              One of the tokens in the pair must be DV. This ensures liquidity flows through the DV ecosystem.
            </p>
          </div>

          {/* Action Button */}
          {!hasSwapAccess ? (
            <Button
              disabled
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 opacity-50"
            >
              <Lock className="w-4 h-4 mr-2" />
              Tier 2 Required
            </Button>
          ) : needsApproval ? (
            <Button
              onClick={handleApprove}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:opacity-90"
            >
              Approve {fromToken.symbol}
            </Button>
          ) : (
            <Button
              onClick={() => setShowConfirmModal(true)}
              disabled={!amountIn || parseDVAmount(amountIn) > currentBalance}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:opacity-90 disabled:opacity-50"
            >
              {!amountIn ? (
                'Enter Amount'
              ) : parseDVAmount(amountIn) > currentBalance ? (
                <>
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Insufficient Balance
                </>
              ) : (
                <>
                  <ArrowRightLeft className="w-4 h-4 mr-2" />
                  Swap {fromToken.symbol} → {toToken.symbol}
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Confirm Swap Modal */}
      <Dialog open={showConfirmModal} onOpenChange={setShowConfirmModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Confirm Swap</DialogTitle>
            <DialogDescription className="text-white/60">
              Review your swap details
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-white/5 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-white/60">You Pay</span>
                <span className="text-white font-medium">{amountIn} {fromToken.symbol}</span>
              </div>
              <div className="flex justify-center">
                <ArrowDown className="w-5 h-5 text-white/50" />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">You Receive</span>
                <span className="text-white font-medium">{amountOut} {toToken.symbol}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white/5 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-white/60">Swap Fee (0.30%)</span>
                <span className="text-pink-400">{formatDVAmount(feeAmount)} {fromToken.symbol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Pool Fee Tier</span>
                <span className="text-white">0.3%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Route</span>
                <span className="text-white">{fromToken.symbol} → DV → {toToken.symbol}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="text-sm text-white/70">
                  <p className="font-medium text-amber-400 mb-1">Slippage Warning</p>
                  <p>Prices may change during transaction confirmation. Your swap will execute at the best available rate.</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 border-white/10 hover:bg-white/5"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSwap}
                disabled={isSwapping}
                className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:opacity-90"
              >
                {isSwapping ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Swapping...
                  </>
                ) : (
                  'Confirm Swap'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Success Modal */}
      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white text-center">
          <div className="py-8">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Swap Successful!</h3>
            <p className="text-white/60 mb-4">
              You swapped {amountIn} {fromToken.symbol} for {amountOut} {toToken.symbol}
            </p>
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <p className="text-sm text-white/60">Fee Paid</p>
              <p className="text-lg font-bold text-pink-400">{formatDVAmount(feeAmount)} {fromToken.symbol}</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
