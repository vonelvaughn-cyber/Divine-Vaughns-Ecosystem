import { useState } from 'react';
import { useAccount, useConnect, useDisconnect, useBalance } from 'wagmi';
import { injected } from 'wagmi/connectors';
import { Wallet, LogOut, ChevronDown, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { formatDVAmount } from '@/lib/web3';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

export function WalletConnect() {
  const { address, isConnected } = useAccount();
  const { connect, isPending: isConnecting } = useConnect();
  const { disconnect } = useDisconnect();
  const [showWalletModal, setShowWalletModal] = useState(false);

  // Get native BNB balance
  const { data: nativeBalance } = useBalance({
    address: address,
    query: {
      enabled: isConnected && !!address,
    },
  });

  // For DV token balance, we'll use a mock since the token might not be on the current chain
  const dvBalance = 0n; // This would be fetched from the contract in production

  const handleConnect = () => {
    setShowWalletModal(true);
  };

  const handleMetaMaskConnect = async () => {
    try {
      await connect({ connector: injected({ target: 'metaMask' }) });
      setShowWalletModal(false);
    } catch (error) {
      console.error('Connection error:', error);
    }
  };

  const handleDisconnect = () => {
    disconnect();
  };

  const truncateAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const getExplorerUrl = (addr: string) => {
    return `https://bscscan.com/address/${addr}`;
  };

  // If not connected, show connect button
  if (!isConnected) {
    return (
      <>
        <Button
          onClick={handleConnect}
          disabled={isConnecting}
          className="gap-2 bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
        >
          <Wallet className="w-4 h-4" />
          {isConnecting ? 'Connecting...' : 'Connect Wallet'}
        </Button>

        <Dialog open={showWalletModal} onOpenChange={setShowWalletModal}>
          <DialogContent className="bg-aether-dark border-white/10 text-white">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">Connect Wallet</DialogTitle>
              <DialogDescription className="text-white/60">
                Choose your preferred wallet to connect to Aether Platform
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3 mt-4">
              <button
                onClick={handleMetaMaskConnect}
                className="w-full p-4 rounded-xl bg-white/5 border border-white/10 hover:border-aether-blue/50 hover:bg-white/10 transition-all flex items-center gap-4"
              >
                <div className="w-10 h-10 rounded-lg bg-[#F6851B] flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                </div>
                <div className="text-left">
                  <p className="font-semibold text-white">MetaMask</p>
                  <p className="text-sm text-white/50">Connect using browser wallet</p>
                </div>
              </button>
              
              <button
                onClick={() => alert('WalletConnect coming soon!')}
                className="w-full p-4 rounded-xl bg-white/5 border border-white/10 hover:border-aether-purple/50 hover:bg-white/10 transition-all flex items-center gap-4 opacity-60"
              >
                <div className="w-10 h-10 rounded-lg bg-[#3B99FC] flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M4.91 7.52a10.18 10.18 0 0114.18 0l.47.46a.49.49 0 010 .7l-1.61 1.57a.49.49 0 01-.68 0l-.65-.64a7.1 7.1 0 00-9.84 0l-.69.68a.49.49 0 01-.68 0L4.44 8.68a.49.49 0 010-.7l.47-.46zM20.24 10.43l1.43 1.4a.49.49 0 010 .7l-6.44 6.3a.51.51 0 01-.71 0l-4.58-4.48a.13.13 0 00-.18 0l-4.58 4.48a.51.51 0 01-.71 0L.6 12.53a.49.49 0 010-.7l1.43-1.4a.51.51 0 01.71 0l4.58 4.48a.13.13 0 00.18 0l4.58-4.48a.51.51 0 01.71 0l4.58 4.48a.13.13 0 00.18 0l4.58-4.48a.51.51 0 01.71 0z"/>
                  </svg>
                </div>
                <div className="text-left">
                  <p className="font-semibold text-white">WalletConnect</p>
                  <p className="text-sm text-white/50">Scan with your mobile wallet</p>
                </div>
              </button>
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  // Connected state - show dropdown with wallet info
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2 border-white/10 bg-white/5 hover:bg-white/10">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="hidden sm:inline">{truncateAddress(address!)}</span>
          <ChevronDown className="w-4 h-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72 bg-aether-dark border-white/10 text-white">
        <div className="p-3">
          <p className="text-xs text-white/50 mb-1">Connected Address</p>
          <div className="flex items-center gap-2">
            <p className="font-mono text-sm">{address}</p>
            <a
              href={getExplorerUrl(address!)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-white/50 hover:text-white"
            >
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
        
        <DropdownMenuSeparator className="bg-white/10" />
        
        <div className="p-3 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-white/60">DV Balance</span>
            <span className="font-semibold text-aether-blue">
              {formatDVAmount(dvBalance)} DV
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-white/60">BNB Balance</span>
            <span className="font-semibold">
              {nativeBalance ? (Number(nativeBalance.value) / 10 ** 18).toFixed(4) : '0'} BNB
            </span>
          </div>
        </div>
        
        <DropdownMenuSeparator className="bg-white/10" />
        
        <DropdownMenuItem
          onClick={handleDisconnect}
          className="text-red-400 focus:text-red-400 focus:bg-red-500/10 cursor-pointer"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Disconnect Wallet
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
