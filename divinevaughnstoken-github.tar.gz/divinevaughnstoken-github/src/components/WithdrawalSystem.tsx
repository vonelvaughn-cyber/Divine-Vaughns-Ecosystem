import { useState, useEffect } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { 
  Banknote, 
  CreditCard, 
  ArrowRightLeft, 
  DollarSign,
  Bitcoin,
  Landmark,
  Smartphone,
  CheckCircle,
  Info,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { APP_CONFIG } from '@/config/app.config';
import { toast } from 'sonner';

// DV Token ABI
const DV_TOKEN_ABI = [
  {
    inputs: [
      { internalType: 'address', name: 'recipient', type: 'address' },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'transfer',
    outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'account', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'address', name: 'spender', type: 'address' },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'approve',
    outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function'
  }
] as const;

// Market prices (would come from oracle/API in production)
const MARKET_PRICES = {
  DV_USD: 0.001,
  ETH_USD: 3500,
  USDC_USD: 1,
};

// Withdrawal methods
const WITHDRAWAL_METHODS = {
  fiat: [
    { id: 'bank', name: 'Bank Transfer', icon: Landmark, feePercent: 1.5, minAmount: 100, maxAmount: 100000, processingTime: '1-3 business days' },
    { id: 'debit', name: 'Debit Card', icon: CreditCard, feePercent: 2.5, minAmount: 50, maxAmount: 10000, processingTime: 'Instant' },
    { id: 'cashapp', name: 'Cash App', icon: Smartphone, feePercent: 2.0, minAmount: 25, maxAmount: 5000, processingTime: 'Instant' },
    { id: 'paypal', name: 'PayPal', icon: DollarSign, feePercent: 3.0, minAmount: 50, maxAmount: 10000, processingTime: 'Instant' },
  ],
  crypto: [
    { id: 'usdc', name: 'USDC', icon: DollarSign, feePercent: 0.5, minAmount: 10, maxAmount: Infinity, processingTime: '~3 minutes' },
    { id: 'eth', name: 'ETH (Base)', icon: Bitcoin, feePercent: 0.3, minAmount: 5, maxAmount: Infinity, processingTime: '~3 minutes' },
  ]
};

// Calculate withdrawal fee based on amount and method
const calculateWithdrawalFee = (amountDV: number, methodFeePercent: number, ethPrice: number): {
  feeDV: number;
  feeUSD: number;
  netDV: number;
  netUSD: number;
} => {
  const dvPriceUSD = MARKET_PRICES.DV_USD;
  const amountUSD = amountDV * dvPriceUSD;
  
  // Base fee percentage
  let feePercent = methodFeePercent;
  
  // Volume discount: larger withdrawals get lower fees
  if (amountUSD >= 10000) feePercent *= 0.7; // 30% discount
  else if (amountUSD >= 5000) feePercent *= 0.8; // 20% discount
  else if (amountUSD >= 1000) feePercent *= 0.9; // 10% discount
  
  // ETH price adjustment: higher ETH = slightly lower fees (network congestion)
  const ethAdjustment = ethPrice > 4000 ? 0.95 : ethPrice > 3000 ? 1.0 : 1.05;
  feePercent *= ethAdjustment;
  
  const feeUSD = amountUSD * (feePercent / 100);
  const feeDV = feeUSD / dvPriceUSD;
  
  return {
    feeDV,
    feeUSD,
    netDV: amountDV - feeDV,
    netUSD: amountUSD - feeUSD
  };
};

// Convert DV to crypto amount
const convertDVToCrypto = (dvAmount: number, cryptoType: 'usdc' | 'eth'): number => {
  const dvValueUSD = dvAmount * MARKET_PRICES.DV_USD;
  if (cryptoType === 'usdc') return dvValueUSD;
  return dvValueUSD / MARKET_PRICES.ETH_USD;
};

export function WithdrawalSystem() {
  const { address, isConnected } = useAccount();
  const [activeTab, setActiveTab] = useState('fiat');
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [destination, setDestination] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [withdrawalComplete, setWithdrawalComplete] = useState(false);

  // Get DV balance
  const { data: dvBalance, refetch: refetchBalance } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  const balanceDV = dvBalance ? parseFloat(formatUnits(dvBalance, 18)) : 0;
  const balanceUSD = balanceDV * MARKET_PRICES.DV_USD;

  // Get selected method details
  const methodDetails = selectedMethod 
    ? [...WITHDRAWAL_METHODS.fiat, ...WITHDRAWAL_METHODS.crypto].find(m => m.id === selectedMethod)
    : null;

  // Calculate fees
  const withdrawalAmount = parseFloat(amount) || 0;
  const feeCalculation = methodDetails 
    ? calculateWithdrawalFee(withdrawalAmount, methodDetails.feePercent, MARKET_PRICES.ETH_USD)
    : null;

  const cryptoAmount = selectedMethod === 'usdc' || selectedMethod === 'eth'
    ? convertDVToCrypto(feeCalculation?.netDV || 0, selectedMethod as 'usdc' | 'eth')
    : 0;

  // Validation
  const isValidAmount = methodDetails && 
    withdrawalAmount >= methodDetails.minAmount && 
    withdrawalAmount <= methodDetails.maxAmount &&
    withdrawalAmount <= balanceDV;

  // Process withdrawal
  const { writeContract: transferDV, data: transferHash, error: transferError } = useWriteContract();
  const { isSuccess: transferConfirmed } = useWaitForTransactionReceipt({ hash: transferHash });

  useEffect(() => {
    if (transferConfirmed) {
      setIsProcessing(false);
      setWithdrawalComplete(true);
      refetchBalance();
      toast.success('Withdrawal processed successfully!');
    }
  }, [transferConfirmed, refetchBalance]);

  useEffect(() => {
    if (transferError) {
      setIsProcessing(false);
      toast.error('Withdrawal failed: ' + (transferError as Error).message);
    }
  }, [transferError]);

  const handleWithdraw = async () => {
    if (!isValidAmount || !methodDetails) return;
    
    setIsProcessing(true);
    
    // For crypto withdrawals, transfer to treasury/bridge contract
    // For fiat, this would trigger off-ramp service
    if (activeTab === 'crypto') {
      transferDV({
        address: APP_CONFIG.contracts.dvToken as `0x${string}`,
        abi: DV_TOKEN_ABI,
        functionName: 'transfer',
        args: [
          APP_CONFIG.contracts.treasury as `0x${string}`,
          parseUnits(withdrawalAmount.toString(), 18)
        ]
      });
    } else {
      // Fiat withdrawal - would integrate with off-ramp provider
      setTimeout(() => {
        setIsProcessing(false);
        setWithdrawalComplete(true);
        toast.success('Fiat withdrawal request submitted!');
      }, 2000);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 4
    }).format(value);
  };

  return (
    <TooltipProvider>
      <Card className="w-full max-w-2xl mx-auto bg-gradient-to-br from-slate-900 to-slate-800 border-emerald-500/30">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center mb-4">
            <Banknote className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl text-white">Withdraw Funds</CardTitle>
          <p className="text-slate-400 text-sm mt-2">
            Convert DV to USD or crypto and withdraw to your preferred method
          </p>
          
          {/* Balance Display */}
          <div className="mt-4 inline-flex items-center gap-4 px-6 py-3 bg-slate-800/50 rounded-xl">
            <div className="text-center">
              <p className="text-xs text-slate-400">Available Balance</p>
              <p className="text-xl font-bold text-amber-400">{balanceDV.toLocaleString()} DV</p>
            </div>
            <div className="w-px h-10 bg-slate-700" />
            <div className="text-center">
              <p className="text-xs text-slate-400">USD Value</p>
              <p className="text-xl font-bold text-emerald-400">{formatCurrency(balanceUSD)}</p>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full bg-slate-800/50">
              <TabsTrigger value="fiat" className="flex-1">
                <Landmark className="w-4 h-4 mr-2" />
                Fiat (USD)
              </TabsTrigger>
              <TabsTrigger value="crypto" className="flex-1">
                <Bitcoin className="w-4 h-4 mr-2" />
                Crypto
              </TabsTrigger>
            </TabsList>

            {/* Fiat Withdrawal */}
            <TabsContent value="fiat" className="space-y-4">
              <p className="text-sm text-slate-400">Select withdrawal method</p>
              
              <div className="grid grid-cols-2 gap-3">
                {WITHDRAWAL_METHODS.fiat.map((method) => {
                  const Icon = method.icon;
                  const isSelected = selectedMethod === method.id;
                  
                  return (
                    <button
                      key={method.id}
                      onClick={() => setSelectedMethod(method.id)}
                      className={`p-4 rounded-xl border transition-all text-left ${
                        isSelected
                          ? 'bg-emerald-500/10 border-emerald-500'
                          : 'bg-slate-800/50 border-slate-700 hover:border-emerald-500/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          isSelected ? 'bg-emerald-500/20' : 'bg-slate-700'
                        }`}>
                          <Icon className={`w-5 h-5 ${isSelected ? 'text-emerald-400' : 'text-slate-400'}`} />
                        </div>
                        <div>
                          <p className="text-white font-medium text-sm">{method.name}</p>
                          <p className="text-xs text-slate-500">{method.feePercent}% fee</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </TabsContent>

            {/* Crypto Withdrawal */}
            <TabsContent value="crypto" className="space-y-4">
              <p className="text-sm text-slate-400">Select cryptocurrency</p>
              
              <div className="grid grid-cols-2 gap-3">
                {WITHDRAWAL_METHODS.crypto.map((method) => {
                  const Icon = method.icon;
                  const isSelected = selectedMethod === method.id;
                  
                  return (
                    <button
                      key={method.id}
                      onClick={() => setSelectedMethod(method.id)}
                      className={`p-4 rounded-xl border transition-all text-left ${
                        isSelected
                          ? 'bg-purple-500/10 border-purple-500'
                          : 'bg-slate-800/50 border-slate-700 hover:border-purple-500/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          isSelected ? 'bg-purple-500/20' : 'bg-slate-700'
                        }`}>
                          <Icon className={`w-5 h-5 ${isSelected ? 'text-purple-400' : 'text-slate-400'}`} />
                        </div>
                        <div>
                          <p className="text-white font-medium text-sm">{method.name}</p>
                          <p className="text-xs text-slate-500">{method.feePercent}% fee</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </TabsContent>
          </Tabs>

          {/* Amount Input */}
          {selectedMethod && (
            <div className="space-y-4">
              <div className="bg-slate-800/50 rounded-xl p-4">
                <div className="flex justify-between mb-2">
                  <label className="text-sm text-slate-400">Amount (DV)</label>
                  <button 
                    onClick={() => setAmount(balanceDV.toString())}
                    className="text-xs text-amber-400 hover:text-amber-300"
                  >
                    MAX
                  </button>
                </div>
                <Input
                  type="number"
                  placeholder="0.0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white text-lg"
                />
                <p className="text-xs text-slate-500 mt-2">
                  Min: {methodDetails?.minAmount} DV | Max: {methodDetails?.maxAmount === Infinity ? 'No limit' : `${methodDetails?.maxAmount} DV`}
                </p>
              </div>

              {/* Destination Input */}
              <div className="space-y-2">
                <label className="text-sm text-slate-400">
                  {activeTab === 'fiat' ? 'Account Details' : 'Wallet Address'}
                </label>
                <Input
                  type="text"
                  placeholder={activeTab === 'fiat' ? 'Enter account/email' : '0x...'}
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              {/* Fee Breakdown */}
              {feeCalculation && (
                <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-400">You Send</span>
                    <span className="text-white">{withdrawalAmount.toLocaleString()} DV</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-400 flex items-center gap-1">
                      Fee ({methodDetails?.feePercent}%)
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="w-3 h-3 text-slate-500" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Fee varies based on amount and ETH price</p>
                        </TooltipContent>
                      </Tooltip>
                    </span>
                    <span className="text-amber-400">{feeCalculation.feeDV.toFixed(2)} DV ({formatCurrency(feeCalculation.feeUSD)})</span>
                  </div>

                  {activeTab === 'crypto' && (
                    <div className="flex justify-between">
                      <span className="text-sm text-slate-400">You'll Receive</span>
                      <span className="text-purple-400 font-semibold">
                        {cryptoAmount.toFixed(6)} {selectedMethod?.toUpperCase()}
                      </span>
                    </div>
                  )}

                  <div className="border-t border-slate-700 pt-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-white font-medium">Net Amount</span>
                      <div className="text-right">
                        <span className="text-lg font-bold text-emerald-400">
                          {feeCalculation.netDV.toFixed(2)} DV
                        </span>
                        <p className="text-xs text-slate-500">
                          ≈ {formatCurrency(feeCalculation.netUSD)}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Processing Time */}
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Info className="w-4 h-4" />
                Processing time: {methodDetails?.processingTime}
              </div>

              {/* Withdraw Button */}
              <Button
                onClick={() => setShowConfirm(true)}
                disabled={!isValidAmount || !destination}
                className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold hover:from-emerald-400 hover:to-emerald-500"
              >
                <ArrowRightLeft className="w-4 h-4 mr-2" />
                Withdraw
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent className="bg-slate-900 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white text-center">Confirm Withdrawal</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div className="bg-slate-800/50 rounded-xl p-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Method</span>
                <span className="text-white">{methodDetails?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Amount</span>
                <span className="text-white">{withdrawalAmount.toLocaleString()} DV</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Fee</span>
                <span className="text-amber-400">{feeCalculation?.feeDV.toFixed(2)} DV</span>
              </div>
              <div className="border-t border-slate-700 pt-2">
                <div className="flex justify-between">
                  <span className="text-white font-medium">Net Amount</span>
                  <span className="text-emerald-400 font-bold">{feeCalculation?.netDV.toFixed(2)} DV</span>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirm(false)}
                className="flex-1 border-slate-600 text-slate-400"
              >
                Cancel
              </Button>
              <Button
                onClick={handleWithdraw}
                disabled={isProcessing}
                className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
              >
                {isProcessing ? 'Processing...' : 'Confirm'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Success Dialog */}
      <Dialog open={withdrawalComplete} onOpenChange={setWithdrawalComplete}>
        <DialogContent className="bg-slate-900 border-emerald-500/50">
          <DialogHeader>
            <DialogTitle className="text-white text-center flex items-center justify-center gap-2">
              <CheckCircle className="w-6 h-6 text-emerald-400" />
              Withdrawal Complete
            </DialogTitle>
          </DialogHeader>
          
          <div className="text-center space-y-4 mt-4">
            <p className="text-slate-400">
              Your withdrawal of <span className="text-white font-semibold">{feeCalculation?.netDV.toFixed(2)} DV</span> has been processed.
            </p>
            
            {activeTab === 'fiat' ? (
              <p className="text-sm text-slate-500">
                Funds will arrive in your {methodDetails?.name} account within {methodDetails?.processingTime}.
              </p>
            ) : (
              <p className="text-sm text-slate-500">
                {cryptoAmount.toFixed(6)} {selectedMethod?.toUpperCase()} has been sent to your wallet.
              </p>
            )}

            {transferHash && (
              <a
                href={`${APP_CONFIG.network.explorer}/tx/${transferHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-emerald-400 hover:text-emerald-300 text-sm"
              >
                View Transaction
                <ExternalLink className="w-3 h-3" />
              </a>
            )}

            <Button
              onClick={() => {
                setWithdrawalComplete(false);
                setAmount('');
                setDestination('');
                setSelectedMethod(null);
              }}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
}

export default WithdrawalSystem;
