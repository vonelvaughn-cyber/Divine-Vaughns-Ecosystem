import { DV_LOGO_URL, AIC_LOGO_URL } from '@/lib/web3';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const sizeClasses = {
  sm: 'w-8 h-8',
  md: 'w-12 h-12',
  lg: 'w-20 h-20',
  xl: 'w-32 h-32',
};

export function DVLogo({ size = 'md', className = '' }: LogoProps) {
  return (
    <img
      src={DV_LOGO_URL}
      alt="Divine Vaughns (DV) Token"
      className={`${sizeClasses[size]} object-contain rounded-full ${className}`}
    />
  );
}

export function AICLogo({ size = 'md', className = '' }: LogoProps) {
  return (
    <img
      src={AIC_LOGO_URL}
      alt="AI Catalyst (AIC) Token"
      className={`${sizeClasses[size]} object-contain rounded-full ${className}`}
    />
  );
}

export function TokenPair({ size = 'md' }: LogoProps) {
  return (
    <div className="flex items-center -space-x-3">
      <DVLogo size={size} />
      <AICLogo size={size} className="ring-2 ring-aether-dark" />
    </div>
  );
}

export function LogoWithText({ size = 'lg' }: LogoProps) {
  return (
    <div className="flex flex-col items-center gap-4">
      <DVLogo size={size} />
      <div className="text-center">
        <h1 className="text-2xl font-bold text-white">Divine Vaughns</h1>
        <p className="text-white/50">DV & AIC Ecosystem</p>
      </div>
    </div>
  );
}
