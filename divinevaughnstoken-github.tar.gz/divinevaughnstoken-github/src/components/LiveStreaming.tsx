import { useState, useRef } from 'react';
import { useAccount } from 'wagmi';
import { useReadContract } from 'wagmi';
import { 
  DV_TOKEN_ADDRESS,
  DV_TOKEN_ABI,
  formatDVAmount,
  useDynamicPricing
} from '@/lib/web3';
import { useDVTier } from '@/hooks/useDVTier';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Video, 
  Radio,
  Users,
  TrendingUp,
  DollarSign,
  Play,
  Square,
  Heart,
  MessageCircle,
  Share2,
  Cloud
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface LiveStream {
  id: string;
  streamer: string;
  streamerTier: number;
  title: string;
  viewers: number;
  likes: number;
  isLive: boolean;
  thumbnail?: string;
}

interface StreamStats {
  duration: number; // seconds
  earnings: bigint;
  cloudRevenue: bigint;
  viewers: number;
  likes: number;
  comments: number;
}

// Mock live streams
const mockStreams: LiveStream[] = [
  {
    id: '1',
    streamer: 'CryptoKing',
    streamerTier: 4,
    title: 'DV Market Analysis Live - Breaking News!',
    viewers: 234,
    likes: 567,
    isLive: true,
  },
  {
    id: '2',
    streamer: 'DeFiQueen',
    streamerTier: 3,
    title: 'Staking Strategy Session - Ask Me Anything',
    viewers: 156,
    likes: 423,
    isLive: true,
  },
  {
    id: '3',
    streamer: 'BaseBuilder',
    streamerTier: 2,
    title: 'Building on Base Chain - Tutorial',
    viewers: 89,
    likes: 234,
    isLive: true,
  },
];

// Calculate live earnings based on DV market value
// Base: 0.11 DV/min to user, 0.01 DV/min to cloud
// As DV price increases, earnings in DV decrease to maintain reasonable USD value
const calculateLiveEarnings = (dvPriceUSD: number) => {
  // Target USD earnings per minute
  const targetUserEarningsUSD = 0.50; // ~$0.50/min to user
  const targetCloudRevenueUSD = 0.05; // ~$0.05/min to cloud
  
  // Calculate DV amounts based on current price
  let userEarningsDV = targetUserEarningsUSD / dvPriceUSD;
  let cloudRevenueDV = targetCloudRevenueUSD / dvPriceUSD;
  
  // Apply minimums to ensure meaningful earnings
  userEarningsDV = Math.max(userEarningsDV, 0.01); // Min 0.01 DV/min
  cloudRevenueDV = Math.max(cloudRevenueDV, 0.001); // Min 0.001 DV/min
  
  // Cap maximums to prevent excessive inflation
  userEarningsDV = Math.min(userEarningsDV, 1.0); // Max 1 DV/min
  cloudRevenueDV = Math.min(cloudRevenueDV, 0.1); // Max 0.1 DV/min
  
  return {
    userPerMinute: userEarningsDV,
    cloudPerMinute: cloudRevenueDV,
    userPerMinuteDV: BigInt(Math.floor(userEarningsDV * 10**18)),
    cloudPerMinuteDV: BigInt(Math.floor(cloudRevenueDV * 10**18)),
    userUSD: userEarningsDV * dvPriceUSD,
    cloudUSD: cloudRevenueDV * dvPriceUSD,
  };
};

export function LiveStreaming() {
  const { isConnected, address } = useAccount();
  const { hasProfileAccess } = useDVTier();
  const { dvPriceUSD, priceChange24h } = useDynamicPricing();

  const [isStreaming, setIsStreaming] = useState(false);
  const [streamTitle, _setStreamTitle] = useState('');
  const [showStartModal, setShowStartModal] = useState(false);
  const [stats, setStats] = useState<StreamStats>({
    duration: 0,
    earnings: 0n,
    cloudRevenue: 0n,
    viewers: 0,
    likes: 0,
    comments: 0,
  });
  
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const earningsRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Get DV balance
  const { data: dvBalance, refetch: refetchBalance } = useReadContract({
    address: DV_TOKEN_ADDRESS as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address },
  });

  // User DV balance available for future use
  dvBalance;

  // Calculate dynamic earnings
  const earnings = calculateLiveEarnings(dvPriceUSD);

  // Start streaming
  const handleStartStream = async () => {
    if (!streamTitle) return;
    
    setIsStreaming(true);
    setShowStartModal(false);
    setStats({
      duration: 0,
      earnings: 0n,
      cloudRevenue: 0n,
      viewers: Math.floor(Math.random() * 50) + 10,
      likes: 0,
      comments: 0,
    });

    // Duration timer
    intervalRef.current = setInterval(() => {
      setStats(prev => ({
        ...prev,
        duration: prev.duration + 1,
        viewers: prev.viewers + Math.floor(Math.random() * 3) - 1,
      }));
    }, 1000);

    // Earnings timer (every minute)
    earningsRef.current = setInterval(async () => {
      setStats(prev => ({
        ...prev,
        earnings: prev.earnings + earnings.userPerMinuteDV,
        cloudRevenue: prev.cloudRevenue + earnings.cloudPerMinuteDV,
      }));
      await refetchBalance();
    }, 60000);
  };

  // End streaming
  const handleEndStream = async () => {
    setIsStreaming(false);
    
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (earningsRef.current) clearInterval(earningsRef.current);

    // Final payout would happen here
    console.log('Stream ended. Total earnings:', formatDVAmount(stats.earnings));
  };

  // Format duration
  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getTierColor = (tierNum: number) => {
    const colors = ['gray', 'amber', 'slate', 'yellow', 'cyan'];
    return colors[tierNum] || 'gray';
  };

  const getTierName = (tierNum: number) => {
    const names = ['None', 'Bronze', 'Silver', 'Gold', 'Platinum'];
    return names[tierNum] || 'Unknown';
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Video className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to view live streams</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-br from-red-500/10 to-orange-500/10 border-red-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-orange-600 flex items-center justify-center">
                <Radio className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-xl">Live Streaming</CardTitle>
                <CardDescription className="text-white/50">
                  Go live & earn DV that scales with market value
                </CardDescription>
              </div>
            </div>
            {hasProfileAccess && !isStreaming && (
              <Button 
                onClick={() => setShowStartModal(true)}
                className="bg-gradient-to-r from-red-500 to-orange-600"
              >
                <Video className="w-4 h-4 mr-2" />
                Go Live
              </Button>
            )}
            {isStreaming && (
              <Button 
                onClick={handleEndStream}
                variant="destructive"
              >
                <Square className="w-4 h-4 mr-2" />
                End Stream
              </Button>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* Earnings Calculator */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            Dynamic Earnings Calculator
          </CardTitle>
          <CardDescription className="text-white/50">
            Earnings fluctuate with DV market value
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
              <p className="text-sm text-white/50 mb-1">Your Earnings</p>
              <p className="text-2xl font-bold text-emerald-400">{earnings.userPerMinute.toFixed(4)} DV</p>
              <p className="text-xs text-emerald-400/70">per minute</p>
              <p className="text-xs text-white/40 mt-1">~${earnings.userUSD.toFixed(3)}/min</p>
            </div>
            <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center">
              <p className="text-sm text-white/50 mb-1">Cloud Revenue</p>
              <p className="text-2xl font-bold text-blue-400">{earnings.cloudPerMinute.toFixed(4)} DV</p>
              <p className="text-xs text-blue-400/70">per minute</p>
              <p className="text-xs text-white/40 mt-1">~${earnings.cloudUSD.toFixed(3)}/min</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white/5">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-white/60">Current DV Price</span>
              <span className="text-white font-medium">${dvPriceUSD.toFixed(6)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-white/60">24h Change</span>
              <span className={`font-medium ${priceChange24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {priceChange24h >= 0 ? '+' : ''}{priceChange24h.toFixed(2)}%
              </span>
            </div>
            <p className="text-xs text-white/40 mt-2">
              As DV price increases, your earnings in DV decrease to maintain stable USD value. 
              This protects against inflation while ensuring fair compensation.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Active Stream (if streaming) */}
      {isStreaming && (
        <Card className="bg-gradient-to-br from-red-500/20 to-orange-500/20 border-red-500/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
              <span className="text-red-400 font-medium">LIVE</span>
              <span className="text-white/50">{formatDuration(stats.duration)}</span>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{stats.viewers}</p>
                <p className="text-xs text-white/50">Viewers</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-emerald-400">{formatDVAmount(stats.earnings)}</p>
                <p className="text-xs text-white/50">Earned</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-400">{formatDVAmount(stats.cloudRevenue)}</p>
                <p className="text-xs text-white/50">To Pool</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-pink-400">{stats.likes}</p>
                <p className="text-xs text-white/50">Likes</p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-black/30">
              <p className="text-white/70 text-sm">{streamTitle}</p>
            </div>

            <div className="flex gap-4 mt-4">
              <button className="flex items-center gap-1 text-white/50 hover:text-pink-400">
                <Heart className="w-5 h-5" />
                <span>Like</span>
              </button>
              <button className="flex items-center gap-1 text-white/50 hover:text-aether-blue">
                <MessageCircle className="w-5 h-5" />
                <span>Comment</span>
              </button>
              <button className="flex items-center gap-1 text-white/50 hover:text-emerald-400">
                <Share2 className="w-5 h-5" />
                <span>Share</span>
              </button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Live Streams Feed */}
      <div className="space-y-4">
        <h3 className="text-white font-medium flex items-center gap-2">
          <Radio className="w-4 h-4 text-red-400" />
          Live Now
        </h3>
        
        {mockStreams.map((stream) => (
          <Card key={stream.id} className="bg-white/[0.02] border-white/10 hover:border-white/20 transition-colors cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                {/* Thumbnail */}
                <div className="w-32 h-20 rounded-lg bg-gradient-to-br from-red-500/20 to-orange-500/20 flex items-center justify-center relative shrink-0">
                  <Play className="w-8 h-8 text-white/50" />
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-red-500 text-white text-xs font-medium flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    LIVE
                  </div>
                </div>

                {/* Stream Info */}
                <div className="flex-1">
                  <p className="text-white font-medium line-clamp-1">{stream.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Avatar className="w-6 h-6">
                      <AvatarFallback className={`bg-${getTierColor(stream.streamerTier)}-500/20 text-${getTierColor(stream.streamerTier)}-400 text-xs`}>
                        {stream.streamer.slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-white/70">{stream.streamer}</span>
                    <Badge className={`bg-${getTierColor(stream.streamerTier)}-500/20 text-${getTierColor(stream.streamerTier)}-400 text-xs`}>
                      {getTierName(stream.streamerTier)}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-sm text-white/50">
                    <span className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {stream.viewers}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {stream.likes}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Revenue Distribution */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <Cloud className="w-5 h-5 text-blue-400" />
            Revenue Distribution
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span className="text-white/70">Streamer Earnings</span>
            </div>
            <span className="text-emerald-400 font-medium">~91.7%</span>
          </div>
          <div className="flex justify-between items-center p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
            <div className="flex items-center gap-2">
              <Cloud className="w-4 h-4 text-blue-400" />
              <span className="text-white/70">DV Liquidation Pool</span>
            </div>
            <span className="text-blue-400 font-medium">~8.3%</span>
          </div>
          <p className="text-xs text-white/40">
            Cloud revenue (0.01 DV/min) goes directly to the DV liquidation pool, 
            increasing token value for all holders.
          </p>
        </CardContent>
      </Card>

      {/* Start Stream Modal */}
      <Dialog open={showStartModal} onOpenChange={setShowStartModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <Video className="w-6 h-6 text-red-400" />
              Go Live
            </DialogTitle>
            <DialogDescription className="text-white/60">
              Start streaming and earn DV that scales with market value
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <p className="text-sm text-white/60 mb-2">Your Earnings Rate</p>
              <div className="flex justify-between items-center">
                <span className="text-emerald-400 font-medium">{earnings.userPerMinute.toFixed(4)} DV/min</span>
                <span className="text-white/50">~${earnings.userUSD.toFixed(3)}/min</span>
              </div>
              <p className="text-xs text-white/40 mt-1">
                Rate fluctuates with DV market value
              </p>
            </div>

            <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <p className="text-sm text-white/60 mb-2">Cloud Contribution</p>
              <div className="flex justify-between items-center">
                <span className="text-blue-400 font-medium">{earnings.cloudPerMinute.toFixed(4)} DV/min</span>
                <span className="text-white/50">To liquidation pool</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowStartModal(false)}
                className="flex-1 border-white/10"
              >
                Cancel
              </Button>
              <Button
                onClick={handleStartStream}
                className="flex-1 bg-gradient-to-r from-red-500 to-orange-600"
              >
                <Radio className="w-4 h-4 mr-2" />
                Start Streaming
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
