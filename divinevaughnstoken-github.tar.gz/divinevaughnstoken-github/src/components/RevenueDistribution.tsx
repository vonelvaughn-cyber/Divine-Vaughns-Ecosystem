import { useState, useEffect } from 'react';
import { useReadContract } from 'wagmi';
import { formatUnits } from 'viem';
import { 
  PieChart, 
  TrendingUp, 
  Droplets, 
  Users, 
  Gift, 
  ArrowRightLeft,
  Send,
  Video,
  Wallet,
  RefreshCw,
  ExternalLink,
  CheckCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TooltipProvider } from '@/components/ui/tooltip';
import { APP_CONFIG } from '@/config/app.config';
import { DV_WETH_POOL_ADDRESS } from '@/lib/web3';

// Pool ABI for liquidity info
const POOL_ABI = [
  {
    inputs: [],
    name: 'liquidity',
    outputs: [{ internalType: 'uint128', name: '', type: 'uint128' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'feeGrowthGlobal0X128',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  }
] as const;

// Revenue sources from app fees
interface RevenueSource {
  id: string;
  name: string;
  icon: React.ElementType;
  feePercent: number;
  description: string;
  monthlyEstimate: number; // in DV
}

const REVENUE_SOURCES: RevenueSource[] = [
  {
    id: 'swap',
    name: 'DV Swap Fees',
    icon: ArrowRightLeft,
    feePercent: 0.3,
    description: '0.30% fee on every swap',
    monthlyEstimate: 50000
  },
  {
    id: 'transfer',
    name: 'Transfer Fees',
    icon: Send,
    feePercent: 0.5,
    description: 'Dynamic 0.05-0.5% on transfers',
    monthlyEstimate: 25000
  },
  {
    id: 'gifts',
    name: 'Gift Shop',
    icon: Gift,
    feePercent: 5,
    description: '5% platform fee on gifts',
    monthlyEstimate: 15000
  },
  {
    id: 'streaming',
    name: 'Live Streaming',
    icon: Video,
    feePercent: 8.3,
    description: '8.3% of streaming earnings',
    monthlyEstimate: 10000
  },
  {
    id: 'content',
    name: 'Content Coins',
    icon: Wallet,
    feePercent: 10,
    description: '10% on content coin sales',
    monthlyEstimate: 8000
  },
  {
    id: 'withdrawal',
    name: 'Withdrawal Fees',
    icon: TrendingUp,
    feePercent: 0.3,
    description: 'Portion of withdrawal fees',
    monthlyEstimate: 5000
  }
];

// DV Price in USD
const DV_PRICE_USD = 0.001;

export function RevenueDistribution() {
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [poolContribution, setPoolContribution] = useState(0);

  // Get pool liquidity
  const { data: poolLiquidity } = useReadContract({
    address: DV_WETH_POOL_ADDRESS as `0x${string}`,
    abi: POOL_ABI,
    functionName: 'liquidity',
    query: { enabled: true }
  });

  // Calculate totals
  useEffect(() => {
    const total = REVENUE_SOURCES.reduce((sum, source) => sum + source.monthlyEstimate, 0);
    setTotalRevenue(total);
    // 100% of fees go to pool
    setPoolContribution(total);
  }, []);

  const poolLiquidityDV = poolLiquidity ? parseFloat(formatUnits(poolLiquidity, 18)) : 394611;
  const monthlyContributionUSD = poolContribution * DV_PRICE_USD;
  const annualContributionUSD = monthlyContributionUSD * 12;

  return (
    <TooltipProvider>
      <div className="w-full max-w-4xl mx-auto space-y-6">
        {/* Hero Section */}
        <Card className="bg-gradient-to-br from-emerald-900/50 to-cyan-900/50 border-emerald-500/30">
          <CardContent className="p-8 text-center">
            <div className="mx-auto w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center mb-6">
              <Droplets className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">
              100% of Fees → DV/WETH Pool
            </h2>
            <p className="text-slate-300 max-w-xl mx-auto">
              Every fee collected from the app goes directly to the DV/WETH liquidity pool, 
              supporting creator earnings and DV value growth.
            </p>
            
            <div className="flex justify-center gap-4 mt-6">
              <a
                href={`https://app.uniswap.org/explore/pools/base/${DV_WETH_POOL_ADDRESS}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/20 text-emerald-400 rounded-lg hover:bg-emerald-500/30 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                View Pool on Uniswap
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Pool Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-slate-900 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-2">
                <Droplets className="w-5 h-5 text-emerald-400" />
                <span className="text-slate-400 text-sm">Pool Liquidity</span>
              </div>
              <p className="text-2xl font-bold text-white">
                {poolLiquidityDV.toLocaleString()} DV
              </p>
              <p className="text-slate-500 text-sm">
                ≈ ${(poolLiquidityDV * DV_PRICE_USD).toLocaleString()} USD
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="w-5 h-5 text-cyan-400" />
                <span className="text-slate-400 text-sm">Monthly Contribution</span>
              </div>
              <p className="text-2xl font-bold text-white">
                {poolContribution.toLocaleString()} DV
              </p>
              <p className="text-slate-500 text-sm">
                ≈ ${monthlyContributionUSD.toLocaleString()} USD
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-2">
                <RefreshCw className="w-5 h-5 text-amber-400" />
                <span className="text-slate-400 text-sm">Annual Projection</span>
              </div>
              <p className="text-2xl font-bold text-white">
                ${annualContributionUSD.toLocaleString()}
              </p>
              <p className="text-slate-500 text-sm">
                Estimated yearly pool growth
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Revenue Sources */}
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <PieChart className="w-5 h-5 text-emerald-400" />
              Revenue Sources
            </CardTitle>
            <p className="text-slate-400 text-sm">
              All fees collected from these sources go to the DV/WETH pool
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {REVENUE_SOURCES.map((source) => {
              const Icon = source.icon;
              const percentage = (source.monthlyEstimate / totalRevenue) * 100;
              
              return (
                <div key={source.id} className="bg-slate-800/50 rounded-xl p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-emerald-400" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-white font-medium">{source.name}</p>
                          <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                            {source.feePercent}% fee
                          </Badge>
                        </div>
                        <p className="text-slate-400 text-sm">{source.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-semibold">
                        {source.monthlyEstimate.toLocaleString()} DV/mo
                      </p>
                      <p className="text-slate-500 text-xs">
                        ≈ ${(source.monthlyEstimate * DV_PRICE_USD).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-slate-500 mb-1">
                      <span>Pool Contribution</span>
                      <span>{percentage.toFixed(1)}%</span>
                    </div>
                    <Progress value={percentage} className="h-2 bg-slate-700" />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">How Fees Support the Ecosystem</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-emerald-400" />
                </div>
                <h4 className="text-white font-medium mb-2">1. Users Transact</h4>
                <p className="text-slate-400 text-sm">
                  Every swap, transfer, gift, and stream generates fees
                </p>
              </div>

              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-3">
                  <Droplets className="w-6 h-6 text-cyan-400" />
                </div>
                <h4 className="text-white font-medium mb-2">2. Fees → Pool</h4>
                <p className="text-slate-400 text-sm">
                  100% of fees go to DV/WETH liquidity pool
                </p>
              </div>

              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6 text-amber-400" />
                </div>
                <h4 className="text-white font-medium mb-2">3. Value Grows</h4>
                <p className="text-slate-400 text-sm">
                  Increased liquidity supports DV price & creator earnings
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Benefits */}
        <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
          <CardContent className="p-6">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
              Benefits for Everyone
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2" />
                <div>
                  <p className="text-white font-medium">For Creators</p>
                  <p className="text-slate-400 text-sm">
                    Higher liquidity means better prices when converting DV to other assets
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2" />
                <div>
                  <p className="text-white font-medium">For Holders</p>
                  <p className="text-slate-400 text-sm">
                    Increased pool depth supports DV price stability and growth
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-amber-400 mt-2" />
                <div>
                  <p className="text-white font-medium">For Traders</p>
                  <p className="text-slate-400 text-sm">
                    Lower slippage and better execution on DV swaps
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full text-pink-400 mt-2" />
                <div>
                  <p className="text-white font-medium">For the Ecosystem</p>
                  <p className="text-slate-400 text-sm">
                    Sustainable growth through self-reinforcing liquidity
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pool Address */}
        <div className="text-center">
          <p className="text-slate-400 text-sm mb-2">DV/WETH Pool Address</p>
          <a
            href={`${APP_CONFIG.network.explorer}/address/${DV_WETH_POOL_ADDRESS}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-mono text-sm"
          >
            {DV_WETH_POOL_ADDRESS}
            <ExternalLink className="w-4 h-4" />
          </a>
          <p className="text-slate-500 text-xs mt-2">
            All fees are transparently added to this pool
          </p>
        </div>
      </div>
    </TooltipProvider>
  );
}

export default RevenueDistribution;
