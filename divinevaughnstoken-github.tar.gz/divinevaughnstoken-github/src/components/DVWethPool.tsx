import { useState, useEffect } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { 
  Droplets, 
  TrendingUp, 
  Plus, 
  DollarSign,
  ArrowRightLeft,
  Wallet,
  Percent,
  ExternalLink,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { APP_CONFIG } from '@/config/app.config';
import { DV_WETH_POOL_ADDRESS, DV_WETH_POOL_FEE } from '@/lib/web3';
import { toast } from 'sonner';

// Uniswap V3 Position Manager ABI (simplified)
const POSITION_MANAGER_ABI = [
  {
    inputs: [
      {
        components: [
          { internalType: 'address', name: 'token0', type: 'address' },
          { internalType: 'address', name: 'token1', type: 'address' },
          { internalType: 'uint24', name: 'fee', type: 'uint24' },
          { internalType: 'int24', name: 'tickLower', type: 'int24' },
          { internalType: 'int24', name: 'tickUpper', type: 'int24' },
          { internalType: 'uint256', name: 'amount0Desired', type: 'uint256' },
          { internalType: 'uint256', name: 'amount1Desired', type: 'uint256' },
          { internalType: 'uint256', name: 'amount0Min', type: 'uint256' },
          { internalType: 'uint256', name: 'amount1Min', type: 'uint256' },
          { internalType: 'address', name: 'recipient', type: 'address' },
          { internalType: 'uint256', name: 'deadline', type: 'uint256' }
        ],
        internalType: 'struct INonfungiblePositionManager.MintParams',
        name: 'params',
        type: 'tuple'
      }
    ],
    name: 'mint',
    outputs: [
      { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
      { internalType: 'uint128', name: 'liquidity', type: 'uint128' },
      { internalType: 'uint256', name: 'amount0', type: 'uint256' },
      { internalType: 'uint256', name: 'amount1', type: 'uint256' }
    ],
    stateMutability: 'payable',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
      { internalType: 'uint128', name: 'amount0Max', type: 'uint128' },
      { internalType: 'uint128', name: 'amount1Max', type: 'uint128' }
    ],
    name: 'collect',
    outputs: [
      { internalType: 'uint256', name: 'amount0', type: 'uint256' },
      { internalType: 'uint256', name: 'amount1', type: 'uint256' }
    ],
    stateMutability: 'payable',
    type: 'function'
  }
] as const;

// Uniswap V3 Position Manager on Base
const POSITION_MANAGER_ADDRESS = '0x03a520b32C04BF3bEEf7BEb72E919cf822Ed34f1';

// ERC20 ABI
const ERC20_ABI = [
  {
    inputs: [{ internalType: 'address', name: 'account', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'address', name: 'owner', type: 'address' },
      { internalType: 'address', name: 'spender', type: 'address' }
    ],
    name: 'allowance',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [
      { internalType: 'address', name: 'spender', type: 'address' },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'approve',
    outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  { inputs: [], name: 'decimals', outputs: [{ internalType: 'uint8', name: '', type: 'uint8' }], stateMutability: 'view', type: 'function' }
] as const;

// Pool slot0 for current price
const POOL_ABI = [
  {
    inputs: [],
    name: 'slot0',
    outputs: [
      { internalType: 'uint160', name: 'sqrtPriceX96', type: 'uint160' },
      { internalType: 'int24', name: 'tick', type: 'int24' },
      { internalType: 'uint16', name: 'observationIndex', type: 'uint16' },
      { internalType: 'uint16', name: 'observationCardinality', type: 'uint16' },
      { internalType: 'uint16', name: 'observationCardinalityNext', type: 'uint16' },
      { internalType: 'uint8', name: 'feeProtocol', type: 'uint8' },
      { internalType: 'bool', name: 'unlocked', type: 'bool' }
    ],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'liquidity',
    outputs: [{ internalType: 'uint128', name: '', type: 'uint128' }],
    stateMutability: 'view',
    type: 'function'
  },
  {
    inputs: [],
    name: 'fee',
    outputs: [{ internalType: 'uint24', name: '', type: 'uint24' }],
    stateMutability: 'view',
    type: 'function'
  }
] as const;

export function DVWethPool() {
  const { address, isConnected } = useAccount();
  const [activeTab, setActiveTab] = useState('overview');
  const [dvAmount, setDvAmount] = useState('');
  const [wethAmount, setWethAmount] = useState('');
  const [isApprovingDV, setIsApprovingDV] = useState(false);
  const [isApprovingWETH, setIsApprovingWETH] = useState(false);
  const [isAddingLiquidity, setIsAddingLiquidity] = useState(false);

  // Get pool info
  const { data: slot0 } = useReadContract({
    address: DV_WETH_POOL_ADDRESS as `0x${string}`,
    abi: POOL_ABI,
    functionName: 'slot0',
    query: { enabled: true }
  });

  const { data: poolLiquidity } = useReadContract({
    address: DV_WETH_POOL_ADDRESS as `0x${string}`,
    abi: POOL_ABI,
    functionName: 'liquidity',
    query: { enabled: true }
  });

  // Get token balances
  const { data: dvBalance } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  const { data: wethBalance } = useReadContract({
    address: '0x4200000000000000000000000000000000000006' as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  // Calculate current price from sqrtPriceX96
  const getCurrentPrice = () => {
    if (!slot0) return null;
    const sqrtPriceX96 = (slot0 as unknown as [bigint, number, number, number, number, number, boolean])[0];
    // Price = (sqrtPriceX96 / 2^96)^2
    const price = (Number(sqrtPriceX96) / (2 ** 96)) ** 2;
    // DV per WETH
    return price;
  };

  const currentPrice = getCurrentPrice();
  const dvPerWeth = currentPrice ? (1 / currentPrice).toFixed(0) : '2,062,280';

  // Calculate estimated WETH needed for DV amount
  useEffect(() => {
    if (dvAmount && currentPrice) {
      const dv = parseFloat(dvAmount);
      const wethNeeded = dv * currentPrice;
      setWethAmount(wethNeeded.toFixed(6));
    }
  }, [dvAmount, currentPrice]);

  // Check allowances
  const { data: dvAllowance, refetch: refetchDVAllowance } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: address ? [address, POSITION_MANAGER_ADDRESS] : undefined,
    query: { enabled: isConnected }
  });

  const { data: wethAllowance, refetch: refetchWETHAllowance } = useReadContract({
    address: '0x4200000000000000000000000000000000000006' as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: address ? [address, POSITION_MANAGER_ADDRESS] : undefined,
    query: { enabled: isConnected }
  });

  // Approval functions
  const { writeContract: approveDV, data: approveDVHash } = useWriteContract();
  const { isSuccess: dvApproveSuccess } = useWaitForTransactionReceipt({ hash: approveDVHash });

  const { writeContract: approveWETH, data: approveWETHHash } = useWriteContract();
  const { isSuccess: wethApproveSuccess } = useWaitForTransactionReceipt({ hash: approveWETHHash });

  useEffect(() => {
    if (dvApproveSuccess) {
      setIsApprovingDV(false);
      refetchDVAllowance();
      toast.success('DV approved for liquidity');
    }
  }, [dvApproveSuccess, refetchDVAllowance]);

  useEffect(() => {
    if (wethApproveSuccess) {
      setIsApprovingWETH(false);
      refetchWETHAllowance();
      toast.success('WETH approved for liquidity');
    }
  }, [wethApproveSuccess, refetchWETHAllowance]);

  const handleApproveDV = () => {
    if (!dvAmount) return;
    setIsApprovingDV(true);
    approveDV({
      address: APP_CONFIG.contracts.dvToken as `0x${string}`,
      abi: ERC20_ABI,
      functionName: 'approve',
      args: [POSITION_MANAGER_ADDRESS, parseUnits(dvAmount, 18)]
    });
  };

  const handleApproveWETH = () => {
    if (!wethAmount) return;
    setIsApprovingWETH(true);
    approveWETH({
      address: '0x4200000000000000000000000000000000000006' as `0x${string}`,
      abi: ERC20_ABI,
      functionName: 'approve',
      args: [POSITION_MANAGER_ADDRESS, parseUnits(wethAmount, 18)]
    });
  };

  // Add liquidity
  const { writeContract: mintPosition, data: mintHash, error: mintError } = useWriteContract();
  const { isSuccess: mintSuccess } = useWaitForTransactionReceipt({ hash: mintHash });

  useEffect(() => {
    if (mintSuccess) {
      setIsAddingLiquidity(false);
      setDvAmount('');
      setWethAmount('');
      toast.success('Liquidity added successfully!');
    }
  }, [mintSuccess]);

  useEffect(() => {
    if (mintError) {
      setIsAddingLiquidity(false);
      toast.error('Failed to add liquidity: ' + (mintError as Error).message);
    }
  }, [mintError]);

  const handleAddLiquidity = () => {
    if (!dvAmount || !wethAmount || !address) return;
    setIsAddingLiquidity(true);

    // Full range position (min and max ticks)
    const tickLower = -887220;
    const tickUpper = 887220;

    mintPosition({
      address: POSITION_MANAGER_ADDRESS as `0x${string}`,
      abi: POSITION_MANAGER_ABI,
      functionName: 'mint',
      args: [{
        token0: APP_CONFIG.contracts.dvToken as `0x${string}`,
        token1: '0x4200000000000000000000000000000000000006' as `0x${string}`,
        fee: DV_WETH_POOL_FEE,
        tickLower,
        tickUpper,
        amount0Desired: parseUnits(dvAmount, 18),
        amount1Desired: parseUnits(wethAmount, 18),
        amount0Min: 0n,
        amount1Min: 0n,
        recipient: address,
        deadline: BigInt(Math.floor(Date.now() / 1000) + 300)
      }],
      value: 0n
    });
  };

  const needsDVApproval = dvAllowance !== undefined && dvAmount && BigInt(dvAllowance) < parseUnits(dvAmount, 18);
  const needsWETHApproval = wethAllowance !== undefined && wethAmount && BigInt(wethAllowance) < parseUnits(wethAmount, 18);

  const formatBalance = (value: bigint | undefined, decimals: number = 18) => {
    if (!value) return '0';
    return parseFloat(formatUnits(value, decimals)).toFixed(4);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto bg-gradient-to-br from-slate-900 to-slate-800 border-emerald-500/30">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mb-4">
            <Droplets className="w-8 h-8 text-emerald-400" />
          </div>
          <CardTitle className="text-2xl text-white">DV/WETH Pool</CardTitle>
          <p className="text-slate-400 text-sm mt-2">
            Provide liquidity to earn trading fees from DV/WETH swaps
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full bg-slate-800/50">
              <TabsTrigger value="overview" className="flex-1">Overview</TabsTrigger>
              <TabsTrigger value="add" className="flex-1">Add Liquidity</TabsTrigger>
              <TabsTrigger value="manage" className="flex-1">Manage</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Pool Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-800/50 rounded-xl p-4 text-center">
                  <p className="text-sm text-slate-400 mb-1">Current Price</p>
                  <p className="text-xl font-bold text-emerald-400">
                    {parseInt(dvPerWeth).toLocaleString()} DV
                  </p>
                  <p className="text-xs text-slate-500">= 1 WETH</p>
                </div>
                <div className="bg-slate-800/50 rounded-xl p-4 text-center">
                  <p className="text-sm text-slate-400 mb-1">Pool Fee</p>
                  <p className="text-xl font-bold text-cyan-400">0.3%</p>
                  <p className="text-xs text-slate-500">Per trade</p>
                </div>
              </div>

              <div className="bg-slate-800/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-slate-300 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    Total Liquidity
                  </span>
                  <Badge className="bg-emerald-500/20 text-emerald-400">
                    {poolLiquidity ? formatUnits(poolLiquidity, 18).split('.')[0] : '394,611'} DV
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-300 flex items-center gap-2">
                    <Wallet className="w-4 h-4 text-purple-400" />
                    WETH in Pool
                  </span>
                  <Badge className="bg-purple-500/20 text-purple-400">
                    0.195 WETH (~$384)
                  </Badge>
                </div>
              </div>

              {/* Pool Info */}
              <div className="bg-slate-800/30 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">Pool Address</span>
                  <a 
                    href={`${APP_CONFIG.network.explorer}/address/${DV_WETH_POOL_ADDRESS}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                  >
                    {DV_WETH_POOL_ADDRESS.slice(0, 6)}...{DV_WETH_POOL_ADDRESS.slice(-4)}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">View on Uniswap</span>
                  <a 
                    href={`https://app.uniswap.org/explore/pools/base/${DV_WETH_POOL_ADDRESS}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-pink-400 hover:text-pink-300 flex items-center gap-1"
                  >
                    Open Uniswap
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* How It Works */}
              <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 rounded-xl p-4 border border-emerald-500/20">
                <h4 className="text-sm font-medium text-white mb-3">How LP Works</h4>
                <div className="space-y-2 text-sm text-slate-400">
                  <div className="flex items-start gap-2">
                    <Plus className="w-4 h-4 text-emerald-400 mt-0.5" />
                    <span>Add DV and WETH to the pool in equal value</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Percent className="w-4 h-4 text-cyan-400 mt-0.5" />
                    <span>Earn 0.3% fee on every swap through the pool</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <DollarSign className="w-4 h-4 text-green-400 mt-0.5" />
                    <span>Collect fees anytime - no lock period</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Add Liquidity Tab */}
            <TabsContent value="add" className="space-y-6">
              {!isConnected ? (
                <div className="text-center py-8">
                  <p className="text-slate-400">Connect your wallet to add liquidity</p>
                </div>
              ) : (
                <>
                  {/* DV Input */}
                  <div className="bg-slate-800/50 rounded-xl p-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-slate-400">DV Amount</span>
                      <span className="text-sm text-slate-500">
                        Balance: {formatBalance(dvBalance as bigint)} DV
                      </span>
                    </div>
                    <div className="flex gap-3">
                      <Input
                        type="number"
                        placeholder="0.0"
                        value={dvAmount}
                        onChange={(e) => setDvAmount(e.target.value)}
                        className="flex-1 bg-slate-700 border-slate-600 text-white"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => dvBalance && setDvAmount(formatUnits(dvBalance, 18))}
                        className="border-slate-600 text-slate-300"
                      >
                        MAX
                      </Button>
                    </div>
                  </div>

                  {/* Arrow */}
                  <div className="flex justify-center">
                    <ArrowRightLeft className="w-5 h-5 text-slate-500 rotate-90" />
                  </div>

                  {/* WETH Input */}
                  <div className="bg-slate-800/50 rounded-xl p-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-slate-400">WETH Amount</span>
                      <span className="text-sm text-slate-500">
                        Balance: {formatBalance(wethBalance as bigint)} WETH
                      </span>
                    </div>
                    <Input
                      type="number"
                      placeholder="0.0"
                      value={wethAmount}
                      readOnly
                      className="w-full bg-slate-700 border-slate-600 text-white"
                    />
                    <p className="text-xs text-slate-500 mt-2">
                      Auto-calculated based on current pool price
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    {needsDVApproval ? (
                      <Button
                        onClick={handleApproveDV}
                        disabled={isApprovingDV || !dvAmount}
                        className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold"
                      >
                        {isApprovingDV ? 'Approving DV...' : 'Approve DV'}
                      </Button>
                    ) : needsWETHApproval ? (
                      <Button
                        onClick={handleApproveWETH}
                        disabled={isApprovingWETH || !wethAmount}
                        className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold"
                      >
                        {isApprovingWETH ? 'Approving WETH...' : 'Approve WETH'}
                      </Button>
                    ) : (
                      <Button
                        onClick={handleAddLiquidity}
                        disabled={isAddingLiquidity || !dvAmount || !wethAmount}
                        className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold"
                      >
                        {isAddingLiquidity ? 'Adding Liquidity...' : 'Add Liquidity'}
                      </Button>
                    )}

                    {mintHash && (
                      <a
                        href={`${APP_CONFIG.network.explorer}/tx/${mintHash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-emerald-400 hover:text-emerald-300 text-center block"
                      >
                        View on BaseScan →
                      </a>
                    )}
                  </div>
                </>
              )}
            </TabsContent>

            {/* Manage Tab */}
            <TabsContent value="manage" className="space-y-6">
              <div className="text-center py-8">
                <Info className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                <p className="text-slate-400 mb-2">Manage your LP positions</p>
                <p className="text-sm text-slate-500">
                  View and manage your liquidity positions on Uniswap
                </p>
                <a
                  href={`https://app.uniswap.org/pool?chain=base`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-pink-500/20 text-pink-400 rounded-lg hover:bg-pink-500/30 transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  Open Uniswap Pool Manager
                </a>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
  );
}

export default DVWethPool;
