import { useState, useRef, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { useReadContract, useWriteContract } from 'wagmi';
import { 
  AIC_TOKEN_ADDRESS, 
  DV_AI_ENGINE_ADDRESS,
  AIC_TOKEN_ABI,
  DV_AI_ENGINE_ABI,
  CONSTANTS,
  formatTokenAmount,
  useDynamicPricing
} from '@/lib/web3';
import { useDVTier } from '@/hooks/useDVTier';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  Send, 
  Flame, 
  Coins,
  AlertTriangle,
  CheckCircle,
  Loader2,
  Bot,
  User,
  TrendingUp,
  Lock,
  Newspaper,
  Search,
  Activity,
  Zap
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  aicBurned?: bigint;
  type?: 'trading' | 'news' | 'price' | 'general';
}

// AI Topics - Open search for news, trading, and price guidance
const ALLOWED_TOPICS = [
  'trading', 'market', 'price', 'news', 'crypto', 'bitcoin', 'ethereum',
  'analysis', 'prediction', 'trend', 'volume', 'liquidity', 'swap',
  'staking', 'dv', 'aic', 'divine vaughns', 'ai catalyst',
  'portfolio', 'investment', 'strategy', 'chart', 'technical'
];

// Check if question is about allowed topics
const isAllowedTopic = (question: string): boolean => {
  const lowerQ = question.toLowerCase();
  return ALLOWED_TOPICS.some(topic => lowerQ.includes(topic)) || question.length > 5;
};

// Mock news data
const mockNews = [
  { title: "DV Swap Volume Hits New All-Time High", source: "CryptoDaily", time: "2h ago", sentiment: "bullish" },
  { title: "AI Catalyst Burn Rate Accelerates", source: "DeFi Pulse", time: "4h ago", sentiment: "bullish" },
  { title: "Base Chain Sees Record User Growth", source: "Blockchain News", time: "6h ago", sentiment: "neutral" },
  { title: "DV Tier System Drives Token Demand", source: "TokenInsight", time: "8h ago", sentiment: "bullish" },
  { title: "New Staking Competition Launches", source: "DV Official", time: "12h ago", sentiment: "bullish" },
];

// Mock AI responses
const mockTradingResponses = [
  "DV is showing strong bullish momentum with increased swap volume. The 0.30% fee structure creates sustainable treasury growth.",
  "Current DV price action suggests accumulation phase. Consider dollar-cost averaging into your position.",
  "The DV/AIC pool ratio at 1000:1 is maintaining stability. AI chat burn mechanism is creating deflationary pressure.",
  "Market sentiment for DV is positive following recent tier adoption. Gold tier (1,000 DV) unlocks premium features.",
  "Technical analysis shows DV forming a support level. The tier-based access control drives consistent demand.",
];

const mockNewsResponses = [
  "Here's the latest on DV: Swap volume hit a new all-time high with increased user adoption across all tiers.",
  "Recent news shows AI Catalyst burn rate is accelerating, creating stronger deflationary pressure on AIC supply.",
  "Base Chain ecosystem is growing rapidly. DV's position as a utility token is strengthening.",
  "The tier system continues to drive DV demand. More users are upgrading to Silver and Gold tiers.",
];

const mockPriceResponses = [
  `Current DV price: $${(0.001 * (1 + Math.random() * 0.1)).toFixed(6)}. Price has fluctuated ±10% in the last 24h based on market conditions.`,
  "DV price guidance: The token maintains stability through the 1000:1 DV/AIC pool ratio and consistent swap volume.",
  `Price prediction: Based on current trends, DV could reach $${(0.0015).toFixed(4)} if adoption continues at this rate.`,
  "Market volatility is normal. DV's utility-driven demand from tier requirements provides price support.",
];

export function AIChat() {
  const { isConnected, address } = useAccount();
  const { hasMarketAccess } = useDVTier();
  const { writeContract: approveAIC } = useWriteContract();
  const { writeContract: useAI } = useWriteContract();
  const { dvPriceUSD, priceChange24h } = useDynamicPricing();
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showBurnModal, setShowBurnModal] = useState(false);
  const [pendingMessage, setPendingMessage] = useState('');
  const [totalBurned, setTotalBurned] = useState(0n);
  const [showTopicWarning, setShowTopicWarning] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get AIC balance
  const { data: aicBalance, refetch: refetchBalance } = useReadContract({
    address: AIC_TOKEN_ADDRESS as `0x${string}`,
    abi: AIC_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address },
  });

  // Get AIC allowance for burn engine
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: AIC_TOKEN_ADDRESS as `0x${string}`,
    abi: AIC_TOKEN_ABI,
    functionName: 'allowance',
    args: address && DV_AI_ENGINE_ADDRESS ? [address, DV_AI_ENGINE_ADDRESS] : undefined,
    query: { enabled: isConnected && !!address },
  });

  const userAICBalance = aicBalance || 0n;
  const aiCostPerMessage = CONSTANTS.AI_COST_PER_MESSAGE;
  const hasEnoughAIC = userAICBalance >= aiCostPerMessage;
  const needsApproval = (allowance || 0n) < aiCostPerMessage;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleApprove = async () => {
    try {
      await approveAIC({
        address: AIC_TOKEN_ADDRESS as `0x${string}`,
        abi: AIC_TOKEN_ABI,
        functionName: 'approve',
        args: [DV_AI_ENGINE_ADDRESS as `0x${string}`, aiCostPerMessage * 100n],
      });
      await refetchAllowance();
    } catch (error) {
      console.error('Approval error:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || !isConnected) return;
    if (!isAllowedTopic(input)) {
      setShowTopicWarning(true);
      return;
    }
    if (needsApproval) {
      setPendingMessage(input);
      setShowBurnModal(true);
      return;
    }
    await processMessage(input);
  };

  const processMessage = async (messageContent: string) => {
    setIsLoading(true);

    const lowerMsg = messageContent.toLowerCase();
    let messageType: Message['type'] = 'general';
    if (lowerMsg.includes('news') || lowerMsg.includes('latest')) messageType = 'news';
    else if (lowerMsg.includes('price') || lowerMsg.includes('prediction')) messageType = 'price';
    else messageType = 'trading';

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageContent,
      timestamp: Date.now(),
      type: messageType,
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    try {
      await useAI({
        address: DV_AI_ENGINE_ADDRESS as `0x${string}`,
        abi: DV_AI_ENGINE_ABI,
        functionName: 'processMessage',
      });

      setTotalBurned(prev => prev + aiCostPerMessage);
      await refetchBalance();

      await new Promise(resolve => setTimeout(resolve, 1500));

      let randomResponse = '';
      if (messageType === 'news') {
        randomResponse = mockNewsResponses[Math.floor(Math.random() * mockNewsResponses.length)];
      } else if (messageType === 'price') {
        randomResponse = mockPriceResponses[Math.floor(Math.random() * mockPriceResponses.length)];
      } else {
        randomResponse = mockTradingResponses[Math.floor(Math.random() * mockTradingResponses.length)];
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: randomResponse,
        timestamp: Date.now(),
        aicBurned: aiCostPerMessage,
        type: messageType,
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('AI usage error:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, there was an error processing your request. Please try again.',
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setPendingMessage('');
    }
  };

  const handleConfirmBurn = async () => {
    if (needsApproval) {
      await handleApprove();
    }
    setShowBurnModal(false);
    if (pendingMessage) {
      await processMessage(pendingMessage);
    }
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Bot className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to chat with AI</p>
        </CardContent>
      </Card>
    );
  }

  if (!hasMarketAccess) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Lock className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <p className="text-white font-medium mb-2">Bronze Tier Required</p>
          <p className="text-white/50">Hold at least 1 DV to access AI Chat</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full mb-4 bg-white/5 border border-white/10">
          <TabsTrigger value="chat" className="flex-1 data-[state=active]:bg-white/10">
            <MessageSquare className="w-4 h-4 mr-2" />
            AI Chat
          </TabsTrigger>
          <TabsTrigger value="news" className="flex-1 data-[state=active]:bg-white/10">
            <Newspaper className="w-4 h-4 mr-2" />
            News
          </TabsTrigger>
          <TabsTrigger value="price" className="flex-1 data-[state=active]:bg-white/10">
            <Activity className="w-4 h-4 mr-2" />
            Price
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="mt-0">
          <Card className="bg-white/[0.02] border-white/10 h-[500px] flex flex-col">
            <CardHeader className="border-b border-white/10 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-white text-base">AI Assistant</CardTitle>
                    <CardDescription className="text-white/50 text-xs">
                      Trading, news & price guidance
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                    <Coins className="w-3 h-3 mr-1" />
                    {formatTokenAmount(userAICBalance, 18)}
                  </Badge>
                  <Badge className="bg-orange-500/20 text-orange-400 text-xs">
                    <Flame className="w-3 h-3 mr-1" />
                    {formatTokenAmount(totalBurned, 18)}
                  </Badge>
                </div>
              </div>
            </CardHeader>

            <div className="px-4 py-2 bg-purple-500/10 border-b border-purple-500/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame className="w-3 h-3 text-orange-400" />
                  <span className="text-xs text-white/70">
                    0.001 AIC <span className="text-white/50">per message</span>
                  </span>
                </div>
                <span className="text-xs text-white/40">
                  DV: ${dvPriceUSD.toFixed(6)} {priceChange24h >= 0 ? '+' : ''}{priceChange24h.toFixed(2)}%
                </span>
              </div>
            </div>

            <CardContent className="flex-1 p-0 overflow-hidden">
              <ScrollArea className="h-full p-4">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center py-12">
                    <div className="w-16 h-16 rounded-full bg-purple-500/10 flex items-center justify-center mb-4">
                      <Search className="w-8 h-8 text-purple-400" />
                    </div>
                    <p className="text-white/60 mb-2">Ask about anything crypto</p>
                    <p className="text-sm text-white/40">
                      News, prices, trading advice, market analysis
                    </p>
                    <div className="mt-6 flex flex-wrap gap-2 justify-center">
                      {['DV price news', 'Market analysis', 'Staking rewards'].map((suggestion) => (
                        <button
                          key={suggestion}
                          onClick={() => setInput(suggestion)}
                          className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 hover:bg-white/10 hover:text-white transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                          message.role === 'user' ? 'bg-aether-blue/20' : 'bg-purple-500/20'
                        }`}>
                          {message.role === 'user' ? (
                            <User className="w-4 h-4 text-aether-blue" />
                          ) : (
                            <Bot className="w-4 h-4 text-purple-400" />
                          )}
                        </div>
                        <div className={`max-w-[80%] ${message.role === 'user' ? 'text-right' : ''}`}>
                          <div className={`inline-block p-3 rounded-2xl text-left ${
                            message.role === 'user'
                              ? 'bg-aether-blue/20 text-white'
                              : 'bg-white/5 text-white/90'
                          }`}>
                            <p className="text-sm">{message.content}</p>
                          </div>
                          {message.aicBurned && (
                            <div className="mt-1 flex items-center gap-1 text-xs text-orange-400">
                              <Flame className="w-3 h-3" />
                              <span>{formatTokenAmount(message.aicBurned, 18)} AIC burned</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                          <Bot className="w-4 h-4 text-purple-400" />
                        </div>
                        <div className="bg-white/5 p-3 rounded-2xl">
                          <Loader2 className="w-5 h-5 text-white/50 animate-spin" />
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>
            </CardContent>

            <div className="p-4 border-t border-white/10">
              {!hasEnoughAIC ? (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-center">
                  <AlertTriangle className="w-5 h-5 text-red-400 mx-auto mb-1" />
                  <p className="text-sm text-red-400">Insufficient AIC balance</p>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Ask about news, prices, or trading..."
                    disabled={isLoading}
                    className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-white/30"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!input.trim() || isLoading}
                    className="bg-gradient-to-r from-purple-500 to-pink-600 hover:opacity-90"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  </Button>
                </div>
              )}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="news" className="mt-0">
          <Card className="bg-white/[0.02] border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Newspaper className="w-5 h-5 text-aether-blue" />
                Latest Crypto News
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockNews.map((news, i) => (
                <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-white font-medium text-sm">{news.title}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-white/10 text-white/60 text-xs">{news.source}</Badge>
                        <span className="text-xs text-white/40">{news.time}</span>
                      </div>
                    </div>
                    <Badge className={news.sentiment === 'bullish' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-white/60'}>
                      <TrendingUp className="w-3 h-3 mr-1" />
                      {news.sentiment}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="price" className="mt-0">
          <Card className="bg-white/[0.02] border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-400" />
                Price Guidance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
                  <p className="text-sm text-white/50 mb-1">DV Price</p>
                  <p className="text-2xl font-bold text-emerald-400">${dvPriceUSD.toFixed(6)}</p>
                  <p className={`text-xs ${priceChange24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {priceChange24h >= 0 ? '+' : ''}{priceChange24h.toFixed(2)}% (24h)
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20 text-center">
                  <p className="text-sm text-white/50 mb-1">AIC Price</p>
                  <p className="text-2xl font-bold text-purple-400">${(dvPriceUSD * 1000).toFixed(4)}</p>
                  <p className="text-xs text-white/40">1000:1 Ratio</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5">
                <p className="text-sm text-white/70 mb-3">Price Fluctuation Guidance</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/50">Support Level</span>
                    <span className="text-emerald-400">${(dvPriceUSD * 0.9).toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Resistance Level</span>
                    <span className="text-amber-400">${(dvPriceUSD * 1.1).toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">24h Volume</span>
                    <span className="text-white">1.5M DV</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-blue-400" />
                  <span className="text-sm text-blue-400 font-medium">AI Prediction</span>
                </div>
                <p className="text-sm text-white/70">
                  Based on current tier adoption and swap volume, DV is expected to maintain 
                  stability within the ±10% range. Strong support from utility demand.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Burn Confirmation Modal */}
      <Dialog open={showBurnModal} onOpenChange={setShowBurnModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <Flame className="w-6 h-6 text-orange-400" />
              Approve AIC Burn
            </DialogTitle>
            <DialogDescription className="text-white/60">
              Each AI message burns 0.001 AIC permanently
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-orange-500/10 border border-orange-500/20">
              <div className="flex justify-between items-center mb-2">
                <span className="text-white/60">Cost per message</span>
                <span className="text-orange-400 font-medium">0.001 AIC</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Your balance</span>
                <span className="text-white">{formatTokenAmount(userAICBalance, 18)} AIC</span>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowBurnModal(false)} className="flex-1 border-white/10">
                Cancel
              </Button>
              <Button onClick={handleConfirmBurn} className="flex-1 bg-gradient-to-r from-orange-500 to-red-600">
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve & Burn
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Topic Warning Modal */}
      <Dialog open={showTopicWarning} onOpenChange={setShowTopicWarning}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
              Topic Not Recognized
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <p className="text-white/70">Try asking about:</p>
            <ul className="text-sm text-amber-400 space-y-1">
              <li>• Crypto news and market updates</li>
              <li>• DV/AIC price analysis</li>
              <li>• Trading strategies</li>
              <li>• Staking and swap guidance</li>
            </ul>
            <Button onClick={() => setShowTopicWarning(false)} className="w-full bg-amber-500">
              Got it
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
