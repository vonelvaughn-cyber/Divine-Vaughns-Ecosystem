import { useState, useEffect, useRef } from 'react';
import { useAccount } from 'wagmi';
import { 
  Video, 
  Users, 
  Gift, 
  Share2, 
  MessageSquare,
  Mic,
  MicOff,
  VideoOff,
  Settings,
  X,
  Send,
  DollarSign
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GiftShop } from './GiftShop';
import { toast } from 'sonner';

// Earnings per minute based on DV price
const EARNINGS_PER_MINUTE_DV = 0.5; // 0.5 DV per minute

interface StreamMessage {
  id: string;
  user: string;
  message: string;
  timestamp: number;
  isGift?: boolean;
  giftType?: string;
  giftAmount?: number;
}

interface LiveStreamProps {
  isCreator?: boolean;
  creatorAddress?: string;
  creatorName?: string;
}

export function LiveStreamWithGifts({ 
  isCreator = false, 
  creatorAddress = '0xCreatorAddress',
  creatorName = 'DV Creator'
}: LiveStreamProps) {
  const { address } = useAccount();
  const [isLive, setIsLive] = useState(false);
  const [viewerCount, setViewerCount] = useState(0);
  const [messages, setMessages] = useState<StreamMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [showGiftShop, setShowGiftShop] = useState(false);
  const [streamDuration, setStreamDuration] = useState(0);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Simulate viewer count changes
  useEffect(() => {
    if (!isLive) return;
    
    const interval = setInterval(() => {
      setViewerCount(prev => {
        const change = Math.floor(Math.random() * 5) - 2;
        return Math.max(1, prev + change);
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [isLive]);

  // Track stream duration and earnings
  useEffect(() => {
    if (!isLive) return;
    
    const interval = setInterval(() => {
      setStreamDuration(prev => prev + 1);
      setTotalEarnings(prev => prev + (EARNINGS_PER_MINUTE_DV / 60));
    }, 1000);

    return () => clearInterval(interval);
  }, [isLive]);

  // Auto-scroll messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startStream = () => {
    setIsLive(true);
    setViewerCount(1);
    setStreamDuration(0);
    setTotalEarnings(0);
    toast.success('Stream started! You are now live.');
  };

  const endStream = () => {
    setIsLive(false);
    toast.info(`Stream ended. Total earnings: ${totalEarnings.toFixed(2)} DV`);
  };

  const sendMessage = () => {
    if (!newMessage.trim()) return;
    
    const message: StreamMessage = {
      id: Date.now().toString(),
      user: isCreator ? creatorName : `User_${address?.slice(-4)}`,
      message: newMessage,
      timestamp: Date.now(),
    };
    
    setMessages(prev => [...prev, message]);
    setNewMessage('');
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Video Stream */}
        <div className="lg:col-span-2">
          <Card className="bg-slate-900 border-slate-700 overflow-hidden">
            {/* Stream Video Area */}
            <div className="relative aspect-video bg-slate-800">
              {isLive ? (
                <>
                  {/* Placeholder for actual video stream */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    {isVideoOff ? (
                      <div className="text-center">
                        <VideoOff className="w-16 h-16 text-slate-600 mx-auto mb-2" />
                        <p className="text-slate-500">Video Off</p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Video className="w-16 h-16 text-slate-600 mx-auto mb-2" />
                        <p className="text-slate-500">
                          {isCreator ? 'Your Stream is Live!' : `Watching ${creatorName}`}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  {/* Live Badge */}
                  <div className="absolute top-4 left-4 flex items-center gap-2">
                    <Badge className="bg-red-500 text-white animate-pulse">
                      ● LIVE
                    </Badge>
                    <Badge className="bg-slate-800/80 text-white">
                      <Users className="w-3 h-3 mr-1" />
                      {viewerCount}
                    </Badge>
                    <Badge className="bg-slate-800/80 text-white">
                      {formatDuration(streamDuration)}
                    </Badge>
                  </div>

                  {/* Creator Earnings */}
                  {isCreator && (
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-amber-500/20 text-amber-400 border border-amber-500/50">
                        <DollarSign className="w-3 h-3 mr-1" />
                        {totalEarnings.toFixed(2)} DV earned
                      </Badge>
                    </div>
                  )}
                </>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Video className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                    <p className="text-slate-500 mb-4">
                      {isCreator ? 'Start your live stream' : 'Stream is offline'}
                    </p>
                    {isCreator && (
                      <Button 
                        onClick={startStream}
                        className="bg-red-500 hover:bg-red-600 text-white"
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Go Live
                      </Button>
                    )}
                  </div>
                </div>
              )}

              {/* Stream Controls */}
              {isLive && isCreator && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2">
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isMuted ? 'bg-red-500' : 'bg-slate-700'
                    }`}
                  >
                    {isMuted ? <MicOff className="w-5 h-5 text-white" /> : <Mic className="w-5 h-5 text-white" />}
                  </button>
                  <button
                    onClick={() => setIsVideoOff(!isVideoOff)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isVideoOff ? 'bg-red-500' : 'bg-slate-700'
                    }`}
                  >
                    {isVideoOff ? <VideoOff className="w-5 h-5 text-white" /> : <Video className="w-5 h-5 text-white" />}
                  </button>
                  <button className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center">
                    <Settings className="w-5 h-5 text-white" />
                  </button>
                  <button
                    onClick={endStream}
                    className="px-4 py-2 rounded-full bg-red-500 text-white font-medium"
                  >
                    End Stream
                  </button>
                </div>
              )}
            </div>

            {/* Stream Info */}
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-white">{creatorName}</h3>
                  <p className="text-slate-400 text-sm">
                    {isLive ? 'Streaming now' : 'Last streamed recently'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {!isCreator && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowGiftShop(true)}
                      className="border-pink-500/50 text-pink-400 hover:bg-pink-500/10"
                    >
                      <Gift className="w-4 h-4 mr-2" />
                      Send Gift
                    </Button>
                  )}
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat Panel */}
        <div className="lg:col-span-1">
          <Card className="bg-slate-900 border-slate-700 h-full flex flex-col">
            <CardContent className="p-4 flex-1 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Live Chat
                </h3>
                <Badge className="bg-slate-800 text-slate-400">
                  {messages.length} messages
                </Badge>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto space-y-2 max-h-[400px] mb-4">
                {messages.length === 0 ? (
                  <p className="text-slate-500 text-center py-8">
                    No messages yet. Say hello!
                  </p>
                ) : (
                  messages.map((msg) => (
                    <div 
                      key={msg.id} 
                      className={`p-2 rounded-lg ${
                        msg.isGift 
                          ? 'bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/30' 
                          : 'bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {msg.isGift && <Gift className="w-4 h-4 text-pink-400 mt-0.5" />}
                        <div>
                          <span className={`text-sm font-medium ${
                            msg.user === creatorName ? 'text-amber-400' : 'text-cyan-400'
                          }`}>
                            {msg.user}
                          </span>
                          <p className="text-white text-sm">{msg.message}</p>
                          {msg.isGift && msg.giftAmount && (
                            <p className="text-pink-400 text-xs mt-1">
                              +{msg.giftAmount} DV to creator
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <div className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  placeholder="Type a message..."
                  className="bg-slate-800 border-slate-700 text-white"
                />
                <Button 
                  onClick={sendMessage}
                  size="icon"
                  className="bg-cyan-500 hover:bg-cyan-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Gift Shop Modal */}
      {showGiftShop && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur z-50 flex items-center justify-center p-4">
          <div className="relative w-full max-w-4xl max-h-[90vh] overflow-auto">
            <button
              onClick={() => setShowGiftShop(false)}
              className="absolute top-4 right-4 z-10 p-2 bg-slate-800 rounded-full hover:bg-slate-700"
            >
              <X className="w-5 h-5 text-white" />
            </button>
            <GiftShop 
              creatorAddress={creatorAddress}
              creatorName={creatorName}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default LiveStreamWithGifts;
