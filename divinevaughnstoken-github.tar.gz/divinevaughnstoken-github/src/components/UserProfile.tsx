import { useState } from 'react';
import { useAccount } from 'wagmi';
import { useDVTier, useStakedDV } from '@/hooks/useDVTier';
import { TIERS, formatDVAmount } from '@/lib/web3';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { User, Shield, TrendingUp, Lock, CheckCircle, Crown, Star, Award, Gem } from 'lucide-react';

const tierIcons: Record<number, typeof Crown> = {
  0: Lock,
  1: Star,
  2: Award,
  3: Crown,
  4: Gem,
};

const tierColors: Record<number, string> = {
  0: 'text-gray-400',
  1: 'text-amber-400',
  2: 'text-slate-300',
  3: 'text-yellow-400',
  4: 'text-cyan-400',
};

const tierBgColors: Record<number, string> = {
  0: 'from-gray-500/20 to-gray-600/10',
  1: 'from-amber-500/20 to-amber-600/10',
  2: 'from-slate-400/20 to-slate-500/10',
  3: 'from-yellow-500/20 to-yellow-600/10',
  4: 'from-cyan-500/20 to-cyan-600/10',
};

export function UserProfileCreator() {
  const { isConnected } = useAccount();
  const { tier, tierName, balance, formattedBalance, hasProfileAccess, isLoading } = useDVTier();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [created, setCreated] = useState(false);

  const TierIcon = tierIcons[tier] || Lock;

  const handleCreateProfile = async () => {
    if (!username || !email) return;
    
    setIsCreating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsCreating(false);
    setCreated(true);
    setTimeout(() => {
      setShowCreateModal(false);
      setCreated(false);
    }, 2000);
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <User className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect your wallet to create a profile</p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <div className="w-8 h-8 border-2 border-aether-blue border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-white/50 mt-4">Checking DV tier...</p>
        </CardContent>
      </Card>
    );
  }

  if (!hasProfileAccess) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Lock className="w-5 h-5 text-gray-400" />
            Profile Locked
          </CardTitle>
          <CardDescription className="text-white/50">
            You need Tier 2 (100+ DV) to create a profile
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 rounded-xl bg-gradient-to-br from-gray-500/10 to-gray-600/5 border border-gray-500/20">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TierIcon className={`w-6 h-6 ${tierColors[tier]}`} />
                <span className="text-white font-medium">Current: {tierName}</span>
              </div>
              <Badge variant="outline" className="border-gray-500/30 text-gray-400">
                Tier {tier}
              </Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Your Balance</span>
                <span className="text-white">{formattedBalance} DV</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Required for Profile</span>
                <span className="text-slate-300">100 DV (Tier 2)</span>
              </div>
            </div>

            <div className="mt-4 h-2 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-slate-400 to-slate-500 rounded-full transition-all"
                style={{ width: `${Math.min(100, (Number(balance) / (100 * 10 ** 18)) * 100)}%` }}
              />
            </div>
            
            <p className="text-xs text-white/40 mt-2">
              Need {formatDVAmount(100n * 10n ** 18n - balance)} more DV to reach Tier 2
            </p>
          </div>

          {/* Tier Progress */}
          <div className="mt-6 space-y-2">
            <p className="text-sm text-white/60">Tier Progress</p>
            <div className="grid grid-cols-5 gap-1">
              {[1, 2, 3, 4].map((t) => (
                <div
                  key={t}
                  className={`h-1.5 rounded-full ${
                    t <= tier ? 'bg-gradient-to-r from-aether-blue to-aether-purple' : 'bg-white/10'
                  }`}
                />
              ))}
            </div>
            <div className="flex justify-between text-xs text-white/40">
              <span>1 DV</span>
              <span>100 DV</span>
              <span>1K DV</span>
              <span>10K DV</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                Profile Access Unlocked
              </CardTitle>
              <CardDescription className="text-white/50">
                Your tier qualifies for profile creation
              </CardDescription>
            </div>
            <Badge className={`bg-gradient-to-r ${tierBgColors[tier]} ${tierColors[tier]} border-0`}>
              <TierIcon className="w-3 h-3 mr-1" />
              {tierName}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className={`p-4 rounded-xl bg-gradient-to-br ${tierBgColors[tier]} border border-white/10 mb-6`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/60">Current Tier</p>
                <p className={`text-2xl font-bold ${tierColors[tier]}`}>{tierName}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-white/60">DV Balance</p>
                <p className="text-xl font-bold text-white">{formattedBalance}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="p-4 rounded-xl bg-white/5 text-center">
              <p className="text-sm text-white/50 mb-1">Profile Status</p>
              <p className="text-lg font-semibold text-emerald-400">Eligible</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5 text-center">
              <p className="text-sm text-white/50 mb-1">Bot Access</p>
              <p className={`text-lg font-semibold ${tier >= 3 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {tier >= 3 ? 'Unlocked' : 'Tier 3+'}
              </p>
            </div>
          </div>

          <Button 
            onClick={() => setShowCreateModal(true)}
            className="w-full bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
          >
            Create Profile
          </Button>
        </CardContent>
      </Card>

      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Create Your Profile</DialogTitle>
            <DialogDescription className="text-white/60">
              Set up your Aether platform profile
            </DialogDescription>
          </DialogHeader>

          {created ? (
            <div className="py-8 text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-emerald-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Profile Created!</h3>
              <p className="text-white/60">Welcome to the Aether ecosystem</p>
            </div>
          ) : (
            <div className="space-y-4 mt-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-aether-blue/10 to-aether-purple/10 border border-aether-blue/20">
                <div className="flex items-center gap-2">
                  <TierIcon className={`w-5 h-5 ${tierColors[tier]}`} />
                  <span className="text-white font-medium">{tierName} Member</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username" className="text-white/70">Username</Label>
                <Input
                  id="username"
                  placeholder="Enter username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white/70">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-medium text-emerald-400">Profile Benefits</span>
                </div>
                <ul className="text-sm text-white/60 space-y-1">
                  <li>• Access to AI Market Bot {tier >= 3 && '✓'}</li>
                  <li>• Staking rewards eligibility ✓</li>
                  <li>• Community competitions ✓</li>
                  <li>• Exclusive features ✓</li>
                </ul>
              </div>

              <Button 
                onClick={handleCreateProfile}
                disabled={!username || !email || isCreating}
                className="w-full bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
              >
                {isCreating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    Creating...
                  </>
                ) : (
                  'Create Profile'
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// Profile Dashboard Component
export function ProfileDashboard() {
  const { isConnected } = useAccount();
  const { tier, tierName, formattedBalance, hasBotAccess, hasPremiumAccess } = useDVTier();
  const { formattedStakedBalance, stakingStartTime } = useStakedDV();

  const TierIcon = tierIcons[tier] || Lock;

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <User className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to view profile</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/[0.02] border-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <User className="w-5 h-5 text-aether-blue" />
          Your Profile
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Tier Badge */}
        <div className={`p-4 rounded-xl bg-gradient-to-br ${tierBgColors[tier]} border border-white/10 mb-4`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center`}>
                <TierIcon className={`w-6 h-6 ${tierColors[tier]}`} />
              </div>
              <div>
                <p className="text-sm text-white/60">Current Tier</p>
                <p className={`text-xl font-bold ${tierColors[tier]}`}>{tierName}</p>
              </div>
            </div>
            <Badge className={`bg-white/10 ${tierColors[tier]}`}>
              Tier {tier}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-gradient-to-br from-aether-blue/20 to-transparent border border-aether-blue/20">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-aether-blue" />
              <span className="text-sm text-white/60">DV Balance</span>
            </div>
            <p className="text-2xl font-bold text-white">{formattedBalance}</p>
            <p className="text-xs text-white/40">DV</p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-aether-purple/20 to-transparent border border-aether-purple/20">
            <div className="flex items-center gap-2 mb-2">
              <Lock className="w-4 h-4 text-aether-purple" />
              <span className="text-sm text-white/60">Staked</span>
            </div>
            <p className="text-2xl font-bold text-white">{formattedStakedBalance}</p>
            <p className="text-xs text-white/40">DV</p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-500/20 to-transparent border border-emerald-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-white/60">Staking Since</span>
            </div>
            <p className="text-lg font-bold text-white">
              {stakingStartTime 
                ? new Date(stakingStartTime).toLocaleDateString() 
                : 'Not staking'}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/20 to-transparent border border-amber-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Crown className="w-4 h-4 text-amber-400" />
              <span className="text-sm text-white/60">Bot Access</span>
            </div>
            <p className={`text-lg font-bold ${hasBotAccess ? 'text-emerald-400' : 'text-amber-400'}`}>
              {hasBotAccess ? 'Unlocked' : 'Tier 3+'}
            </p>
          </div>
        </div>

        {/* Next Tier Progress */}
        {tier < 4 && (
          <div className="mt-4 p-4 rounded-xl bg-white/5">
            <p className="text-sm text-white/60 mb-2">Next Tier: {TIERS[(tier + 1) as keyof typeof TIERS]?.name}</p>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-aether-blue to-aether-purple rounded-full"
                style={{ width: `${(tier / 4) * 100}%` }}
              />
            </div>
            <p className="text-xs text-white/40 mt-2">
              Hold {formatDVAmount(TIERS[(tier + 1) as keyof typeof TIERS]?.minBalance || 0n)} DV to unlock
            </p>
          </div>
        )}

        {hasPremiumAccess && (
          <div className="mt-4 p-4 rounded-xl bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30">
            <div className="flex items-center gap-2">
              <Gem className="w-5 h-5 text-cyan-400" />
              <span className="text-cyan-400 font-medium">Platinum Member Benefits Active</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
