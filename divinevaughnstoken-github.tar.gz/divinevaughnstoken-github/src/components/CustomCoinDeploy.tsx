import { useState } from 'react';
import { useAccount } from 'wagmi';
import { useReadContract, useWriteContract } from 'wagmi';
import { 
  DV_TOKEN_ADDRESS,
  DV_TOKEN_ABI,
  formatDVAmount,
  useDynamicPricing
} from '@/lib/web3';
import { useDVTier } from '@/hooks/useDVTier';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Coins, 
  Rocket, 
  Flame,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Lock,
  Zap,
  Info
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface DeployForm {
  tokenName: string;
  tokenSymbol: string;
  initialSupply: string;
  decimals: string;
}

// Dynamic pricing tiers based on DV market value
const getDeploymentFee = (dvPriceUSD: number): { dvAmount: bigint; usdValue: number; tier: string } => {
  // As DV price increases, fee in DV decreases to maintain reasonable USD cost
  if (dvPriceUSD >= 0.01) {
    // High DV price: 100 DV (~$1)
    return { 
      dvAmount: 100n * 10n ** 18n, 
      usdValue: dvPriceUSD * 100,
      tier: 'Standard'
    };
  } else if (dvPriceUSD >= 0.005) {
    // Medium DV price: 200 DV (~$1)
    return { 
      dvAmount: 200n * 10n ** 18n, 
      usdValue: dvPriceUSD * 200,
      tier: 'Standard'
    };
  } else if (dvPriceUSD >= 0.001) {
    // Low DV price: 1000 DV (~$1)
    return { 
      dvAmount: 1000n * 10n ** 18n, 
      usdValue: dvPriceUSD * 1000,
      tier: 'Standard'
    };
  } else {
    // Very low DV price: 2000 DV (~$0.20-$1)
    return { 
      dvAmount: 2000n * 10n ** 18n, 
      usdValue: dvPriceUSD * 2000,
      tier: 'Discounted'
    };
  }
};

export function CustomCoinDeploy() {
  const { isConnected, address } = useAccount();
  const { hasSwapAccess } = useDVTier();
  const { dvPriceUSD, isLoading: priceLoading } = useDynamicPricing();
  const { writeContract: approveDV } = useWriteContract();

  const [form, setForm] = useState<DeployForm>({
    tokenName: '',
    tokenSymbol: '',
    initialSupply: '1000000',
    decimals: '18',
  });
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploySuccess, setDeploySuccess] = useState(false);
  const [deployedAddress, setDeployedAddress] = useState('');

  // Get dynamic deployment fee
  const { dvAmount: deploymentFeeDV, usdValue: deploymentFeeUSD, tier: feeTier } = getDeploymentFee(dvPriceUSD);

  // Get DV balance
  const { data: dvBalance, refetch: refetchBalance } = useReadContract({
    address: DV_TOKEN_ADDRESS as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address },
  });

  const userDVBalance = dvBalance || 0n;
  const hasEnoughDV = userDVBalance >= deploymentFeeDV;

  const handleDeploy = async () => {
    if (!form.tokenName || !form.tokenSymbol || !hasEnoughDV) return;

    setIsDeploying(true);
    try {
      // Approve DV for deployment fee
      await approveDV({
        address: DV_TOKEN_ADDRESS as `0x${string}`,
        abi: DV_TOKEN_ABI,
        functionName: 'approve',
        args: ['0x...deployer_contract...', deploymentFeeDV], // Replace with actual deployer
      });

      // Deploy token (mock for now)
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Generate mock deployed address
      const mockAddress = '0x' + Array(40).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
      setDeployedAddress(mockAddress);
      setDeploySuccess(true);
      await refetchBalance();
    } catch (error) {
      console.error('Deployment error:', error);
    } finally {
      setIsDeploying(false);
      setShowConfirmModal(false);
    }
  };

  const isFormValid = form.tokenName.length >= 3 && 
                      form.tokenSymbol.length >= 2 && 
                      form.tokenSymbol.length <= 8 &&
                      Number(form.initialSupply) > 0;

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Rocket className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to deploy custom tokens</p>
        </CardContent>
      </Card>
    );
  }

  // Tier 2+ (Silver) required for coin deployment
  if (!hasSwapAccess) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Lock className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <p className="text-white font-medium mb-2">Silver Tier Required</p>
          <p className="text-white/50">Hold at least 100 DV to deploy custom tokens</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-br from-emerald-500/10 to-purple-500/10 border-emerald-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-purple-600 flex items-center justify-center">
                <Rocket className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-xl">Custom Token Deployer</CardTitle>
                <CardDescription className="text-white/50">
                  Create your own ERC20 token with DV fees
                </CardDescription>
              </div>
            </div>
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              <Zap className="w-3 h-3 mr-1" />
              Powered by DV
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Dynamic Pricing Info */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            Dynamic Deployment Fee
          </CardTitle>
          <CardDescription className="text-white/50">
            Fee adjusts based on DV market value to maintain fair pricing
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white/5 text-center">
              <p className="text-sm text-white/50 mb-1">Current DV Price</p>
              <p className="text-2xl font-bold text-white">${dvPriceUSD.toFixed(6)}</p>
              {priceLoading && <p className="text-xs text-white/40">Updating...</p>}
            </div>
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
              <p className="text-sm text-white/50 mb-1">Deployment Fee</p>
              <p className="text-2xl font-bold text-emerald-400">{formatDVAmount(deploymentFeeDV)} DV</p>
              <p className="text-xs text-emerald-400/70">~${deploymentFeeUSD.toFixed(2)} USD</p>
            </div>
          </div>

          {/* Price Fluctuation Indicator */}
          <div className="p-4 rounded-xl bg-white/5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-white/60">Fee Tier</span>
              <Badge className="bg-purple-500/20 text-purple-400">{feeTier}</Badge>
            </div>
            <p className="text-sm text-white/50">
              As DV price increases, the fee in DV decreases to maintain a reasonable USD cost (~$1).
            </p>
          </div>

          {/* DV Balance */}
          <div className="p-4 rounded-xl bg-white/5">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-white/60">Your DV Balance</span>
              <span className={`font-medium ${hasEnoughDV ? 'text-emerald-400' : 'text-red-400'}`}>
                {formatDVAmount(userDVBalance)} DV
              </span>
            </div>
            <Progress 
              value={Math.min(100, Number(userDVBalance) / Number(deploymentFeeDV) * 100)} 
              className="h-2"
            />
            {!hasEnoughDV && (
              <p className="text-xs text-red-400 mt-2">
                Need {formatDVAmount(deploymentFeeDV - userDVBalance)} more DV
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Deployment Form */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <Coins className="w-5 h-5 text-purple-400" />
            Token Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white/70">Token Name</Label>
              <Input
                value={form.tokenName}
                onChange={(e) => setForm({ ...form, tokenName: e.target.value })}
                placeholder="My Token"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
              />
              <p className="text-xs text-white/40">Min 3 characters</p>
            </div>
            <div className="space-y-2">
              <Label className="text-white/70">Token Symbol</Label>
              <Input
                value={form.tokenSymbol}
                onChange={(e) => setForm({ ...form, tokenSymbol: e.target.value.toUpperCase() })}
                placeholder="MTK"
                maxLength={8}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
              />
              <p className="text-xs text-white/40">2-8 characters</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white/70">Initial Supply</Label>
              <Input
                type="number"
                value={form.initialSupply}
                onChange={(e) => setForm({ ...form, initialSupply: e.target.value })}
                className="bg-white/5 border-white/10 text-white"
              />
              <p className="text-xs text-white/40">Total tokens to mint</p>
            </div>
            <div className="space-y-2">
              <Label className="text-white/70">Decimals</Label>
              <Input
                type="number"
                value={form.decimals}
                onChange={(e) => setForm({ ...form, decimals: e.target.value })}
                min={0}
                max={18}
                className="bg-white/5 border-white/10 text-white"
              />
              <p className="text-xs text-white/40">Standard: 18</p>
            </div>
          </div>

          {/* Preview */}
          {isFormValid && (
            <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20">
              <p className="text-sm text-white/60 mb-2">Token Preview</p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                  <span className="text-white font-bold">{form.tokenSymbol.slice(0, 2)}</span>
                </div>
                <div>
                  <p className="text-white font-medium">{form.tokenName}</p>
                  <p className="text-sm text-purple-400">{form.tokenSymbol}</p>
                  <p className="text-xs text-white/50">
                    Supply: {Number(form.initialSupply).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Deploy Button */}
          <Button
            onClick={() => setShowConfirmModal(true)}
            disabled={!isFormValid || !hasEnoughDV}
            className="w-full bg-gradient-to-r from-emerald-500 to-purple-600 hover:opacity-90 disabled:opacity-50"
          >
            {!isFormValid ? (
              'Complete Token Details'
            ) : !hasEnoughDV ? (
              <>
                <AlertTriangle className="w-4 h-4 mr-2" />
                Insufficient DV Balance
              </>
            ) : (
              <>
                <Rocket className="w-4 h-4 mr-2" />
                Deploy Token ({formatDVAmount(deploymentFeeDV)} DV)
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Fee Distribution Info */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <Info className="w-5 h-5 text-aether-blue" />
            Fee Distribution
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-400" />
              <span className="text-white/70">DV Burned (Deflationary)</span>
            </div>
            <span className="text-white font-medium">50%</span>
          </div>
          <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-emerald-400" />
              <span className="text-white/70">Treasury (Ecosystem Growth)</span>
            </div>
            <span className="text-white font-medium">30%</span>
          </div>
          <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              <span className="text-white/70">DV/AIC Pool (Liquidity)</span>
            </div>
            <span className="text-white font-medium">20%</span>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation Modal */}
      <Dialog open={showConfirmModal} onOpenChange={setShowConfirmModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <Rocket className="w-6 h-6 text-emerald-400" />
              Confirm Token Deployment
            </DialogTitle>
            <DialogDescription className="text-white/60">
              Review your token details before deployment
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-xl bg-white/5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                  <span className="text-white font-bold">{form.tokenSymbol.slice(0, 2)}</span>
                </div>
                <div>
                  <p className="text-white font-medium text-lg">{form.tokenName}</p>
                  <p className="text-purple-400">{form.tokenSymbol}</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-white/60">Initial Supply</span>
                  <span className="text-white">{Number(form.initialSupply).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/60">Decimals</span>
                  <span className="text-white">{form.decimals}</span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <p className="text-sm text-white/60 mb-2">Deployment Fee</p>
              <div className="flex justify-between items-center">
                <span className="text-emerald-400 font-medium">{formatDVAmount(deploymentFeeDV)} DV</span>
                <span className="text-white/50">~${deploymentFeeUSD.toFixed(2)} USD</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 border-white/10 hover:bg-white/5"
              >
                Cancel
              </Button>
              <Button
                onClick={handleDeploy}
                disabled={isDeploying}
                className="flex-1 bg-gradient-to-r from-emerald-500 to-purple-600 hover:opacity-90"
              >
                {isDeploying ? (
                  <>
                    <div className="w-4 h-4 mr-2 animate-spin border-2 border-white/30 border-t-white rounded-full" />
                    Deploying...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Confirm Deploy
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Success Modal */}
      <Dialog open={deploySuccess} onOpenChange={setDeploySuccess}>
        <DialogContent className="bg-aether-dark border-white/10 text-white text-center">
          <div className="py-8">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Token Deployed!</h3>
            <p className="text-white/60 mb-4">
              Your token <span className="text-white font-medium">{form.tokenName}</span> has been successfully deployed
            </p>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10">
              <p className="text-sm text-white/60 mb-1">Contract Address</p>
              <p className="text-emerald-400 font-mono text-sm break-all">{deployedAddress}</p>
            </div>
            <div className="mt-4 p-4 rounded-xl bg-orange-500/10 border border-orange-500/20">
              <p className="text-sm text-white/60">Fee Paid</p>
              <p className="text-lg font-bold text-emerald-400">{formatDVAmount(deploymentFeeDV)} DV</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
