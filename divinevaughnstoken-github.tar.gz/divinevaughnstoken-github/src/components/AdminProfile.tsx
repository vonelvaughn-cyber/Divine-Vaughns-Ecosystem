import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Mail, Phone, User, Crown } from 'lucide-react';

interface AdminProfileProps {
  name: string;
  email: string;
  phone: string;
  role: string;
  walletAddress?: string;
}

export function AdminProfile({ name, email, phone, role, walletAddress }: AdminProfileProps) {
  return (
    <Card className="bg-gradient-to-br from-aether-blue/10 to-aether-purple/10 border-aether-blue/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-aether-blue to-aether-purple flex items-center justify-center">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-white">Platform Admin</CardTitle>
              <p className="text-white/50 text-sm">{role}</p>
            </div>
          </div>
          <Badge className="bg-aether-blue/20 text-aether-blue border-aether-blue/30">
            <Shield className="w-3 h-3 mr-1" />
            Verified
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
          <User className="w-5 h-5 text-aether-blue" />
          <div>
            <p className="text-sm text-white/50">Name</p>
            <p className="text-white font-medium">{name}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
          <Mail className="w-5 h-5 text-aether-purple" />
          <div>
            <p className="text-sm text-white/50">Email</p>
            <p className="text-white font-medium">{email}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
          <Phone className="w-5 h-5 text-emerald-400" />
          <div>
            <p className="text-sm text-white/50">Phone</p>
            <p className="text-white font-medium">{phone}</p>
          </div>
        </div>

        {walletAddress && (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
            <Shield className="w-5 h-5 text-amber-400" />
            <div>
              <p className="text-sm text-white/50">Admin Wallet</p>
              <p className="text-white font-mono text-sm">{walletAddress}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Default admin profile for Devaughn Parker
export const DEFAULT_ADMIN = {
  name: 'Devaughn Parker',
  email: 'vonelvaughn@gmail.com',
  phone: '501-224-9720',
  role: 'Platform Administrator',
  walletAddress: '0x...', // Can be updated when provided
};
