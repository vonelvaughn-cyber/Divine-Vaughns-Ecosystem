import { useState, useEffect } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { 
  Gift, 
  Heart, 
  Star, 
  Crown, 
  Gem, 
  Flame, 
  Zap, 
  Sparkles,
  Rocket,
  Diamond,
  Trophy,
  Send,
  CreditCard,
  Bitcoin,
  ArrowRight,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { APP_CONFIG } from '@/config/app.config';
import { toast } from 'sonner';

// DV Token ABI
const DV_TOKEN_ABI = [
  {
    inputs: [
      { internalType: 'address', name: 'recipient', type: 'address' },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'transfer',
    outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'account', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  }
] as const;

// DV Price in USD (would come from oracle in production)
const DV_PRICE_USD = 0.001;

// Gift tiers with dynamic pricing based on DV value
interface GiftItem {
  id: string;
  name: string;
  icon: React.ElementType;
  baseDvCost: number;
  description: string;
  animation: string;
  color: string;
}

const GIFTS: GiftItem[] = [
  { 
    id: 'like', 
    name: 'Like', 
    icon: Heart, 
    baseDvCost: 10, 
    description: 'Show your appreciation',
    animation: 'pulse',
    color: 'text-pink-400'
  },
  { 
    id: 'star', 
    name: 'Star', 
    icon: Star, 
    baseDvCost: 50, 
    description: 'A shining star for great content',
    animation: 'spin-slow',
    color: 'text-yellow-400'
  },
  { 
    id: 'lightning', 
    name: 'Lightning', 
    icon: Zap, 
    baseDvCost: 100, 
    description: 'Electrifying performance!',
    animation: 'flash',
    color: 'text-cyan-400'
  },
  { 
    id: 'flame', 
    name: 'Fire', 
    icon: Flame, 
    baseDvCost: 250, 
    description: 'This content is fire!',
    animation: 'flicker',
    color: 'text-orange-400'
  },
  { 
    id: 'sparkle', 
    name: 'Sparkle', 
    icon: Sparkles, 
    baseDvCost: 500, 
    description: 'Magical content!',
    animation: 'sparkle',
    color: 'text-purple-400'
  },
  { 
    id: 'gem', 
    name: 'Gem', 
    icon: Gem, 
    baseDvCost: 1000, 
    description: 'A rare gem of content',
    animation: 'shine',
    color: 'text-emerald-400'
  },
  { 
    id: 'crown', 
    name: 'Crown', 
    icon: Crown, 
    baseDvCost: 2500, 
    description: 'King/Queen of content!',
    animation: 'glow',
    color: 'text-amber-400'
  },
  { 
    id: 'diamond', 
    name: 'Diamond', 
    icon: Diamond, 
    baseDvCost: 5000, 
    description: 'Diamond-tier content!',
    animation: 'sparkle-intense',
    color: 'text-blue-400'
  },
  { 
    id: 'rocket', 
    name: 'Rocket', 
    icon: Rocket, 
    baseDvCost: 10000, 
    description: 'To the moon!',
    animation: 'launch',
    color: 'text-red-400'
  },
  { 
    id: 'trophy', 
    name: 'Trophy', 
    icon: Trophy, 
    baseDvCost: 25000, 
    description: 'Champion content creator!',
    animation: 'shine-gold',
    color: 'text-yellow-500'
  },
];

// Calculate gift price based on DV market value
const calculateGiftPrice = (baseDvCost: number): { dv: number; usd: number } => {
  // Dynamic pricing: as DV price increases, gift costs adjust
  const dvPrice = DV_PRICE_USD;
  
  // Minimum $0.01 per gift, scale up based on tier
  const minUsdValue = 0.01;
  const usdValue = Math.max(minUsdValue, baseDvCost * dvPrice);
  
  // Recalculate DV needed for target USD value
  const dvNeeded = Math.ceil(usdValue / dvPrice);
  
  return { dv: dvNeeded, usd: usdValue };
};

interface GiftShopProps {
  creatorAddress?: string;
  creatorName?: string;
}

export function GiftShop({ creatorAddress, creatorName }: GiftShopProps) {
  const { address, isConnected } = useAccount();
  const [selectedGift, setSelectedGift] = useState<GiftItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [showBuyDV, setShowBuyDV] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  // Get DV balance
  const { data: dvBalance, refetch: refetchBalance } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  const balanceDV = dvBalance ? parseFloat(formatUnits(dvBalance, 18)) : 0;

  // Send gift transaction
  const { writeContract: sendGift, data: sendHash, error: sendError } = useWriteContract();
  const { isSuccess: sendConfirmed } = useWaitForTransactionReceipt({ hash: sendHash });

  useEffect(() => {
    if (sendConfirmed) {
      setIsSending(false);
      setSendSuccess(true);
      refetchBalance();
      toast.success(`Sent ${quantity}x ${selectedGift?.name} to ${creatorName || 'creator'}!`);
      setTimeout(() => {
        setSendSuccess(false);
        setSelectedGift(null);
      }, 3000);
    }
  }, [sendConfirmed, selectedGift, quantity, creatorName, refetchBalance]);

  useEffect(() => {
    if (sendError) {
      setIsSending(false);
      toast.error('Failed to send gift: ' + (sendError as Error).message);
    }
  }, [sendError]);

  const handleSendGift = async () => {
    if (!selectedGift || !creatorAddress || !address) return;
    
    const { dv } = calculateGiftPrice(selectedGift.baseDvCost);
    const totalDv = dv * quantity;
    
    if (balanceDV < totalDv) {
      setShowBuyDV(true);
      return;
    }

    setIsSending(true);
    sendGift({
      address: APP_CONFIG.contracts.dvToken as `0x${string}`,
      abi: DV_TOKEN_ABI,
      functionName: 'transfer',
      args: [creatorAddress as `0x${string}`, parseUnits(totalDv.toString(), 18)]
    });
  };

  const selectedGiftPrice = selectedGift ? calculateGiftPrice(selectedGift.baseDvCost) : null;
  const totalCost = selectedGiftPrice ? selectedGiftPrice.dv * quantity : 0;
  const totalUsd = selectedGiftPrice ? selectedGiftPrice.usd * quantity : 0;

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-purple-500/30">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center mb-4">
            <Gift className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl text-white">Gift Shop</CardTitle>
          <p className="text-slate-400 text-sm mt-2">
            {creatorName ? `Support ${creatorName} with DV gifts` : 'Support your favorite creators'}
          </p>
          
          {/* Balance Display */}
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-slate-800/50 rounded-full">
            <span className="text-slate-400 text-sm">Your Balance:</span>
            <span className="text-amber-400 font-semibold">{balanceDV.toLocaleString()} DV</span>
            <span className="text-slate-500 text-sm">(~${(balanceDV * DV_PRICE_USD).toFixed(2)})</span>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Gift Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {GIFTS.map((gift) => {
              const price = calculateGiftPrice(gift.baseDvCost);
              const Icon = gift.icon;
              const isSelected = selectedGift?.id === gift.id;
              
              return (
                <button
                  key={gift.id}
                  onClick={() => setSelectedGift(gift)}
                  className={`p-4 rounded-xl border transition-all text-center ${
                    isSelected
                      ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500'
                      : 'bg-slate-800/50 border-slate-700 hover:border-purple-500/50 hover:bg-slate-700'
                  }`}
                >
                  <div className={`w-12 h-12 mx-auto mb-2 rounded-xl bg-slate-700 flex items-center justify-center ${gift.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <p className="text-white text-sm font-medium">{gift.name}</p>
                  <p className="text-amber-400 text-xs mt-1">{price.dv} DV</p>
                  <p className="text-slate-500 text-xs">~${price.usd.toFixed(2)}</p>
                </button>
              );
            })}
          </div>

          {/* Selected Gift Details */}
          {selectedGift && (
            <div className="bg-slate-800/50 rounded-xl p-6 border border-purple-500/30">
              <div className="flex items-start gap-4">
                <div className={`w-16 h-16 rounded-xl bg-slate-700 flex items-center justify-center ${selectedGift.color}`}>
                  <selectedGift.icon className="w-8 h-8" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white">{selectedGift.name}</h3>
                  <p className="text-slate-400 text-sm">{selectedGift.description}</p>
                  
                  <div className="flex items-center gap-4 mt-4">
                    <div>
                      <p className="text-xs text-slate-500">Cost per gift</p>
                      <p className="text-amber-400 font-semibold">{selectedGiftPrice?.dv} DV</p>
                      <p className="text-slate-500 text-xs">~${selectedGiftPrice?.usd.toFixed(2)}</p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-8 h-8 rounded-lg bg-slate-700 text-white hover:bg-slate-600"
                      >
                        -
                      </button>
                      <span className="w-12 text-center text-white font-semibold">{quantity}</span>
                      <button 
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-8 h-8 rounded-lg bg-slate-700 text-white hover:bg-slate-600"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-slate-700">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-slate-400">Total Cost</p>
                        <p className="text-xl font-bold text-white">{totalCost.toLocaleString()} DV</p>
                        <p className="text-slate-500 text-sm">~${totalUsd.toFixed(2)} USD</p>
                      </div>
                      
                      <Button
                        onClick={handleSendGift}
                        disabled={isSending || !creatorAddress}
                        className="bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold hover:from-pink-400 hover:to-purple-500"
                      >
                        {isSending ? 'Sending...' : sendSuccess ? (
                          <><CheckCircle className="w-4 h-4 mr-2" /> Sent!</>
                        ) : (
                          <><Send className="w-4 h-4 mr-2" /> Send Gift</>
                        )}
                      </Button>
                    </div>
                    
                    {balanceDV < totalCost && (
                      <p className="text-red-400 text-sm mt-2">
                        Insufficient balance. Need {totalCost.toLocaleString()} DV
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Buy DV Button */}
          <div className="text-center">
            <Button
              variant="outline"
              onClick={() => setShowBuyDV(true)}
              className="border-amber-500/50 text-amber-400 hover:bg-amber-500/10"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Buy DV with Card/Crypto
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Buy DV Dialog */}
      <Dialog open={showBuyDV} onOpenChange={setShowBuyDV}>
        <DialogContent className="bg-slate-900 border-slate-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white text-center">Buy DV Tokens</DialogTitle>
            <p className="text-slate-400 text-center text-sm">
              Purchase DV with your preferred payment method
            </p>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            {/* Current Price */}
            <div className="bg-slate-800/50 rounded-xl p-4 text-center">
              <p className="text-slate-400 text-sm">Current DV Price</p>
              <p className="text-2xl font-bold text-amber-400">${DV_PRICE_USD}</p>
              <p className="text-slate-500 text-xs">per DV token</p>
            </div>

            {/* Payment Options */}
            <div className="space-y-3">
              <a
                href="https://app.uniswap.org/#/swap?chain=base&inputCurrency=ETH&outputCurrency=0x804Ed08fd4f33570DF8d1b69E4FC2da12f14f8B6"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full p-4 rounded-xl bg-slate-800 border border-slate-700 hover:border-pink-500/50 hover:bg-slate-700 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center">
                    <ArrowRight className="w-5 h-5 text-pink-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Buy on Uniswap</p>
                    <p className="text-sm text-slate-500">Swap ETH/WETH for DV</p>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500" />
              </a>

              <a
                href="https://ramp.alchemypay.org/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full p-4 rounded-xl bg-slate-800 border border-slate-700 hover:border-blue-500/50 hover:bg-slate-700 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Buy with Card</p>
                    <p className="text-sm text-slate-500">via Alchemy Pay (ETH → DV)</p>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500" />
              </a>

              <a
                href="https://www.moonpay.com/buy"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full p-4 rounded-xl bg-slate-800 border border-slate-700 hover:border-purple-500/50 hover:bg-slate-700 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-purple-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Buy with MoonPay</p>
                    <p className="text-sm text-slate-500">Credit/Debit card → ETH → DV</p>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500" />
              </a>

              <a
                href="https://bridge.base.org/deposit"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full p-4 rounded-xl bg-slate-800 border border-slate-700 hover:border-emerald-500/50 hover:bg-slate-700 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <Bitcoin className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Bridge to Base</p>
                    <p className="text-sm text-slate-500">Bridge ETH from Ethereum → Base</p>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-500" />
              </a>
            </div>

            <p className="text-xs text-slate-500 text-center">
              After purchasing ETH, swap for DV on Uniswap
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default GiftShop;
