import { useState, useEffect } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { parseUnits, formatUnits } from 'viem';
import { 
  Send, 
  Wallet, 
  AlertCircle, 
  CheckCircle,
  TrendingUp,
  Info,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { APP_CONFIG } from '@/config/app.config';
import { toast } from 'sonner';

// DV Token ABI
const DV_TOKEN_ABI = [
  {
    inputs: [
      { internalType: 'address', name: 'recipient', type: 'address' },
      { internalType: 'uint256', name: 'amount', type: 'uint256' }
    ],
    name: 'transfer',
    outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    inputs: [{ internalType: 'address', name: 'account', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function'
  }
] as const;

// Fee tiers based on transfer amount
const FEE_TIERS = [
  { max: 100, feePercent: 0.5, label: 'Micro' },      // <$0.10
  { max: 1000, feePercent: 0.3, label: 'Small' },     // <$1
  { max: 10000, feePercent: 0.2, label: 'Medium' },   // <$10
  { max: 100000, feePercent: 0.1, label: 'Large' },   // <$100
  { max: Infinity, feePercent: 0.05, label: 'Whale' } // >$100
];

// DV price in USD (would come from oracle in production)
const DV_PRICE_USD = 0.001;

export function TokenTransfer() {
  const { address, isConnected, connector } = useAccount();
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  // Get DV balance
  const { data: dvBalance, refetch: refetchBalance } = useReadContract({
    address: APP_CONFIG.contracts.dvToken as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected }
  });

  // Calculate fee based on amount
  const calculateFee = (transferAmount: number): { feeDV: number; feePercent: number; tier: string } => {
    const tier = FEE_TIERS.find(t => transferAmount <= t.max) || FEE_TIERS[FEE_TIERS.length - 1];
    const feeDV = transferAmount * (tier.feePercent / 100);
    return { feeDV, feePercent: tier.feePercent, tier: tier.label };
  };

  const transferAmount = parseFloat(amount) || 0;
  const { feeDV, feePercent, tier } = calculateFee(transferAmount);
  const totalNeeded = transferAmount + feeDV;
  const balanceDV = dvBalance ? parseFloat(formatUnits(dvBalance, 18)) : 0;
  const hasEnoughBalance = balanceDV >= totalNeeded;

  // Send transaction
  const { writeContract: sendTokens, data: sendHash, error: sendError } = useWriteContract();
  const { isSuccess: sendConfirmed } = useWaitForTransactionReceipt({ hash: sendHash });

  useEffect(() => {
    if (sendConfirmed) {
      setIsSending(false);
      setSendSuccess(true);
      setAmount('');
      setRecipient('');
      refetchBalance();
      toast.success(`Successfully sent ${transferAmount} DV!`);
      setTimeout(() => setSendSuccess(false), 5000);
    }
  }, [sendConfirmed, transferAmount, refetchBalance]);

  useEffect(() => {
    if (sendError) {
      setIsSending(false);
      toast.error('Transfer failed: ' + (sendError as Error).message);
    }
  }, [sendError]);

  const handleSend = async () => {
    if (!recipient || !amount || !address) return;
    
    // Validate recipient address
    if (!recipient.startsWith('0x') || recipient.length !== 42) {
      toast.error('Invalid recipient address');
      return;
    }

    setIsSending(true);
    
    // Send tokens (in production, fee would be handled by contract)
    sendTokens({
      address: APP_CONFIG.contracts.dvToken as `0x${string}`,
      abi: DV_TOKEN_ABI,
      functionName: 'transfer',
      args: [recipient as `0x${string}`, parseUnits(amount, 18)]
    });
  };

  const formatWalletName = (name: string) => {
    return name.replace('Wallet', '').trim();
  };

  return (
    <TooltipProvider>
      <Card className="w-full max-w-lg mx-auto bg-gradient-to-br from-slate-900 to-slate-800 border-amber-500/30">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center mb-4">
            <Send className="w-8 h-8 text-amber-400" />
          </div>
          <CardTitle className="text-2xl text-white">Send DV Tokens</CardTitle>
          <p className="text-slate-400 text-sm mt-2">
            Transfer DV to any wallet on Base Network
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Wallet Info */}
          {isConnected && (
            <div className="bg-slate-800/50 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400 flex items-center gap-2">
                  <Wallet className="w-4 h-4" />
                  Connected Wallet
                </span>
                <Badge className="bg-emerald-500/20 text-emerald-400">
                  {formatWalletName(connector?.name || 'Unknown')}
                </Badge>
              </div>
              <p className="text-white font-mono text-sm">
                {address?.slice(0, 10)}...{address?.slice(-8)}
              </p>
            </div>
          )}

          {/* Balance Display */}
          <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 rounded-xl p-4 border border-amber-500/20">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-300">Your DV Balance</span>
              <span className="text-xl font-bold text-amber-400">
                {balanceDV.toLocaleString()} DV
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              ≈ ${(balanceDV * DV_PRICE_USD).toFixed(2)} USD
            </p>
          </div>

          {/* Recipient Input */}
          <div className="space-y-2">
            <label className="text-sm text-slate-400">Recipient Address</label>
            <Input
              type="text"
              placeholder="0x..."
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white font-mono"
            />
          </div>

          {/* Amount Input */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <label className="text-sm text-slate-400">Amount (DV)</label>
              <button 
                onClick={() => setAmount(balanceDV.toString())}
                className="text-xs text-amber-400 hover:text-amber-300"
              >
                MAX
              </button>
            </div>
            <Input
              type="number"
              placeholder="0.0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          {/* Fee Breakdown */}
          {transferAmount > 0 && (
            <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400 flex items-center gap-2">
                  Transfer Amount
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="w-4 h-4 text-slate-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Amount to be sent to recipient</p>
                    </TooltipContent>
                  </Tooltip>
                </span>
                <span className="text-white">{transferAmount.toLocaleString()} DV</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400 flex items-center gap-2">
                  Network Fee ({feePercent}%)
                  <Tooltip>
                    <TooltipTrigger>
                      <TrendingUp className="w-4 h-4 text-slate-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Fee tier: {tier} - Decreases with larger amounts</p>
                    </TooltipContent>
                  </Tooltip>
                </span>
                <span className="text-amber-400">{feeDV.toFixed(4)} DV</span>
              </div>

              <div className="border-t border-slate-700 pt-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white font-medium">Total Needed</span>
                  <span className="text-lg font-bold text-white">
                    {totalNeeded.toLocaleString()} DV
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 text-right">
                  ≈ ${(totalNeeded * DV_PRICE_USD).toFixed(4)} USD
                </p>
              </div>
            </div>
          )}

          {/* Error Message */}
          {!hasEnoughBalance && transferAmount > 0 && (
            <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 rounded-lg p-3">
              <AlertCircle className="w-4 h-4" />
              Insufficient balance. Need {totalNeeded.toLocaleString()} DV, have {balanceDV.toLocaleString()} DV
            </div>
          )}

          {/* Send Button */}
          <Button
            onClick={handleSend}
            disabled={isSending || !recipient || !amount || !hasEnoughBalance}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold hover:from-amber-400 hover:to-amber-500 disabled:opacity-50"
          >
            {isSending ? (
              <span className="flex items-center gap-2">
                Sending...
              </span>
            ) : sendSuccess ? (
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Sent Successfully!
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Send className="w-4 h-4" />
                Send DV
              </span>
            )}
          </Button>

          {/* Transaction Link */}
          {sendHash && (
            <a
              href={`${APP_CONFIG.network.explorer}/tx/${sendHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-amber-400 hover:text-amber-300 text-center flex items-center justify-center gap-1"
            >
              View on BaseScan
              <ExternalLink className="w-3 h-3" />
            </a>
          )}

          {/* Fee Schedule */}
          <div className="bg-slate-800/30 rounded-xl p-4">
            <h4 className="text-sm font-medium text-white mb-3">Fee Schedule</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {FEE_TIERS.map((t, i) => (
                <div key={i} className="flex justify-between py-1">
                  <span className="text-slate-400">{t.label}</span>
                  <span className="text-amber-400">{t.feePercent}%</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Fees decrease as transfer amount increases
            </p>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
}

export default TokenTransfer;
