import { useState } from 'react';
import { useAccount } from 'wagmi';
import { useReadContract } from 'wagmi';
import { 
  DV_TOKEN_ADDRESS,
  DV_TOKEN_ABI,
  formatDVAmount,
  useDynamicPricing
} from '@/lib/web3';
import { useDVTier } from '@/hooks/useDVTier';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Coins, 
  Heart,
  Share2,
  MessageCircle,
  Plus,
  Zap,
  ShoppingCart
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface ContentPost {
  id: string;
  author: string;
  authorTier: number;
  content: string;
  imageUrl?: string;
  coinName: string;
  coinSymbol: string;
  coinPrice: number;
  coinSupply: number;
  likes: number;
  comments: number;
  shares: number;
  timestamp: number;
  revenueGenerated: number;
}

// Mock content posts
const mockPosts: ContentPost[] = [
  {
    id: '1',
    author: 'CryptoKing',
    authorTier: 4,
    content: 'Just analyzed the DV market trend! The tier system is driving serious demand. My prediction: DV hits $0.005 by end of quarter. 🚀',
    coinName: 'KingCoin',
    coinSymbol: 'KING',
    coinPrice: 0.001,
    coinSupply: 10000,
    likes: 234,
    comments: 45,
    shares: 89,
    timestamp: Date.now() - 3600000,
    revenueGenerated: 125.50,
  },
  {
    id: '2',
    author: 'DeFiQueen',
    authorTier: 3,
    content: 'Staking update: My 1-year DV lock is printing 20% APR! The AI burn mechanism is creating real deflationary pressure on AIC. 📈',
    coinName: 'QueenToken',
    coinSymbol: 'QUEEN',
    coinPrice: 0.0005,
    coinSupply: 5000,
    likes: 156,
    comments: 32,
    shares: 67,
    timestamp: Date.now() - 7200000,
    revenueGenerated: 78.25,
  },
  {
    id: '3',
    author: 'BaseBuilder',
    authorTier: 2,
    content: 'New to DV ecosystem? Here\'s my guide to maximizing tier benefits. Start with Bronze, work your way up! 💎',
    coinName: 'BuilderCoin',
    coinSymbol: 'BUILD',
    coinPrice: 0.0002,
    coinSupply: 2500,
    likes: 89,
    comments: 23,
    shares: 45,
    timestamp: Date.now() - 10800000,
    revenueGenerated: 34.80,
  },
];

// Calculate content coin price based on DV market value
const calculateCoinPrice = (dvPriceUSD: number, tier: number): number => {
  // Base price scales with DV value and author tier
  const basePrice = dvPriceUSD * 0.1; // 10% of DV price
  const tierMultiplier = 1 + (tier * 0.25); // Higher tier = higher base price
  return basePrice * tierMultiplier;
};

export function ContentCoinSystem() {
  const { isConnected, address } = useAccount();
  const { tier, hasProfileAccess } = useDVTier();
  const { dvPriceUSD } = useDynamicPricing();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [selectedPost, setSelectedPost] = useState<ContentPost | null>(null);
  const [buyAmount, setBuyAmount] = useState('100');
  
  const [newPost, setNewPost] = useState({
    content: '',
    coinName: '',
    coinSymbol: '',
    coinSupply: '1000',
  });

  // Get DV balance
  const { data: dvBalance } = useReadContract({
    address: DV_TOKEN_ADDRESS as `0x${string}`,
    abi: DV_TOKEN_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: isConnected && !!address },
  });

  // User DV balance available for future use
  dvBalance;

  // Dynamic coin creation fee (scales with DV price)
  const coinCreationFee = Math.ceil(50 / dvPriceUSD); // ~$50 worth of DV
  const coinCreationFeeDV = BigInt(coinCreationFee) * 10n ** 18n;

  const handleCreatePost = async () => {
    if (!newPost.content || !newPost.coinName || !newPost.coinSymbol) return;
    
    // Create content coin
    const coinPrice = calculateCoinPrice(dvPriceUSD, tier);
    console.log('Creating coin:', {
      name: newPost.coinName,
      symbol: newPost.coinSymbol,
      price: coinPrice,
      supply: newPost.coinSupply,
    });
    
    setShowCreateModal(false);
    setNewPost({ content: '', coinName: '', coinSymbol: '', coinSupply: '1000' });
  };

  const handleBuyCoin = async () => {
    if (!selectedPost || !buyAmount) return;
    
    const totalCost = selectedPost.coinPrice * Number(buyAmount);
    const appRevenue = totalCost * 0.10; // 10% to app revenue
    
    console.log('Buying coin:', {
      coin: selectedPost.coinSymbol,
      amount: buyAmount,
      totalCost,
      appRevenue,
    });
    
    setShowBuyModal(false);
    setBuyAmount('100');
  };

  const getTierColor = (tierNum: number) => {
    const colors = ['gray', 'amber', 'slate', 'yellow', 'cyan'];
    return colors[tierNum] || 'gray';
  };

  const getTierName = (tierNum: number) => {
    const names = ['None', 'Bronze', 'Silver', 'Gold', 'Platinum'];
    return names[tierNum] || 'Unknown';
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Coins className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to view content feed</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 border-pink-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                <Coins className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-xl">Content Feed</CardTitle>
                <CardDescription className="text-white/50">
                  Create posts & earn from content coin sales
                </CardDescription>
              </div>
            </div>
            {hasProfileAccess && (
              <Button 
                onClick={() => setShowCreateModal(true)}
                className="bg-gradient-to-r from-pink-500 to-purple-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Post
              </Button>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* Revenue Info */}
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-6">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-sm text-white/50 mb-1">Creator Earnings</p>
              <p className="text-xl font-bold text-emerald-400">90%</p>
              <p className="text-xs text-white/40">of coin sales</p>
            </div>
            <div>
              <p className="text-sm text-white/50 mb-1">App Revenue</p>
              <p className="text-xl font-bold text-amber-400">10%</p>
              <p className="text-xs text-white/40">to ecosystem</p>
            </div>
            <div>
              <p className="text-sm text-white/50 mb-1">Coin Price</p>
              <p className="text-xl font-bold text-purple-400">Dynamic</p>
              <p className="text-xs text-white/40">scales with DV</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Posts Feed */}
      <div className="space-y-4">
        {mockPosts.map((post) => (
          <Card key={post.id} className="bg-white/[0.02] border-white/10 hover:border-white/20 transition-colors">
            <CardContent className="p-6">
              {/* Author Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className={`bg-${getTierColor(post.authorTier)}-500/20 text-${getTierColor(post.authorTier)}-400`}>
                      {post.author.slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-white font-medium">{post.author}</p>
                    <div className="flex items-center gap-2">
                      <Badge className={`bg-${getTierColor(post.authorTier)}-500/20 text-${getTierColor(post.authorTier)}-400 text-xs`}>
                        {getTierName(post.authorTier)}
                      </Badge>
                      <span className="text-xs text-white/40">
                        {new Date(post.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-emerald-400 font-medium">${post.revenueGenerated.toFixed(2)}</p>
                  <p className="text-xs text-white/40">earned</p>
                </div>
              </div>

              {/* Content */}
              <p className="text-white/80 mb-4">{post.content}</p>

              {/* Content Coin */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-500/20 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                      <span className="text-white font-bold text-sm">{post.coinSymbol.slice(0, 2)}</span>
                    </div>
                    <div>
                      <p className="text-white font-medium">{post.coinName}</p>
                      <p className="text-sm text-pink-400">{post.coinSymbol}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium">${post.coinPrice.toFixed(6)}</p>
                    <p className="text-xs text-white/40">{post.coinSupply.toLocaleString()} supply</p>
                  </div>
                </div>
                <Button 
                  onClick={() => { setSelectedPost(post); setShowBuyModal(true); }}
                  className="w-full mt-3 bg-gradient-to-r from-pink-500 to-purple-600"
                  size="sm"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy {post.coinSymbol}
                </Button>
              </div>

              {/* Engagement */}
              <div className="flex items-center gap-6 text-white/50">
                <button className="flex items-center gap-1 hover:text-pink-400 transition-colors">
                  <Heart className="w-4 h-4" />
                  <span className="text-sm">{post.likes}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-aether-blue transition-colors">
                  <MessageCircle className="w-4 h-4" />
                  <span className="text-sm">{post.comments}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-emerald-400 transition-colors">
                  <Share2 className="w-4 h-4" />
                  <span className="text-sm">{post.shares}</span>
                </button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create Post Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <Plus className="w-6 h-6 text-pink-400" />
              Create Content Post
            </DialogTitle>
            <DialogDescription className="text-white/60">
              Share insights and create your own content coin
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label className="text-white/70">Your Content</Label>
              <Textarea
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                placeholder="Share your crypto insights, analysis, or predictions..."
                className="bg-white/5 border-white/10 text-white min-h-[100px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-white/70">Coin Name</Label>
                <Input
                  value={newPost.coinName}
                  onChange={(e) => setNewPost({ ...newPost, coinName: e.target.value })}
                  placeholder="MyCoin"
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-white/70">Coin Symbol</Label>
                <Input
                  value={newPost.coinSymbol}
                  onChange={(e) => setNewPost({ ...newPost, coinSymbol: e.target.value.toUpperCase() })}
                  placeholder="MYC"
                  maxLength={6}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70">Initial Supply</Label>
              <Input
                type="number"
                value={newPost.coinSupply}
                onChange={(e) => setNewPost({ ...newPost, coinSupply: e.target.value })}
                className="bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="p-4 rounded-xl bg-pink-500/10 border border-pink-500/20">
              <p className="text-sm text-white/60 mb-2">Coin Creation Fee</p>
              <div className="flex justify-between items-center">
                <span className="text-pink-400 font-medium">{formatDVAmount(coinCreationFeeDV)} DV</span>
                <span className="text-white/50">~$50 USD</span>
              </div>
              <p className="text-xs text-white/40 mt-1">
                Your coin price will be ${calculateCoinPrice(dvPriceUSD, tier).toFixed(6)} (scales with DV)
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 border-white/10"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreatePost}
                className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600"
              >
                <Zap className="w-4 h-4 mr-2" />
                Create & Post
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Buy Coin Modal */}
      <Dialog open={showBuyModal} onOpenChange={setShowBuyModal}>
        <DialogContent className="bg-aether-dark border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <ShoppingCart className="w-6 h-6 text-emerald-400" />
              Buy {selectedPost?.coinSymbol}
            </DialogTitle>
          </DialogHeader>

          {selectedPost && (
            <div className="space-y-4 mt-4">
              <div className="p-4 rounded-xl bg-white/5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                    <span className="text-white font-bold">{selectedPost.coinSymbol.slice(0, 2)}</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">{selectedPost.coinName}</p>
                    <p className="text-pink-400">{selectedPost.coinSymbol}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white/70">Amount to Buy</Label>
                <Input
                  type="number"
                  value={buyAmount}
                  onChange={(e) => setBuyAmount(e.target.value)}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>

              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Price per coin</span>
                    <span className="text-white">${selectedPost.coinPrice.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Amount</span>
                    <span className="text-white">{buyAmount} {selectedPost.coinSymbol}</span>
                  </div>
                  <div className="border-t border-white/10 pt-2">
                    <div className="flex justify-between">
                      <span className="text-white/60">Total Cost</span>
                      <span className="text-emerald-400 font-medium">
                        ${(selectedPost.coinPrice * Number(buyAmount)).toFixed(6)}
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-amber-400">App Revenue (10%)</span>
                    <span className="text-amber-400">
                      ${(selectedPost.coinPrice * Number(buyAmount) * 0.10).toFixed(6)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowBuyModal(false)}
                  className="flex-1 border-white/10"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleBuyCoin}
                  className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy Now
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
