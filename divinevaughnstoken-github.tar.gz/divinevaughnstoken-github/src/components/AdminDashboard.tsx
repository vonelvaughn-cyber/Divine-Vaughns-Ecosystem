import { useState, useEffect, useRef } from 'react';
import { useAccount } from 'wagmi';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { 
  Shield, 
  Github, 
  Bot, 
  Settings, 
  Users, 
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Send,
  Code,
  FileCode,
  GitBranch,
  Lock,
  Cpu
} from 'lucide-react';


// Admin addresses (in production, this would be checked against a smart contract)
const ADMIN_ADDRESSES = [
  '0x742d35Cc6634C0532925a3b844Bc9e7595f8aE3e', // Example admin
];

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  type?: 'code' | 'text' | 'command';
}

interface GitHubRepo {
  name: string;
  url: string;
  branch: string;
  lastCommit: string;
  status: 'synced' | 'pending' | 'error';
}

interface SystemStatus {
  totalUsers: number;
  activeStakers: number;
  totalStaked: string;
  botSessions24h: number;
  dvPrice: number;
  platformRevenue: string;
}

export function AdminDashboard() {
  const { address, isConnected } = useAccount();
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeTab, setActiveTab] = useState('ai-chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isAiResponding, setIsAiResponding] = useState(false);
  const [githubToken, setGithubToken] = useState('');
  const [githubRepo, setGithubRepo] = useState('');
  const [isConnectedToGitHub, setIsConnectedToGitHub] = useState(false);
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [systemStatus] = useState<SystemStatus>({
    totalUsers: 1247,
    activeStakers: 523,
    totalStaked: '45,230,000',
    botSessions24h: 189,
    dvPrice: 0.001,
    platformRevenue: '12,450',
  });
  const [pendingChanges, setPendingChanges] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Check if connected wallet is admin
  useEffect(() => {
    if (address) {
      setIsAdmin(ADMIN_ADDRESSES.includes(address) || true); // Allow all for demo
    }
  }, [address]);

  // Scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Send message to AI
  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: Date.now(),
      type: 'text',
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsAiResponding(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAiResponse(inputMessage);
      setMessages(prev => [...prev, aiResponse]);
      setIsAiResponding(false);
    }, 1500);
  };

  // Generate AI response based on user input
  const generateAiResponse = (input: string): ChatMessage => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('change color') || lowerInput.includes('update color')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: `I'll help you update the color scheme. Here's the code change needed:

\`\`\`css
/* Update in src/index.css */
:root {
  --aether-blue: 217 91% 60%;
  --aether-purple: 263 70% 60%;
  --aether-pink: 330 80% 60%;
}
\`\`\`

Would you like me to commit this change to GitHub?`,
        timestamp: Date.now(),
        type: 'code',
      };
    }

    if (lowerInput.includes('add component') || lowerInput.includes('new component')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: `I can help you add a new component. What type of component would you like to create?

Options:
1. **UI Component** - Button, Card, Modal, etc.
2. **Feature Component** - Dashboard widget, Chart, etc.
3. **Page Section** - Hero, Features, Pricing, etc.

Please describe what you need and I'll generate the code.`,
        timestamp: Date.now(),
        type: 'text',
      };
    }

    if (lowerInput.includes('deploy') || lowerInput.includes('push')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: `I'll prepare the deployment for you. Current status:

✅ All tests passing
✅ Build successful
✅ No merge conflicts

**Pending changes:**
${pendingChanges.length > 0 ? pendingChanges.map(c => `- ${c}`).join('\n') : '- No pending changes'}

Ready to deploy to production?`,
        timestamp: Date.now(),
        type: 'command',
      };
    }

    if (lowerInput.includes('status') || lowerInput.includes('stats')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: `**Platform Status:**

📊 **Users:** ${systemStatus.totalUsers.toLocaleString()} total
🔒 **Active Stakers:** ${systemStatus.activeStakers.toLocaleString()}
💰 **Total Staked:** ${systemStatus.totalStaked} DV
🤖 **Bot Sessions (24h):** ${systemStatus.botSessions24h}
💵 **DV Price:** $${systemStatus.dvPrice.toFixed(4)}
📈 **Platform Revenue:** ${systemStatus.platformRevenue} DV

Everything is running smoothly!`,
        timestamp: Date.now(),
        type: 'text',
      };
    }

    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: `I'm your AI admin assistant. I can help you with:

🎨 **Design Changes** - Colors, typography, layouts
💻 **Code Updates** - Components, features, bug fixes
🚀 **Deployments** - Push changes to production
📊 **Analytics** - View platform stats and metrics
🔧 **Configuration** - Update settings and parameters

What would you like to do?`,
      timestamp: Date.now(),
      type: 'text',
    };
  };

  // Connect to GitHub
  const connectGitHub = () => {
    if (githubToken && githubRepo) {
      setIsConnectedToGitHub(true);
      setRepos([{
        name: githubRepo.split('/').pop() || 'aether-platform',
        url: `https://github.com/${githubRepo}`,
        branch: 'main',
        lastCommit: '2 minutes ago',
        status: 'synced',
      }]);
    }
  };

  // Commit changes to GitHub
  const commitChanges = () => {
    setPendingChanges([]);
    // Simulate commit
    alert('Changes committed successfully!');
  };

  if (!isConnected) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Shield className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/50">Connect wallet to access admin dashboard</p>
        </CardContent>
      </Card>
    );
  }

  if (!isAdmin) {
    return (
      <Card className="bg-white/[0.02] border-white/10">
        <CardContent className="p-8 text-center">
          <Lock className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <p className="text-white font-medium mb-2">Access Denied</p>
          <p className="text-white/50">This wallet is not authorized as an admin</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/[0.02] border-white/10">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-aether-blue to-aether-purple flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-white">Admin Dashboard</CardTitle>
              <CardDescription className="text-white/50">
                Manage platform settings and communicate with AI
              </CardDescription>
            </div>
          </div>
          <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
            <CheckCircle className="w-3 h-3 mr-1" />
            Admin Access
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full bg-white/5 border border-white/10 mb-6">
            <TabsTrigger value="ai-chat" className="data-[state=active]:bg-white/10">
              <Bot className="w-4 h-4 mr-2" />
              AI Assistant
            </TabsTrigger>
            <TabsTrigger value="github" className="data-[state=active]:bg-white/10">
              <Github className="w-4 h-4 mr-2" />
              GitHub
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-white/10">
              <TrendingUp className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-white/10">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* AI Chat Tab */}
          <TabsContent value="ai-chat" className="space-y-4">
            <div className="h-[400px] border border-white/10 rounded-xl bg-black/20 flex flex-col">
              <ScrollArea className="flex-1 p-4">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8">
                    <Bot className="w-12 h-12 text-aether-blue mb-4" />
                    <h4 className="text-lg font-medium text-white mb-2">AI Admin Assistant</h4>
                    <p className="text-white/50 max-w-md">
                      I can help you make changes to the app, deploy updates, and manage the platform. 
                      Just tell me what you'd like to do!
                    </p>
                    <div className="flex flex-wrap gap-2 mt-6 justify-center">
                      {['Change colors', 'Add component', 'View stats', 'Deploy changes'].map((suggestion) => (
                        <button
                          key={suggestion}
                          onClick={() => {
                            setInputMessage(suggestion);
                            sendMessage();
                          }}
                          className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white/70 hover:bg-white/10 hover:text-white transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] p-4 rounded-2xl ${
                            message.role === 'user'
                              ? 'bg-gradient-to-r from-aether-blue to-aether-purple text-white'
                              : 'bg-white/5 border border-white/10 text-white'
                          }`}
                        >
                          {message.type === 'code' ? (
                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-xs text-white/50 mb-2">
                                <Code className="w-3 h-3" />
                                Code
                              </div>
                              <pre className="bg-black/30 p-3 rounded-lg overflow-x-auto text-sm font-mono">
                                <code>{message.content}</code>
                              </pre>
                            </div>
                          ) : (
                            <div className="whitespace-pre-wrap">{message.content}</div>
                          )}
                          <div className={`text-xs mt-2 ${message.role === 'user' ? 'text-white/60' : 'text-white/40'}`}>
                            {new Date(message.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    ))}
                    {isAiResponding && (
                      <div className="flex justify-start">
                        <div className="bg-white/5 border border-white/10 p-4 rounded-2xl">
                          <div className="flex gap-1">
                            <div className="w-2 h-2 bg-aether-blue rounded-full animate-bounce" />
                            <div className="w-2 h-2 bg-aether-purple rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                            <div className="w-2 h-2 bg-aether-pink rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>

              <div className="p-4 border-t border-white/10">
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask AI to make changes..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                    className="flex-1 bg-white/5 border-white/10 text-white"
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={!inputMessage.trim() || isAiResponding}
                    className="bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* GitHub Tab */}
          <TabsContent value="github" className="space-y-6">
            {!isConnectedToGitHub ? (
              <div className="p-8 rounded-xl bg-white/5 border border-white/10 text-center">
                <Github className="w-12 h-12 text-white/30 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-white mb-2">Connect GitHub</h4>
                <p className="text-white/50 mb-6">Link your GitHub repository to enable AI-powered deployments</p>
                <div className="max-w-md mx-auto space-y-4">
                  <div className="space-y-2 text-left">
                    <Label className="text-white/70">GitHub Token</Label>
                    <Input
                      type="password"
                      placeholder="ghp_xxxxxxxxxxxx"
                      value={githubToken}
                      onChange={(e) => setGithubToken(e.target.value)}
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <div className="space-y-2 text-left">
                    <Label className="text-white/70">Repository (owner/repo)</Label>
                    <Input
                      placeholder="username/aether-platform"
                      value={githubRepo}
                      onChange={(e) => setGithubRepo(e.target.value)}
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <Button
                    onClick={connectGitHub}
                    disabled={!githubToken || !githubRepo}
                    className="w-full bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Connect GitHub
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Github className="w-6 h-6 text-white" />
                    <div>
                      <p className="text-white font-medium">{repos[0]?.name}</p>
                      <p className="text-sm text-white/50">{repos[0]?.url}</p>
                    </div>
                  </div>
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Connected
                  </Badge>
                </div>

                {/* Pending Changes */}
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-white font-medium flex items-center gap-2">
                      <FileCode className="w-4 h-4" />
                      Pending Changes
                    </h4>
                    {pendingChanges.length > 0 && (
                      <Button
                        size="sm"
                        onClick={commitChanges}
                        className="bg-gradient-to-r from-aether-blue to-aether-purple hover:opacity-90"
                      >
                        <GitBranch className="w-4 h-4 mr-2" />
                        Commit & Push
                      </Button>
                    )}
                  </div>
                  {pendingChanges.length === 0 ? (
                    <p className="text-white/50 text-center py-4">No pending changes</p>
                  ) : (
                    <div className="space-y-2">
                      {pendingChanges.map((change, index) => (
                        <div key={index} className="flex items-center gap-2 p-2 rounded-lg bg-white/5">
                          <Code className="w-4 h-4 text-aether-blue" />
                          <span className="text-sm text-white">{change}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Repository Stats */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 rounded-xl bg-white/5 text-center">
                    <p className="text-2xl font-bold text-white">{repos[0]?.branch}</p>
                    <p className="text-sm text-white/50">Branch</p>
                  </div>
                  <div className="p-4 rounded-xl bg-white/5 text-center">
                    <p className="text-2xl font-bold text-white">{repos[0]?.lastCommit}</p>
                    <p className="text-sm text-white/50">Last Commit</p>
                  </div>
                  <div className="p-4 rounded-xl bg-white/5 text-center">
                    <p className="text-2xl font-bold text-emerald-400">{repos[0]?.status}</p>
                    <p className="text-sm text-white/50">Status</p>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="p-6 rounded-xl bg-gradient-to-br from-aether-blue/20 to-transparent border border-aether-blue/20">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-aether-blue" />
                  <span className="text-sm text-white/60">Total Users</span>
                </div>
                <p className="text-3xl font-bold text-white">{systemStatus.totalUsers.toLocaleString()}</p>
              </div>
              <div className="p-6 rounded-xl bg-gradient-to-br from-aether-purple/20 to-transparent border border-aether-purple/20">
                <div className="flex items-center gap-2 mb-2">
                  <Lock className="w-5 h-5 text-aether-purple" />
                  <span className="text-sm text-white/60">Active Stakers</span>
                </div>
                <p className="text-3xl font-bold text-white">{systemStatus.activeStakers.toLocaleString()}</p>
              </div>
              <div className="p-6 rounded-xl bg-gradient-to-br from-emerald-500/20 to-transparent border border-emerald-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <span className="text-sm text-white/60">Total Staked</span>
                </div>
                <p className="text-3xl font-bold text-white">{systemStatus.totalStaked}</p>
              </div>
              <div className="p-6 rounded-xl bg-gradient-to-br from-amber-500/20 to-transparent border border-amber-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Bot className="w-5 h-5 text-amber-400" />
                  <span className="text-sm text-white/60">Bot Sessions (24h)</span>
                </div>
                <p className="text-3xl font-bold text-white">{systemStatus.botSessions24h}</p>
              </div>
              <div className="p-6 rounded-xl bg-gradient-to-br from-cyan-500/20 to-transparent border border-cyan-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Cpu className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm text-white/60">DV Price</span>
                </div>
                <p className="text-3xl font-bold text-white">${systemStatus.dvPrice.toFixed(4)}</p>
              </div>
              <div className="p-6 rounded-xl bg-gradient-to-br from-pink-500/20 to-transparent border border-pink-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-pink-400" />
                  <span className="text-sm text-white/60">Platform Revenue</span>
                </div>
                <p className="text-3xl font-bold text-white">{systemStatus.platformRevenue}</p>
              </div>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="space-y-4">
              <h4 className="text-white font-medium">Platform Settings</h4>
              
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Maintenance Mode</p>
                    <p className="text-sm text-white/50">Temporarily disable all user actions</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">New User Registration</p>
                    <p className="text-sm text-white/50">Allow new users to create profiles</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Staking Enabled</p>
                    <p className="text-sm text-white/50">Allow users to stake DV tokens</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">AI Bot Service</p>
                    <p className="text-sm text-white/50">Enable AI market bot purchases</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-400">Danger Zone</p>
                    <p className="text-sm text-white/60 mt-1">
                      These settings affect all users. Changes are logged and require confirmation.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
