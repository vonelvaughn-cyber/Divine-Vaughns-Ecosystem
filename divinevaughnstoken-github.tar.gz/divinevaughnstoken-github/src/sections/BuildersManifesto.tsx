import { useRef, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Hammer, 
  Users, 
  TrendingUp, 
  TrendingDown,
  CheckCircle2,
  XCircle,
  Lightbulb,
  Code,
  Palette,
  BookOpen,
  ArrowRight
} from 'lucide-react';

const builderTypes = [
  {
    icon: Code,
    title: 'Developers',
    description: 'Building the infrastructure that remembers',
    examples: ['Smart contracts', 'Bridge protocols', 'Verification systems'],
  },
  {
    icon: Palette,
    title: 'Creators',
    description: 'Creating content that contributes value',
    examples: ['Educational content', 'Art & media', 'Community building'],
  },
  {
    icon: BookOpen,
    title: 'Educators',
    description: 'Teaching the principles of true value',
    examples: ['Documentation', 'Tutorials', 'Philosophy'],
  },
];

const comparison = [
  {
    aspect: 'Mindset',
    builders: 'Create lasting value',
    speculators: 'Extract short-term gains',
  },
  {
    aspect: 'Time Horizon',
    builders: 'Years, decades',
    speculators: 'Days, weeks',
  },
  {
    aspect: 'Contribution',
    builders: 'Adds to the system',
    speculators: 'Drains from the system',
  },
  {
    aspect: 'Memory',
    builders: 'Remembered by the system',
    speculators: 'Forgotten quickly',
  },
];

export function BuildersManifesto() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-32 px-6 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #101520 0%, #0a0a0f 100%)' }}
    >
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-6">
            <Hammer className="w-4 h-4 text-emerald-400" />
            <span className="text-sm text-emerald-300 tracking-wider uppercase">The Manifesto</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            For People Who <span className="text-emerald-400">Build</span>,
            <br />
            <span className="text-white/40">Not Speculate</span>
          </h2>

          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            This system is designed for those who create, contribute, and construct 
            lasting value—not those who extract and disappear.
          </p>
        </div>

        {/* Builder Types */}
        <div
          className={`grid md:grid-cols-3 gap-6 mb-16 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {builderTypes.map((type, i) => {
            const Icon = type.icon;
            return (
              <Card
                key={i}
                className="bg-gradient-to-br from-emerald-500/5 to-teal-500/5 border-emerald-500/20 hover:border-emerald-500/40 transition-all duration-300"
              >
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-6">
                    <Icon className="w-7 h-7 text-emerald-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{type.title}</h3>
                  <p className="text-white/60 mb-4">{type.description}</p>
                  <div className="space-y-2">
                    {type.examples.map((example, j) => (
                      <div key={j} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-sm text-white/50">{example}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Comparison Table */}
        <div
          className={`mb-16 transition-all duration-1000 delay-400 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Card className="bg-white/5 border-white/10 overflow-hidden">
            <CardContent className="p-0">
              <div className="grid grid-cols-3 gap-0">
                {/* Header Row */}
                <div className="p-4 border-b border-white/10 bg-white/5">
                  <span className="text-white/40 text-sm">Aspect</span>
                </div>
                <div className="p-4 border-b border-white/10 bg-emerald-500/10">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 font-medium">Builders</span>
                  </div>
                </div>
                <div className="p-4 border-b border-white/10 bg-red-500/10">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="w-4 h-4 text-red-400" />
                    <span className="text-red-400 font-medium">Speculators</span>
                  </div>
                </div>

                {/* Data Rows */}
                {comparison.map((row, i) => (
                  <>
                    <div key={`aspect-${i}`} className="p-4 border-b border-white/5">
                      <span className="text-white/60">{row.aspect}</span>
                    </div>
                    <div key={`builder-${i}`} className="p-4 border-b border-white/5 bg-emerald-500/5">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-white/80">{row.builders}</span>
                      </div>
                    </div>
                    <div key={`speculator-${i}`} className="p-4 border-b border-white/5 bg-red-500/5">
                      <div className="flex items-center gap-2">
                        <XCircle className="w-4 h-4 text-red-400" />
                        <span className="text-white/50">{row.speculators}</span>
                      </div>
                    </div>
                  </>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* The Invitation */}
        <div
          className={`text-center transition-all duration-1000 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Card className="bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/30 max-w-3xl mx-auto">
            <CardContent className="p-8 md:p-12">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-emerald-400" />
              </div>

              <h3 className="text-2xl font-bold text-white mb-4">
                Join The Builders
              </h3>

              <p className="text-white/70 mb-6 leading-relaxed">
                If you believe in creating value that outlasts the hype cycles, 
                if you want your contributions to be remembered by the system itself, 
                you are already one of us.
              </p>

              <div className="flex flex-wrap justify-center gap-3 mb-8">
                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 px-4 py-2">
                  <Lightbulb className="w-4 h-4 mr-2" />
                  Create
                </Badge>
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 px-4 py-2">
                  <Code className="w-4 h-4 mr-2" />
                  Build
                </Badge>
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 px-4 py-2">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Teach
                </Badge>
              </div>

              <Button
                size="lg"
                onClick={() => window.dispatchEvent(new CustomEvent('launchApp'))}
                className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-semibold px-8"
              >
                Start Building
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
