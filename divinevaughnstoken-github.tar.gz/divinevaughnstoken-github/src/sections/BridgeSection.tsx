import { useRef, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Link2, Shield, Zap, Globe, Lock, Wallet } from 'lucide-react';

const bridgeFeatures = [
  {
    icon: Link2,
    title: 'Cross-Chain Execution',
    description: 'Seamlessly move value across blockchain networks while maintaining the integrity of contribution records.',
  },
  {
    icon: Shield,
    title: 'Verification Layer',
    description: 'Every transaction is verified against the principle: does this reflect true value?',
  },
  {
    icon: Zap,
    title: 'Native Settlement',
    description: 'DV is the required asset for all protocol-level operations. No shortcuts. No substitutes.',
  },
  {
    icon: Globe,
    title: 'Universal Bridge',
    description: 'Connect ecosystems while preserving the memory of human effort across all chains.',
  },
];

export function BridgeSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-32 px-6 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #151210 0%, #0a0a0f 50%, #101520 100%)' }}
    >
      {/* Bridge Visual */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Central light beam */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-full bg-gradient-to-b from-transparent via-amber-500/30 to-transparent" />
        
        {/* Arched bridge structure */}
        <svg
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] opacity-10"
          viewBox="0 0 800 400"
        >
          <path
            d="M 100 400 Q 400 50 700 400"
            fill="none"
            stroke="url(#bridgeGradient)"
            strokeWidth="2"
          />
          <path
            d="M 150 400 Q 400 100 650 400"
            fill="none"
            stroke="url(#bridgeGradient)"
            strokeWidth="1"
            opacity="0.5"
          />
          <defs>
            <linearGradient id="bridgeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#d4af37" />
              <stop offset="50%" stopColor="#ffd700" />
              <stop offset="100%" stopColor="#d4af37" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 mb-6">
            <Lock className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-blue-300 tracking-wider uppercase">Protocol Layer</span>
          </div>

          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Vaughns <span className="text-amber-400">Bridge</span>
          </h2>

          <p className="text-xl text-white/60 max-w-2xl mx-auto leading-relaxed">
            The native fee and settlement asset for cross-chain execution and verification.
          </p>
        </div>

        {/* Core Statement */}
        <div
          className={`mb-16 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Card className="bg-gradient-to-br from-amber-500/10 via-blue-500/5 to-purple-500/10 border-amber-500/20 max-w-4xl mx-auto">
            <CardContent className="p-8 md:p-12 text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-black">DV</span>
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-4">
                The Vaughns Token
              </h3>
              
              <p className="text-lg text-white/70 leading-relaxed mb-6">
                "The Vaughns token is the native fee and settlement asset for Vaughns Bridge, 
                required for protocol-level operations including cross-chain execution and verification."
              </p>

              <div className="flex flex-wrap justify-center gap-4">
                <div className="px-4 py-2 rounded-full bg-amber-500/20 border border-amber-500/30">
                  <span className="text-amber-400 text-sm">Native Fee Asset</span>
                </div>
                <div className="px-4 py-2 rounded-full bg-blue-500/20 border border-blue-500/30">
                  <span className="text-blue-400 text-sm">Settlement Layer</span>
                </div>
                <div className="px-4 py-2 rounded-full bg-purple-500/20 border border-purple-500/30">
                  <span className="text-purple-400 text-sm">Protocol Required</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div
          className={`grid md:grid-cols-2 gap-6 mb-12 transition-all duration-1000 delay-400 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {bridgeFeatures.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <Card
                key={i}
                className="bg-white/5 border-white/10 hover:bg-white/10 hover:border-amber-500/30 transition-all duration-300 group"
              >
                <CardContent className="p-6 flex gap-4">
                  <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0 group-hover:bg-amber-500/20 transition-colors">
                    <Icon className="w-6 h-6 text-amber-400" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">{feature.title}</h4>
                    <p className="text-white/60 text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA */}
        <div
          className={`text-center transition-all duration-1000 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Button
            size="lg"
            onClick={() => document.getElementById('builders')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-semibold px-8"
          >
            <Wallet className="w-5 h-5 mr-2" />
            Connect Wallet to Bridge
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <p className="text-white/40 text-sm mt-4">
            Full bridge functionality coming soon. Join the builders.
          </p>
        </div>
      </div>
    </section>
  );
}
