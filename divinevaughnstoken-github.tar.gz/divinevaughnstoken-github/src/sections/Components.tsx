import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Search, Settings, User, Mail, Lock, ChevronRight, Star, Zap, Shield } from 'lucide-react';

const buttonVariants = [
  { variant: 'default' as const, label: 'Primary' },
  { variant: 'secondary' as const, label: 'Secondary' },
  { variant: 'outline' as const, label: 'Outline' },
  { variant: 'ghost' as const, label: 'Ghost' },
  { variant: 'destructive' as const, label: 'Destructive' },
  { variant: 'link' as const, label: 'Link' },
];

const buttonSizes = [
  { size: 'sm' as const, label: 'Small' },
  { size: 'default' as const, label: 'Default' },
  { size: 'lg' as const, label: 'Large' },
  { size: 'icon' as const, label: 'Icon', icon: Star },
];

const badgeVariants = [
  { variant: 'default' as const, label: 'Default' },
  { variant: 'secondary' as const, label: 'Secondary' },
  { variant: 'outline' as const, label: 'Outline' },
  { variant: 'destructive' as const, label: 'Destructive' },
];

export function Components() {
  const [isVisible, setIsVisible] = useState(false);
  const [sliderValue, setSliderValue] = useState([50]);
  const [switchChecked, setSwitchChecked] = useState(true);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="components"
      ref={sectionRef}
      className="relative w-full py-32 px-6 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-aether-dark via-pink-500/5 to-aether-dark" />
      <div className="absolute bottom-0 left-1/4 w-[600px] h-[400px] bg-aether-pink/10 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/20 text-sm text-pink-400 mb-6">
            Components
          </span>
          <h2 className="text-display-sm md:text-display-md font-bold text-white mb-6">
            Building blocks for
            <span className="text-gradient"> every interface</span>
          </h2>
          <p className="text-lg text-white/50 max-w-2xl mx-auto">
            50+ pre-built components designed with accessibility and customization in mind. 
            Mix and match to create unique experiences.
          </p>
        </div>

        {/* Components Showcase */}
        <Tabs defaultValue="buttons" className="w-full">
          <TabsList
            className={`w-full max-w-lg mx-auto mb-12 bg-white/5 border border-white/10 transition-all duration-700 delay-150 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <TabsTrigger value="buttons" className="data-[state=active]:bg-white/10">Buttons</TabsTrigger>
            <TabsTrigger value="inputs" className="data-[state=active]:bg-white/10">Inputs</TabsTrigger>
            <TabsTrigger value="cards" className="data-[state=active]:bg-white/10">Cards</TabsTrigger>
            <TabsTrigger value="controls" className="data-[state=active]:bg-white/10">Controls</TabsTrigger>
          </TabsList>

          <TabsContent value="buttons" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Button Variants */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-6">Variants</h3>
                <div className="flex flex-wrap gap-4">
                  {buttonVariants.map((btn) => (
                    <Button key={btn.label} variant={btn.variant}>
                      {btn.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Button Sizes */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-6">Sizes</h3>
                <div className="flex flex-wrap items-center gap-4">
                  {buttonSizes.map((btn) => (
                    btn.size === 'icon' && btn.icon ? (
                      <Button key={btn.label} size="icon">
                        <btn.icon className="w-4 h-4" />
                      </Button>
                    ) : (
                      <Button key={btn.label} size={btn.size}>
                        {btn.label}
                      </Button>
                    )
                  ))}
                </div>
              </div>

              {/* Button with Icons */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-6">With Icons</h3>
                <div className="flex flex-wrap gap-4">
                  <Button className="gap-2">
                    <Mail className="w-4 h-4" />
                    Send Email
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <Settings className="w-4 h-4" />
                    Settings
                  </Button>
                  <Button variant="secondary" className="gap-2">
                    <User className="w-4 h-4" />
                    Profile
                  </Button>
                </div>
              </div>

              {/* Loading & Disabled */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-6">States</h3>
                <div className="flex flex-wrap gap-4">
                  <Button disabled>Disabled</Button>
                  <Button variant="outline" disabled>Disabled</Button>
                  <Button className="gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Loading
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="inputs" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Basic Inputs */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10 space-y-6">
                <h3 className="text-lg font-semibold text-white mb-6">Text Inputs</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-white/70">Email</Label>
                    <Input type="email" placeholder="hello@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white/70">Password</Label>
                    <Input type="password" placeholder="••••••••" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white/70">Search</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                      <Input className="pl-10" placeholder="Search..." />
                    </div>
                  </div>
                </div>
              </div>

              {/* Input States */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10 space-y-6">
                <h3 className="text-lg font-semibold text-white mb-6">States</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-white/70">Default</Label>
                    <Input placeholder="Default state" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white/70">Disabled</Label>
                    <Input disabled placeholder="Disabled state" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white/70">With Icon</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                      <Input className="pl-10" placeholder="Secure input" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="cards" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Feature Card */}
              <Card className="bg-white/[0.02] border-white/10">
                <CardHeader>
                  <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center mb-4">
                    <Zap className="w-6 h-6 text-blue-400" />
                  </div>
                  <CardTitle className="text-white">Lightning Fast</CardTitle>
                  <CardDescription className="text-white/50">
                    Optimized for performance with minimal bundle size.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="ghost" className="gap-2 text-blue-400 hover:text-blue-300">
                    Learn more <ChevronRight className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>

              {/* Stats Card */}
              <Card className="bg-white/[0.02] border-white/10">
                <CardHeader>
                  <CardDescription className="text-white/50">Total Users</CardDescription>
                  <CardTitle className="text-4xl font-bold text-white">24,593</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-400">+12.5%</Badge>
                    <span className="text-sm text-white/50">from last month</span>
                  </div>
                </CardContent>
              </Card>

              {/* Profile Card */}
              <Card className="bg-white/[0.02] border-white/10">
                <CardHeader className="text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-aether-blue to-aether-purple mx-auto mb-4" />
                  <CardTitle className="text-white">Sarah Chen</CardTitle>
                  <CardDescription className="text-white/50">Product Designer</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center gap-2">
                    <Button size="sm" variant="outline">Message</Button>
                    <Button size="sm">Follow</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="controls" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Switches & Checkboxes */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10 space-y-8">
                <h3 className="text-lg font-semibold text-white">Toggles</h3>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-white">Notifications</Label>
                    <p className="text-sm text-white/50">Receive push notifications</p>
                  </div>
                  <Switch checked={switchChecked} onCheckedChange={setSwitchChecked} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-white">Dark Mode</Label>
                    <p className="text-sm text-white/50">Always use dark theme</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="space-y-4">
                  <Label className="text-white">Preferences</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="terms" />
                    <label htmlFor="terms" className="text-sm text-white/70">
                      Accept terms and conditions
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="newsletter" defaultChecked />
                    <label htmlFor="newsletter" className="text-sm text-white/70">
                      Subscribe to newsletter
                    </label>
                  </div>
                </div>
              </div>

              {/* Sliders & Radio */}
              <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10 space-y-8">
                <h3 className="text-lg font-semibold text-white">Sliders</h3>
                
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <Label className="text-white">Volume</Label>
                    <span className="text-sm text-white/50">{sliderValue[0]}%</span>
                  </div>
                  <Slider value={sliderValue} onValueChange={setSliderValue} max={100} step={1} />
                </div>

                <div className="space-y-4">
                  <Label className="text-white">Plan</Label>
                  <RadioGroup defaultValue="pro" className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 rounded-xl border border-white/10 hover:border-white/20 transition-colors">
                      <RadioGroupItem value="free" id="free" />
                      <Label htmlFor="free" className="flex-1 text-white cursor-pointer">
                        <span className="font-medium">Free</span>
                        <span className="block text-sm text-white/50">Basic features</span>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3 p-3 rounded-xl border border-white/10 hover:border-white/20 transition-colors">
                      <RadioGroupItem value="pro" id="pro" />
                      <Label htmlFor="pro" className="flex-1 text-white cursor-pointer">
                        <span className="font-medium">Pro</span>
                        <span className="block text-sm text-white/50">All features</span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Badges */}
        <div
          className={`mt-12 p-8 rounded-3xl bg-white/[0.02] border border-white/10 transition-all duration-700 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h3 className="text-lg font-semibold text-white mb-6">Badges</h3>
          <div className="flex flex-wrap gap-3">
            {badgeVariants.map((badge) => (
              <Badge key={badge.label} variant={badge.variant}>
                {badge.label}
              </Badge>
            ))}
            <Badge className="gap-1">
              <Star className="w-3 h-3" />
              Featured
            </Badge>
            <Badge className="gap-1 bg-gradient-to-r from-aether-blue to-aether-purple">
              <Shield className="w-3 h-3" />
              Premium
            </Badge>
          </div>
        </div>
      </div>
    </section>
  );
}
