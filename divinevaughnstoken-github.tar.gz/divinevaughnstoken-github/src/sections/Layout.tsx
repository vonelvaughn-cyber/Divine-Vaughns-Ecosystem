import { useEffect, useRef, useState } from 'react';
import { Grid3X3, Move, Maximize, Layers } from 'lucide-react';

const spacingScale = [
  { name: '0', value: '0px', class: 'w-0' },
  { name: '1', value: '4px', class: 'w-1' },
  { name: '2', value: '8px', class: 'w-2' },
  { name: '3', value: '12px', class: 'w-3' },
  { name: '4', value: '16px', class: 'w-4' },
  { name: '5', value: '20px', class: 'w-5' },
  { name: '6', value: '24px', class: 'w-6' },
  { name: '8', value: '32px', class: 'w-8' },
  { name: '10', value: '40px', class: 'w-10' },
  { name: '12', value: '48px', class: 'w-12' },
  { name: '16', value: '64px', class: 'w-16' },
  { name: '20', value: '80px', class: 'w-20' },
  { name: '24', value: '96px', class: 'w-24' },
  { name: '32', value: '128px', class: 'w-32' },
  { name: '40', value: '160px', class: 'w-40' },
  { name: '48', value: '192px', class: 'w-48' },
  { name: '64', value: '256px', class: 'w-64' },
];

const breakpoints = [
  { name: 'sm', value: '640px', description: 'Small devices' },
  { name: 'md', value: '768px', description: 'Tablets' },
  { name: 'lg', value: '1024px', description: 'Laptops' },
  { name: 'xl', value: '1280px', description: 'Desktops' },
  { name: '2xl', value: '1536px', description: 'Large screens' },
];

const gridExamples = [
  { cols: 1, class: 'grid-cols-1' },
  { cols: 2, class: 'grid-cols-2' },
  { cols: 3, class: 'grid-cols-3' },
  { cols: 4, class: 'grid-cols-4' },
  { cols: 6, class: 'grid-cols-6' },
  { cols: 12, class: 'grid-cols-12' },
];

export function Layout() {
  const [isVisible, setIsVisible] = useState(false);
  const [selectedGrid, setSelectedGrid] = useState(3);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="layout"
      ref={sectionRef}
      className="relative w-full py-32 px-6 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-aether-dark via-cyan-500/5 to-aether-dark" />
      <div className="absolute top-1/3 left-0 w-[500px] h-[500px] bg-aether-blue/10 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-sm text-cyan-400 mb-6">
            Layout System
          </span>
          <h2 className="text-display-sm md:text-display-md font-bold text-white mb-6">
            Structure that
            <span className="text-gradient"> scales beautifully</span>
          </h2>
          <p className="text-lg text-white/50 max-w-2xl mx-auto">
            A flexible grid system and spacing scale that adapts to any screen size, 
            ensuring consistent layouts across all devices.
          </p>
        </div>

        {/* Spacing Scale */}
        <div
          className={`mb-20 transition-all duration-700 delay-150 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="flex items-center gap-3 mb-8">
            <Move className="w-5 h-5 text-cyan-400" />
            <h3 className="text-xl font-semibold text-white">Spacing Scale</h3>
          </div>
          
          <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10">
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-9 gap-6">
              {spacingScale.map((space) => (
                <div key={space.name} className="flex flex-col items-center gap-2">
                  <div className="h-16 flex items-end">
                    <div className={`${space.class} h-2 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full`} />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-white">{space.name}</p>
                    <p className="text-xs text-white/40">{space.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Grid System */}
        <div
          className={`mb-20 transition-all duration-700 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Grid3X3 className="w-5 h-5 text-cyan-400" />
              <h3 className="text-xl font-semibold text-white">Grid System</h3>
            </div>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 6, 12].map((cols) => (
                <button
                  key={cols}
                  onClick={() => setSelectedGrid(cols)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    selectedGrid === cols
                      ? 'bg-white/10 text-white'
                      : 'text-white/50 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {cols}
                </button>
              ))}
            </div>
          </div>

          <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10">
            <div className={`grid gap-4 ${gridExamples.find(g => g.cols === selectedGrid)?.class}`}>
              {Array.from({ length: selectedGrid * 2 }).map((_, i) => (
                <div
                  key={i}
                  className="aspect-square rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/10 border border-cyan-500/20 flex items-center justify-center"
                >
                  <span className="text-cyan-400 font-medium">{i + 1}</span>
                </div>
              ))}
            </div>
            <p className="mt-6 text-sm text-white/40 text-center">
              grid-cols-{selectedGrid} with gap-4 (16px)
            </p>
          </div>
        </div>

        {/* Breakpoints */}
        <div
          className={`mb-20 transition-all duration-700 delay-450 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="flex items-center gap-3 mb-8">
            <Maximize className="w-5 h-5 text-cyan-400" />
            <h3 className="text-xl font-semibold text-white">Breakpoints</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {breakpoints.map((bp) => (
              <div
                key={bp.name}
                className="p-6 rounded-2xl bg-white/[0.02] border border-white/10 hover:border-white/20 transition-colors"
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold text-white">{bp.name}</span>
                  <span className="text-xs text-white/40 px-2 py-1 rounded-full bg-white/5">
                    min-width
                  </span>
                </div>
                <p className="text-lg font-medium text-cyan-400">{bp.value}</p>
                <p className="text-sm text-white/40 mt-2">{bp.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Container Sizes */}
        <div
          className={`transition-all duration-700 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="flex items-center gap-3 mb-8">
            <Layers className="w-5 h-5 text-cyan-400" />
            <h3 className="text-xl font-semibold text-white">Container Sizes</h3>
          </div>

          <div className="space-y-4">
            {[
              { name: 'sm', value: '640px', width: 'w-full max-w-sm' },
              { name: 'md', value: '768px', width: 'w-full max-w-md' },
              { name: 'lg', value: '1024px', width: 'w-full max-w-lg' },
              { name: 'xl', value: '1280px', width: 'w-full max-w-xl' },
              { name: '2xl', value: '1536px', width: 'w-full max-w-2xl' },
              { name: '7xl', value: '1280px', width: 'w-full max-w-7xl' },
            ].map((container) => (
              <div
                key={container.name}
                className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/10"
              >
                <div className="w-20 shrink-0">
                  <span className="text-sm font-medium text-white">{container.name}</span>
                </div>
                <div className="flex-1">
                  <div className={`${container.width} h-8 rounded-lg bg-gradient-to-r from-cyan-500/30 to-blue-500/30`} />
                </div>
                <div className="w-24 text-right">
                  <span className="text-sm text-white/40">{container.value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Responsive Example */}
        <div
          className={`mt-20 p-8 rounded-3xl bg-gradient-to-br from-cyan-500/10 to-transparent border border-cyan-500/20 transition-all duration-700 delay-750 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h3 className="text-lg font-semibold text-white mb-6">Responsive in Action</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: 'Mobile', desc: '1 column, stacked', color: 'from-pink-500/20 to-pink-600/10' },
              { title: 'Tablet', desc: '2 columns, side by side', color: 'from-purple-500/20 to-purple-600/10' },
              { title: 'Desktop', desc: '4 columns, grid layout', color: 'from-blue-500/20 to-blue-600/10' },
              { title: 'Wide', desc: '4 columns, expanded', color: 'from-cyan-500/20 to-cyan-600/10' },
            ].map((item) => (
              <div
                key={item.title}
                className={`p-6 rounded-2xl bg-gradient-to-br ${item.color} border border-white/10`}
              >
                <h4 className="font-semibold text-white mb-2">{item.title}</h4>
                <p className="text-sm text-white/60">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
