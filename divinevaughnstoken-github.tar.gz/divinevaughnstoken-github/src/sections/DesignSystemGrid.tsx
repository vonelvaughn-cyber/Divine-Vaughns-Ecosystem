import { useEffect, useRef, useState } from 'react';
import { Palette, Type, Layers, LayoutGrid, ArrowRight } from 'lucide-react';

const features = [
  {
    icon: Palette,
    title: 'Colors',
    description: 'A harmonious color palette with semantic tokens, gradients, and accessibility-compliant combinations.',
    color: 'from-blue-500/20 to-blue-600/5',
    borderColor: 'group-hover:border-blue-500/30',
    iconColor: 'text-blue-400',
    href: '#colors',
  },
  {
    icon: Type,
    title: 'Typography',
    description: 'Carefully crafted type scale with Inter font family, optimized for readability and visual hierarchy.',
    color: 'from-purple-500/20 to-purple-600/5',
    borderColor: 'group-hover:border-purple-500/30',
    iconColor: 'text-purple-400',
    href: '#typography',
  },
  {
    icon: Layers,
    title: 'Components',
    description: '50+ reusable UI components built with React, TypeScript, and Tailwind CSS for rapid development.',
    color: 'from-pink-500/20 to-pink-600/5',
    borderColor: 'group-hover:border-pink-500/30',
    iconColor: 'text-pink-400',
    href: '#components',
  },
  {
    icon: LayoutGrid,
    title: 'Layout',
    description: 'Flexible grid system and spacing scale that adapts seamlessly across all screen sizes.',
    color: 'from-cyan-500/20 to-cyan-600/5',
    borderColor: 'group-hover:border-cyan-500/30',
    iconColor: 'text-cyan-400',
    href: '#layout',
  },
];

export function DesignSystemGrid() {
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const sectionRef = useRef<HTMLElement>(null);
  const cardRefs = useRef<(HTMLAnchorElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = cardRefs.current.indexOf(entry.target as HTMLAnchorElement);
            if (index !== -1 && !visibleCards.includes(index)) {
              setTimeout(() => {
                setVisibleCards((prev) => [...prev, index]);
              }, index * 100);
            }
          }
        });
      },
      { threshold: 0.2, rootMargin: '-50px' }
    );

    cardRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, [visibleCards]);

  return (
    <section
      id="design-system"
      ref={sectionRef}
      className="relative w-full py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 mb-6">
            Core Foundations
          </span>
          <h2 className="text-display-sm md:text-display-md font-bold text-white mb-6">
            Everything you need to
            <span className="text-gradient"> build faster</span>
          </h2>
          <p className="text-lg text-white/50 max-w-2xl mx-auto">
            Aether provides a complete set of design foundations and components 
            to help you create consistent, beautiful interfaces.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            const isVisible = visibleCards.includes(index);

            return (
              <a
                key={feature.title}
                ref={(el) => { cardRefs.current[index] = el; }}
                href={feature.href}
                className={`group relative p-8 rounded-3xl bg-gradient-to-br ${feature.color} border border-white/5 backdrop-blur-sm transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl ${feature.borderColor} ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
              >
                {/* Background Glow */}
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                {/* Content */}
                <div className="relative z-10">
                  {/* Icon */}
                  <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Icon className={`w-7 h-7 ${feature.iconColor}`} />
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl font-semibold text-white mb-3 flex items-center gap-3">
                    {feature.title}
                    <ArrowRight className="w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </h3>

                  {/* Description */}
                  <p className="text-white/50 leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                {/* Corner Decoration */}
                <div className="absolute top-4 right-4 w-20 h-20 rounded-full bg-white/5 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
