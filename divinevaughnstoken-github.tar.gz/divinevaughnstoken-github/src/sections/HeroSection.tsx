import { useEffect, useRef } from 'react';
import { DVLogo } from '@/components/TokenLogos';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles, Infinity, Heart, Layers, ChevronDown } from 'lucide-react';

interface HeroSectionProps {
  onLaunchApp: () => void;
}

export function HeroSection({ onLaunchApp }: HeroSectionProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Animated memory particles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      alpha: number;
      life: number;
      maxLife: number;
    }> = [];

    const createParticle = () => {
      particles.push({
        x: Math.random() * canvas.width,
        y: canvas.height + 10,
        vx: (Math.random() - 0.5) * 0.5,
        vy: -Math.random() * 1 - 0.5,
        size: Math.random() * 2 + 1,
        alpha: 0,
        life: 0,
        maxLife: Math.random() * 200 + 100,
      });
    };

    let frame = 0;
    const animate = () => {
      ctx.fillStyle = 'rgba(10, 10, 15, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (frame % 3 === 0) createParticle();

      particles.forEach((p, i) => {
        p.life++;
        p.x += p.vx;
        p.y += p.vy;

        // Fade in then out
        if (p.life < 30) p.alpha = p.life / 30 * 0.6;
        else if (p.life > p.maxLife - 30) p.alpha = (p.maxLife - p.life) / 30 * 0.6;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(212, 175, 55, ${p.alpha})`; // Gold color
        ctx.fill();

        if (p.life >= p.maxLife) particles.splice(i, 1);
      });

      // Draw connections between nearby particles (memory web)
      particles.forEach((p1, i) => {
        particles.slice(i + 1).forEach((p2) => {
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 100) {
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(212, 175, 55, ${0.1 * (1 - dist / 100)})`;
            ctx.stroke();
          }
        });
      });

      frame++;
      requestAnimationFrame(animate);
    };

    animate();
    return () => window.removeEventListener('resize', resize);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 z-0"
        style={{ background: 'linear-gradient(180deg, #0a0a0f 0%, #1a1510 50%, #0a0a0f 100%)' }}
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-transparent via-transparent to-[#0a0a0f]" />

      {/* Sacred Geometry Pattern */}
      <div className="absolute inset-0 z-[1] opacity-5">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="flowerOfLife" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="10" cy="10" r="8" fill="none" stroke="currentColor" strokeWidth="0.3" />
              <circle cx="10" cy="2" r="8" fill="none" stroke="currentColor" strokeWidth="0.3" />
              <circle cx="10" cy="18" r="8" fill="none" stroke="currentColor" strokeWidth="0.3" />
              <circle cx="2" cy="10" r="8" fill="none" stroke="currentColor" strokeWidth="0.3" />
              <circle cx="18" cy="10" r="8" fill="none" stroke="currentColor" strokeWidth="0.3" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#flowerOfLife)" />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 mb-8 animate-fade-in">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-sm text-amber-300 tracking-wider uppercase">A Memory Anchor</span>
        </div>

        {/* Main Logo */}
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-amber-500/20 blur-3xl rounded-full animate-pulse" />
            <DVLogo size="xl" className="relative z-10" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight">
          <span className="text-white">Divine</span>{' '}
          <span className="bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 bg-clip-text text-transparent">
            Vaughns
          </span>
        </h1>

        {/* Core Philosophy */}
        <div className="space-y-4 mb-12 max-w-3xl mx-auto">
          <p className="text-xl md:text-2xl text-amber-100/90 font-light italic">
            "This is a different kind of system"
          </p>
          <p className="text-lg text-white/60">
            This is value that <span className="text-amber-400">remembers life</span>
          </p>
          <p className="text-lg text-white/60">
            This is for people who <span className="text-emerald-400">build</span>, not speculate
          </p>
        </div>

        {/* Three Pillars */}
        <div className="grid grid-cols-3 gap-6 mb-12 max-w-2xl mx-auto">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
            <Heart className="w-6 h-6 text-rose-400 mx-auto mb-2" />
            <p className="text-sm text-white/80 font-medium">Memory</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
            <Layers className="w-6 h-6 text-amber-400 mx-auto mb-2" />
            <p className="text-sm text-white/80 font-medium">Contribution</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
            <Infinity className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm text-white/80 font-medium">Continuity</p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            onClick={onLaunchApp}
            className="bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-semibold px-8"
          >
            Enter The Bridge
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => document.getElementById('philosophy')?.scrollIntoView({ behavior: 'smooth' })}
            className="border-amber-500/50 text-amber-300 hover:bg-amber-500/10 px-8"
          >
            Read The Philosophy
            <ChevronDown className="w-5 h-5 ml-2" />
          </Button>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-amber-500/30 flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-amber-400 rounded-full animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
}
