import { useEffect, useRef, useState } from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';

export function Hero() {
  const [isVisible, setIsVisible] = useState(false);
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToContent = () => {
    const nextSection = document.getElementById('design-system');
    nextSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-hero" />
      <div className="absolute inset-0 bg-gradient-mesh" />
      
      {/* Animated Gradient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-aether-blue/20 rounded-full blur-[120px] animate-pulse-glow" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-aether-purple/15 rounded-full blur-[100px] animate-pulse-glow" style={{ animationDelay: '1s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-aether-pink/5 rounded-full blur-[150px]" />

      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 z-50 px-6 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-aether-blue" />
            <span className="text-sm font-medium tracking-wide">AETHER</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#design-system" className="text-sm text-white/60 hover:text-white transition-colors">Overview</a>
            <a href="#colors" className="text-sm text-white/60 hover:text-white transition-colors">Colors</a>
            <a href="#typography" className="text-sm text-white/60 hover:text-white transition-colors">Typography</a>
            <a href="#components" className="text-sm text-white/60 hover:text-white transition-colors">Components</a>
            <a href="#layout" className="text-sm text-white/60 hover:text-white transition-colors">Layout</a>
            <a href="#web3-platform" className="text-sm text-aether-blue hover:text-aether-purple transition-colors">Web3 Platform</a>
          </div>
          <button className="px-4 py-2 text-sm font-medium bg-white/10 hover:bg-white/15 rounded-lg transition-colors">
            Get Started
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10 text-center px-6 max-w-6xl mx-auto">
        {/* Badge */}
        <div
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-aether-blue animate-pulse" />
          <span className="text-sm text-white/70">Design System v2.0</span>
        </div>

        {/* Main Title */}
        <h1
          className={`text-display-md md:text-display-lg lg:text-display-xl font-bold tracking-tighter mb-6 transition-all duration-700 delay-100 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="text-white">Aether</span>
          <br />
          <span className="text-gradient">Design System</span>
        </h1>

        {/* Subtitle */}
        <p
          className={`text-lg md:text-xl text-white/60 max-w-2xl mx-auto mb-12 leading-relaxed transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          A comprehensive design system built for modern interfaces. 
          Crafted with precision, flexibility, and scalability in mind.
        </p>

        {/* CTA Buttons */}
        <div
          className={`flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-700 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <button className="group px-8 py-4 bg-white text-aether-dark font-medium rounded-xl hover:bg-white/90 transition-all flex items-center gap-2">
            Explore System
            <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
          </button>
          <button className="px-8 py-4 bg-white/5 text-white font-medium rounded-xl border border-white/10 hover:bg-white/10 transition-all">
            View Documentation
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToContent}
        className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/40 hover:text-white/70 transition-all duration-500 cursor-pointer ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        style={{ transitionDelay: '600ms' }}
      >
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <div className="w-6 h-10 rounded-full border-2 border-current flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-current rounded-full animate-bounce" />
        </div>
      </button>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-aether-dark to-transparent" />
    </section>
  );
}
