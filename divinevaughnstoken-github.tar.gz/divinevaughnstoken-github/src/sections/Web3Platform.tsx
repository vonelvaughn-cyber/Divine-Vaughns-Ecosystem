import { useState } from 'react';
import { WalletConnect } from '@/components/WalletConnect';
import { UserProfileCreator, ProfileDashboard } from '@/components/UserProfile';
import { AIMarketBot } from '@/components/AIMarketBot';
import { StakingCompetition } from '@/components/StakingCompetition';
import { AdminDashboard } from '@/components/AdminDashboard';
import { AdminProfile, DEFAULT_ADMIN } from '@/components/AdminProfile';
import { StorageCodeWallet } from '@/components/StorageCodeWallet';
import { DVSwap } from '@/components/DVSwap';
import { AIAppManager } from '@/components/AIAppManager';
import { AIChat } from '@/components/AIChat';
import { CustomCoinDeploy } from '@/components/CustomCoinDeploy';
import { ContentCoinSystem } from '@/components/ContentCoinSystem';
import { DVAICPool } from '@/components/DVAICPool';
import { DexMarketplace } from '@/components/DexMarketplace';
import { LiquidationPool } from '@/components/LiquidationPool';
import { DVWethPool } from '@/components/DVWethPool';
import { TokenTransfer } from '@/components/TokenTransfer';
import { GiftShop } from '@/components/GiftShop';
import { LiveStreamWithGifts } from '@/components/LiveStreamWithGifts';
import { WithdrawalSystem } from '@/components/WithdrawalSystem';
import { RevenueDistribution } from '@/components/RevenueDistribution';
import { DVLogo, AICLogo } from '@/components/TokenLogos';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Wallet, 
  User, 
  Bot, 
  Trophy, 
  Shield, 
  Sparkles,
  TrendingUp,
  Lock,
  Zap,
  Crown,
  Gem,
  Star,
  Award,
  CheckCircle,
  Key,
  ArrowRightLeft,
  Brain,
  MessageSquare,
  Flame,
  Cloud,
  Radio,
  Coins,
  Video,
  Store,
  Droplets,
  Waves,
  Send,
  Gift,
  Banknote,
  PieChart
} from 'lucide-react';
import { useAccount } from 'wagmi';
import { useDVTier } from '@/hooks/useDVTier';
import { Badge } from '@/components/ui/badge';
import { PLATFORM_DOMAIN } from '@/lib/web3';

const tierIcons: Record<number, typeof Crown> = {
  0: Lock,
  1: Star,
  2: Award,
  3: Crown,
  4: Gem,
};

const tierColors: Record<number, string> = {
  0: 'text-gray-400',
  1: 'text-amber-400',
  2: 'text-slate-300',
  3: 'text-yellow-400',
  4: 'text-cyan-400',
};

const tierBgColors: Record<number, string> = {
  0: 'from-gray-500/20 to-gray-600/10',
  1: 'from-amber-500/20 to-amber-600/10',
  2: 'from-slate-400/20 to-slate-500/10',
  3: 'from-yellow-500/20 to-yellow-600/10',
  4: 'from-cyan-500/20 to-cyan-600/10',
};

export function Web3Platform() {
  const { isConnected } = useAccount();
  const { tier, tierName, formattedBalance, hasMarketAccess, hasProfileAccess, hasSwapAccess, hasStorageAccess, hasBotAccess } = useDVTier();
  const [activeTab, setActiveTab] = useState('overview');

  const TierIcon = tierIcons[tier] || Lock;

  return (
    <section id="web3-platform" className="relative w-full py-20 px-6">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-aether-dark via-aether-blue/5 to-aether-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header with Logos */}
        <div className="text-center mb-12">
          {/* Token Logos */}
          <div className="flex justify-center items-center gap-6 mb-6">
            <div className="flex flex-col items-center">
              <DVLogo size="xl" />
              <span className="text-sm text-amber-400 mt-2 font-medium">DV</span>
            </div>
            <div className="text-white/30 text-2xl">×</div>
            <div className="flex flex-col items-center">
              <AICLogo size="xl" />
              <span className="text-sm text-purple-400 mt-2 font-medium">AIC</span>
            </div>
          </div>
          
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-aether-blue/10 border border-aether-blue/20 mb-6">
            <Sparkles className="w-4 h-4 text-aether-blue" />
            <span className="text-sm text-aether-blue">{PLATFORM_DOMAIN}</span>
          </div>
          <h2 className="text-display-sm md:text-display-md font-bold text-white mb-4">
            Divine Vaughns <span className="text-gradient">Ecosystem</span>
          </h2>
          <p className="text-lg text-white/50 max-w-2xl mx-auto mb-8">
            Powered by DV & AIC tokens on Base Chain. Connect your wallet to access 
            AI chat with burn mechanics, DV swaps, staking rewards, and tier-based features.
          </p>
          
          {/* Wallet Connection */}
          <div className="flex justify-center">
            <WalletConnect />
          </div>
        </div>

        {/* Token Info Banner */}
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-8 gap-4 mb-12">
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <div className="flex justify-center mb-2">
                <DVLogo size="sm" />
              </div>
              <p className="text-sm text-white/50 mb-1">DV Token</p>
              <p className="text-lg font-semibold text-white">Divine Vaughns</p>
              <p className="text-xs text-white/40 font-mono mt-1">Base Chain</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <div className="flex justify-center mb-2">
                <AICLogo size="sm" />
              </div>
              <p className="text-sm text-white/50 mb-1">AIC Token</p>
              <p className="text-lg font-semibold text-purple-400">AI Catalyst</p>
              <p className="text-xs text-white/40 font-mono mt-1">1M Supply</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Market View</p>
              <p className="text-lg font-semibold text-amber-400">Tier 1+</p>
              <p className="text-xs text-white/40 mt-1">1+ DV (Bronze)</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Profile & Swap</p>
              <p className="text-lg font-semibold text-slate-300">Tier 2+</p>
              <p className="text-xs text-white/40 mt-1">100+ DV (Silver)</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Storage & AI Bot</p>
              <p className="text-lg font-semibold text-yellow-400">Tier 3+</p>
              <p className="text-xs text-white/40 mt-1">1,000+ DV (Gold)</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">AI Manager</p>
              <p className="text-lg font-semibold text-cyan-400">Tier 4</p>
              <p className="text-xs text-white/40 mt-1">10,000+ DV (Platinum)</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">DEX Marketplace</p>
              <p className="text-lg font-semibold text-indigo-400">100 DV + 200 AIC</p>
              <p className="text-xs text-white/40 mt-1">Full token trading</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Liquidation Pool</p>
              <p className="text-lg font-semibold text-emerald-400">5% + stDV3</p>
              <p className="text-xs text-white/40 mt-1">Earn contributing</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">DV/WETH Pool</p>
              <p className="text-lg font-semibold text-blue-400">0.3% Fees</p>
              <p className="text-xs text-white/40 mt-1">~2M DV = 1 WETH</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Send DV</p>
              <p className="text-lg font-semibold text-amber-400">0.05-0.5%</p>
              <p className="text-xs text-white/40 mt-1">Dynamic fees</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Gift Shop</p>
              <p className="text-lg font-semibold text-pink-400">10+ Gifts</p>
              <p className="text-xs text-white/40 mt-1">Support creators</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Live Stream</p>
              <p className="text-lg font-semibold text-red-400">0.5 DV/min</p>
              <p className="text-xs text-white/40 mt-1">Earn streaming</p>
            </CardContent>
          </Card>
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/50 mb-1">Withdraw</p>
              <p className="text-lg font-semibold text-emerald-400">Fiat + Crypto</p>
              <p className="text-xs text-white/40 mt-1">DV to USD/USDC</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-emerald-900/20 to-cyan-900/20 border-emerald-500/30">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-emerald-400/70 mb-1">Fee Distribution</p>
              <p className="text-lg font-semibold text-emerald-400">100% → Pool</p>
              <p className="text-xs text-emerald-400/50 mt-1">DV/WETH Liquidity</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Platform Tabs - Requires Tier 1+ (1+ DV) */}
        {isConnected && hasMarketAccess && (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full max-w-3xl mx-auto mb-8 bg-white/5 border border-white/10 flex-wrap h-auto py-2">
              <TabsTrigger value="overview" className="data-[state=active]:bg-white/10">
                <TrendingUp className="w-4 h-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="profile" className="data-[state=active]:bg-white/10">
                <User className="w-4 h-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="storage-wallet" className="data-[state=active]:bg-white/10">
                <Key className="w-4 h-4 mr-2" />
                Storage
              </TabsTrigger>
              <TabsTrigger value="swap" className="data-[state=active]:bg-white/10">
                <ArrowRightLeft className="w-4 h-4 mr-2" />
                Swap
              </TabsTrigger>
              <TabsTrigger value="send" className="data-[state=active]:bg-white/10">
                <Send className="w-4 h-4 mr-2" />
                Send
              </TabsTrigger>
              <TabsTrigger value="dex" className="data-[state=active]:bg-white/10">
                <Store className="w-4 h-4 mr-2" />
                DEX
              </TabsTrigger>
              <TabsTrigger value="liquidation" className="data-[state=active]:bg-white/10">
                <Droplets className="w-4 h-4 mr-2" />
                Pool
              </TabsTrigger>
              <TabsTrigger value="dv-weth-pool" className="data-[state=active]:bg-white/10">
                <Waves className="w-4 h-4 mr-2" />
                DV/WETH
              </TabsTrigger>
              <TabsTrigger value="ai-chat" className="data-[state=active]:bg-white/10">
                <MessageSquare className="w-4 h-4 mr-2" />
                AI Chat
              </TabsTrigger>
              <TabsTrigger value="content-feed" className="data-[state=active]:bg-white/10">
                <TrendingUp className="w-4 h-4 mr-2" />
                Content
              </TabsTrigger>
              <TabsTrigger value="live" className="data-[state=active]:bg-white/10">
                <Radio className="w-4 h-4 mr-2" />
                Live
              </TabsTrigger>
              <TabsTrigger value="gifts" className="data-[state=active]:bg-white/10">
                <Gift className="w-4 h-4 mr-2" />
                Gifts
              </TabsTrigger>
              <TabsTrigger value="withdraw" className="data-[state=active]:bg-white/10">
                <Banknote className="w-4 h-4 mr-2" />
                Withdraw
              </TabsTrigger>
              <TabsTrigger value="revenue" className="data-[state=active]:bg-white/10">
                <PieChart className="w-4 h-4 mr-2" />
                Revenue
              </TabsTrigger>
              <TabsTrigger value="ai-bot" className="data-[state=active]:bg-white/10">
                <Bot className="w-4 h-4 mr-2" />
                AI Bot
              </TabsTrigger>
              <TabsTrigger value="dv-aic-pool" className="data-[state=active]:bg-white/10">
                <Cloud className="w-4 h-4 mr-2" />
                DV/AIC Pool
              </TabsTrigger>
              <TabsTrigger value="staking" className="data-[state=active]:bg-white/10">
                <Trophy className="w-4 h-4 mr-2" />
                Staking
              </TabsTrigger>
              <TabsTrigger value="admin" className="data-[state=active]:bg-white/10">
                <Shield className="w-4 h-4 mr-2" />
                Admin
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Tier Display */}
              <div className={`p-8 rounded-3xl bg-gradient-to-br ${tierBgColors[tier]} border border-white/10 text-center`}>
                <div className="w-20 h-20 rounded-2xl bg-white/10 flex items-center justify-center mx-auto mb-4">
                  <TierIcon className={`w-10 h-10 ${tierColors[tier]}`} />
                </div>
                <h3 className={`text-3xl font-bold ${tierColors[tier]} mb-2`}>{tierName}</h3>
                <p className="text-white/60">Current Tier</p>
                <div className="flex justify-center gap-1 mt-4">
                  {[1, 2, 3, 4].map((t) => (
                    <div
                      key={t}
                      className={`w-12 h-2 rounded-full ${
                        t <= tier ? 'bg-gradient-to-r from-aether-blue to-aether-purple' : 'bg-white/10'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Quick Stats */}
                <Card className="bg-white/[0.02] border-white/10">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Wallet className="w-5 h-5 text-aether-blue" />
                      Your DV Balance
                    </h3>
                    <div className="text-center py-8">
                      <p className="text-5xl font-bold text-white mb-2">{formattedBalance}</p>
                      <p className="text-white/50">DV Tokens</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div className="p-4 rounded-xl bg-white/5 text-center">
                        <p className="text-sm text-white/50">USD Value</p>
                        <p className="text-lg font-semibold text-emerald-400">
                          ${(parseFloat(formattedBalance) * 0.001).toFixed(2)}
                        </p>
                      </div>
                      <div className="p-4 rounded-xl bg-white/5 text-center">
                        <p className="text-sm text-white/50">Tier Status</p>
                        <p className={`text-lg font-semibold ${tierColors[tier]}`}>
                          {tierName}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card className="bg-white/[0.02] border-white/10">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Zap className="w-5 h-5 text-aether-purple" />
                      Quick Actions
                    </h3>
                    <div className="space-y-3">
                      <button
                        onClick={() => setActiveTab('profile')}
                        className={`w-full p-4 rounded-xl border transition-all flex items-center justify-between ${
                          hasProfileAccess 
                            ? 'bg-white/5 border-white/10 hover:border-aether-blue/50 hover:bg-white/10' 
                            : 'bg-white/5 border-white/10 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-aether-blue/20 flex items-center justify-center">
                            <User className="w-5 h-5 text-aether-blue" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Create Profile</p>
                            <p className="text-sm text-white/50">Tier 2+ (100+ DV)</p>
                          </div>
                        </div>
                        {!hasProfileAccess && <Lock className="w-5 h-5 text-gray-400" />}
                        {hasProfileAccess && <CheckCircle className="w-5 h-5 text-emerald-400" />}
                      </button>

                      <button
                        onClick={() => setActiveTab('swap')}
                        className={`w-full p-4 rounded-xl border transition-all flex items-center justify-between ${
                          hasSwapAccess 
                            ? 'bg-white/5 border-white/10 hover:border-pink-500/50 hover:bg-white/10' 
                            : 'bg-white/5 border-white/10 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                            <ArrowRightLeft className="w-5 h-5 text-pink-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">DV Swap</p>
                            <p className="text-sm text-white/50">0.30% Fee - Tier 2+</p>
                          </div>
                        </div>
                        {!hasSwapAccess && <Lock className="w-5 h-5 text-gray-400" />}
                        {hasSwapAccess && <CheckCircle className="w-5 h-5 text-emerald-400" />}
                      </button>

                      <button
                        onClick={() => setActiveTab('send')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 hover:border-amber-500/50 hover:bg-amber-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                            <Send className="w-5 h-5 text-amber-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Send DV</p>
                            <p className="text-sm text-white/50">Transfer with dynamic fees</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('dex')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 hover:border-indigo-500/50 hover:bg-indigo-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                            <Store className="w-5 h-5 text-indigo-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">DEX Marketplace</p>
                            <p className="text-sm text-white/50">Trade any token - 100 DV + 200 AIC</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('liquidation')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20 hover:border-emerald-500/50 hover:bg-emerald-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                            <Droplets className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Liquidation Pool</p>
                            <p className="text-sm text-white/50">5% commission + 0.5 stDV3 per DV</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('dv-weth-pool')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 hover:border-blue-500/50 hover:bg-blue-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                            <Waves className="w-5 h-5 text-blue-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">DV/WETH Pool</p>
                            <p className="text-sm text-white/50">Earn 0.3% fees providing liquidity</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('storage-wallet')}
                        className={`w-full p-4 rounded-xl border transition-all flex items-center justify-between ${
                          hasStorageAccess 
                            ? 'bg-white/5 border-white/10 hover:border-emerald-500/50 hover:bg-white/10' 
                            : 'bg-white/5 border-white/10 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                            <Key className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Storage Wallet</p>
                            <p className="text-sm text-white/50">500 DV - Tier 3+</p>
                          </div>
                        </div>
                        {!hasStorageAccess && <Lock className="w-5 h-5 text-gray-400" />}
                        {hasStorageAccess && <CheckCircle className="w-5 h-5 text-emerald-400" />}
                      </button>

                      <button
                        onClick={() => setActiveTab('ai-bot')}
                        className={`w-full p-4 rounded-xl border transition-all flex items-center justify-between ${
                          hasBotAccess 
                            ? 'bg-white/5 border-white/10 hover:border-aether-purple/50 hover:bg-white/10' 
                            : 'bg-white/5 border-white/10 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-aether-purple/20 flex items-center justify-center">
                            <Bot className="w-5 h-5 text-aether-purple" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">AI Market Bot</p>
                            <p className="text-sm text-white/50">Tier 3+ (1,000+ DV)</p>
                          </div>
                        </div>
                        {!hasBotAccess && <Lock className="w-5 h-5 text-gray-400" />}
                        {hasBotAccess && <CheckCircle className="w-5 h-5 text-emerald-400" />}
                      </button>

                      <button
                        onClick={() => setActiveTab('staking')}
                        className="w-full p-4 rounded-xl bg-white/5 border border-white/10 hover:border-emerald-500/50 hover:bg-white/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                            <Trophy className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Staking Competition</p>
                            <p className="text-sm text-white/50">Earn up to 20% APR</p>
                          </div>
                        </div>
                      </button>

                      <button
                        onClick={() => setActiveTab('ai-chat')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 hover:border-purple-500/50 hover:bg-purple-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                            <MessageSquare className="w-5 h-5 text-purple-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">AI Chat & Coin Deploy</p>
                            <p className="text-sm text-white/50">Trading advice + Custom tokens</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('content-feed')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-pink-500/10 to-rose-500/10 border border-pink-500/20 hover:border-pink-500/50 hover:bg-pink-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                            <Coins className="w-5 h-5 text-pink-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Content Feed</p>
                            <p className="text-sm text-white/50">Post & earn from content coins</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('live')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-red-500/10 to-orange-500/10 border border-red-500/20 hover:border-red-500/50 hover:bg-red-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                            <Video className="w-5 h-5 text-red-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Live Streaming</p>
                            <p className="text-sm text-white/50">Go live & earn DV per minute</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('gifts')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-500/20 hover:border-pink-500/50 hover:bg-pink-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                            <Gift className="w-5 h-5 text-pink-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Gift Shop</p>
                            <p className="text-sm text-white/50">Support creators with DV gifts</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('withdraw')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20 hover:border-emerald-500/50 hover:bg-emerald-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                            <Banknote className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Withdraw</p>
                            <p className="text-sm text-white/50">DV to USD or crypto</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('revenue')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-emerald-900/30 to-cyan-900/30 border border-emerald-500/30 hover:border-emerald-500/50 hover:bg-emerald-900/40 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-emerald-500/30 flex items-center justify-center">
                            <PieChart className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">Fee Distribution</p>
                            <p className="text-sm text-white/50">100% → DV/WETH Pool</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      <button
                        onClick={() => setActiveTab('dv-aic-pool')}
                        className="w-full p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-purple-500/10 border border-emerald-500/20 hover:border-emerald-500/50 hover:bg-emerald-500/10 transition-all flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                            <Cloud className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div className="text-left">
                            <p className="text-white font-medium">DV/AIC Pool</p>
                            <p className="text-sm text-white/50">Cloud revenue generation</p>
                          </div>
                        </div>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </button>

                      {tier >= 4 && (
                        <button
                          onClick={() => setActiveTab('admin')}
                          className="w-full p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 hover:border-purple-500/50 hover:bg-purple-500/10 transition-all flex items-center justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                              <Brain className="w-5 h-5 text-purple-400" />
                            </div>
                            <div className="text-left">
                              <p className="text-white font-medium">AI App Manager</p>
                              <p className="text-sm text-white/50">Monitor & prevent inflation</p>
                            </div>
                          </div>
                          <CheckCircle className="w-5 h-5 text-emerald-400" />
                        </button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Features Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
                <div className="p-6 rounded-2xl bg-gradient-to-br from-aether-blue/10 to-transparent border border-aether-blue/20">
                  <Bot className="w-8 h-8 text-aether-blue mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">AI Market Bot</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Advanced trading signals powered by AI. Get real-time market analysis.
                  </p>
                  <Badge className="bg-aether-blue/20 text-aether-blue">
                    Tier 3+ Required
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-aether-purple/10 to-transparent border border-aether-purple/20">
                  <Trophy className="w-8 h-8 text-aether-purple mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Staking Rewards</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Lock DV tokens for 3, 6, or 12 months and earn competitive APR.
                  </p>
                  <Badge className="bg-aether-purple/20 text-aether-purple">
                    Up to 20% APR
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-pink-500/10 to-transparent border border-pink-500/20">
                  <ArrowRightLeft className="w-8 h-8 text-pink-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">DV Swap</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Swap DV with WETH, USDC and more. DV must be in the pair.
                  </p>
                  <Badge className="bg-pink-500/20 text-pink-400">
                    0.30% Fee - Tier 2+
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/20">
                  <Send className="w-8 h-8 text-amber-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Send DV</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Transfer DV to any wallet with dynamic fees that decrease with amount.
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-amber-500/20 text-amber-400">
                      0.05% - 0.5%
                    </Badge>
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      Multi-Wallet
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-transparent border border-indigo-500/20">
                  <Store className="w-8 h-8 text-indigo-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">DEX Marketplace</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Full DEX access to trade ETH, USDC, cbETH and more tokens on Base.
                  </p>
                  <Badge className="bg-indigo-500/20 text-indigo-400">
                    100 DV + 200 AIC Required
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/20">
                  <Droplets className="w-8 h-8 text-emerald-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Liquidation Pool</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Contribute DV to earn 5% commission + 0.5 stDV3 rewards per contribution.
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      5% Commission
                    </Badge>
                    <Badge className="bg-purple-500/20 text-purple-400">
                      0.5 stDV3/DV
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-500/10 to-transparent border border-blue-500/20">
                  <Waves className="w-8 h-8 text-blue-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">DV/WETH Pool</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Provide liquidity to the DV/WETH Uniswap V3 pool and earn 0.3% trading fees.
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-blue-500/20 text-blue-400">
                      0.3% Fees
                    </Badge>
                    <Badge className="bg-cyan-500/20 text-cyan-400">
                      Uniswap V3
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/20">
                  <Key className="w-8 h-8 text-emerald-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Storage Wallet</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Create secure backup wallets with 12-word recovery codes.
                  </p>
                  <Badge className="bg-emerald-500/20 text-emerald-400">
                    500 DV - Tier 3+
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-purple-500/10 to-transparent border border-purple-500/20">
                  <MessageSquare className="w-8 h-8 text-purple-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">AI Chat & Coin Deploy</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Trading advice with AIC burn + Deploy custom tokens with DV fees.
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-purple-500/20 text-purple-400">
                      <Flame className="w-3 h-3 mr-1" />
                      0.001 AIC
                    </Badge>
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      DV Fees
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-pink-500/10 to-transparent border border-pink-500/20">
                  <Coins className="w-8 h-8 text-pink-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Content Feed</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Create posts with content coins. Earn 90% from sales, 10% to app revenue.
                  </p>
                  <Badge className="bg-pink-500/20 text-pink-400">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    90% Creator
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-red-500/10 to-transparent border border-red-500/20">
                  <Video className="w-8 h-8 text-red-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Live Streaming</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Go live and earn DV per minute. Viewers can send gifts!
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      0.5 DV/min
                    </Badge>
                    <Badge className="bg-pink-500/20 text-pink-400">
                      Gift Support
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-pink-500/10 to-transparent border border-pink-500/20">
                  <Gift className="w-8 h-8 text-pink-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Gift Shop</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Send DV gifts to support your favorite creators. 10+ gift types!
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-amber-500/20 text-amber-400">
                      10-25,000 DV
                    </Badge>
                    <Badge className="bg-purple-500/20 text-purple-400">
                      10 Gifts
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/20">
                  <Banknote className="w-8 h-8 text-emerald-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Withdraw</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Convert DV to USD (bank, Cash App, PayPal) or crypto (USDC, ETH).
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      0.3-3% Fee
                    </Badge>
                    <Badge className="bg-cyan-500/20 text-cyan-400">
                      Fiat + Crypto
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-900/30 to-cyan-900/30 border border-emerald-500/30">
                  <PieChart className="w-8 h-8 text-emerald-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">Fee Distribution</h4>
                  <p className="text-white/50 text-sm mb-4">
                    100% of all app fees go directly to the DV/WETH liquidity pool.
                  </p>
                  <div className="flex gap-2">
                    <Badge className="bg-emerald-500/20 text-emerald-400">
                      100% → Pool
                    </Badge>
                    <Badge className="bg-cyan-500/20 text-cyan-400">
                      Transparent
                    </Badge>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/20">
                  <Cloud className="w-8 h-8 text-emerald-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">DV/AIC Pool</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Paired liquidity pool generating cloud revenue for the ecosystem.
                  </p>
                  <Badge className="bg-emerald-500/20 text-emerald-400">
                    0.5 DV = 1 AIC
                  </Badge>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-transparent border border-indigo-500/20">
                  <Brain className="w-8 h-8 text-indigo-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">AI App Manager</h4>
                  <p className="text-white/50 text-sm mb-4">
                    Monitor DV tokenomics, prevent inflation, and manage swap parameters.
                  </p>
                  <Badge className="bg-indigo-500/20 text-indigo-400">
                    Admin Only - Tier 4
                  </Badge>
                </div>
              </div>

              {/* Tier Requirements */}
              <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-4">Tier Requirements</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { tier: 1, name: 'Bronze', req: '1 DV', icon: Star },
                    { tier: 2, name: 'Silver', req: '100 DV', icon: Award },
                    { tier: 3, name: 'Gold', req: '1,000 DV', icon: Crown },
                    { tier: 4, name: 'Platinum', req: '10,000 DV', icon: Gem },
                  ].map((t) => {
                    const Icon = t.icon;
                    const isUnlocked = tier >= t.tier;
                    return (
                      <div
                        key={t.tier}
                        className={`p-4 rounded-xl border text-center ${
                          isUnlocked 
                            ? 'bg-gradient-to-br from-aether-blue/10 to-aether-purple/10 border-aether-blue/30' 
                            : 'bg-white/5 border-white/10 opacity-50'
                        }`}
                      >
                        <Icon className={`w-6 h-6 mx-auto mb-2 ${isUnlocked ? 'text-aether-blue' : 'text-white/40'}`} />
                        <p className={`font-medium ${isUnlocked ? 'text-white' : 'text-white/60'}`}>{t.name}</p>
                        <p className="text-xs text-white/40">{t.req}</p>
                        {isUnlocked && <CheckCircle className="w-4 h-4 text-emerald-400 mx-auto mt-2" />}
                      </div>
                    );
                  })}
                </div>
              </div>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <UserProfileCreator />
                <ProfileDashboard />
              </div>
            </TabsContent>

            {/* Storage Wallet Tab */}
            <TabsContent value="storage-wallet">
              <div className="max-w-2xl mx-auto">
                <StorageCodeWallet />
              </div>
            </TabsContent>

            {/* Swap Tab */}
            <TabsContent value="swap">
              <div className="max-w-2xl mx-auto">
                <DVSwap />
              </div>
            </TabsContent>

            {/* Token Transfer Tab */}
            <TabsContent value="send">
              <div className="max-w-2xl mx-auto">
                <TokenTransfer />
              </div>
            </TabsContent>

            {/* DEX Marketplace Tab */}
            <TabsContent value="dex">
              <div className="max-w-2xl mx-auto">
                <DexMarketplace onClose={() => setActiveTab('overview')} />
              </div>
            </TabsContent>

            {/* Liquidation Pool Tab */}
            <TabsContent value="liquidation">
              <div className="max-w-2xl mx-auto">
                <LiquidationPool />
              </div>
            </TabsContent>

            {/* DV/WETH Pool Tab */}
            <TabsContent value="dv-weth-pool">
              <div className="max-w-2xl mx-auto">
                <DVWethPool />
              </div>
            </TabsContent>

            {/* AI Chat Tab */}
            <TabsContent value="ai-chat" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <AIChat />
                <CustomCoinDeploy />
              </div>
            </TabsContent>

            {/* Content Feed Tab */}
            <TabsContent value="content-feed">
              <div className="max-w-3xl mx-auto">
                <ContentCoinSystem />
              </div>
            </TabsContent>

            {/* Live Streaming Tab */}
            <TabsContent value="live">
              <div className="max-w-4xl mx-auto">
                <LiveStreamWithGifts />
              </div>
            </TabsContent>

            {/* Gift Shop Tab */}
            <TabsContent value="gifts">
              <div className="max-w-4xl mx-auto">
                <GiftShop />
              </div>
            </TabsContent>

            {/* Withdrawal Tab */}
            <TabsContent value="withdraw">
              <div className="max-w-2xl mx-auto">
                <WithdrawalSystem />
              </div>
            </TabsContent>

            {/* Revenue Distribution Tab */}
            <TabsContent value="revenue">
              <div className="max-w-4xl mx-auto">
                <RevenueDistribution />
              </div>
            </TabsContent>

            {/* AI Bot Tab */}
            <TabsContent value="ai-bot">
              <div className="max-w-2xl mx-auto">
                <AIMarketBot />
              </div>
            </TabsContent>

            {/* DV/AIC Pool Tab */}
            <TabsContent value="dv-aic-pool">
              <div className="max-w-3xl mx-auto">
                <DVAICPool />
              </div>
            </TabsContent>

            {/* Staking Tab */}
            <TabsContent value="staking">
              <div className="max-w-3xl mx-auto">
                <StakingCompetition />
              </div>
            </TabsContent>

            {/* Admin Tab */}
            <TabsContent value="admin" className="space-y-6">
              <Tabs defaultValue="dashboard" className="w-full">
                <TabsList className="w-full max-w-md mx-auto mb-6 bg-white/5 border border-white/10">
                  <TabsTrigger value="dashboard" className="data-[state=active]:bg-white/10">
                    <Shield className="w-4 h-4 mr-2" />
                    Dashboard
                  </TabsTrigger>
                  <TabsTrigger value="ai-manager" className="data-[state=active]:bg-white/10">
                    <Brain className="w-4 h-4 mr-2" />
                    AI Manager
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="dashboard" className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <AdminProfile {...DEFAULT_ADMIN} />
                    <div className="max-w-4xl">
                      <AdminDashboard />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="ai-manager">
                  <div className="max-w-4xl mx-auto">
                    <AIAppManager />
                  </div>
                </TabsContent>
              </Tabs>
            </TabsContent>
          </Tabs>
        )}

        {/* Connected but No Market Access (Tier 0) */}
        {isConnected && !hasMarketAccess && (
          <div className="text-center py-16">
            <div className="w-20 h-20 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-6">
              <Lock className="w-10 h-10 text-amber-400" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Hold DV to Access Market</h3>
            <p className="text-white/50 max-w-md mx-auto mb-4">
              You need at least <span className="text-amber-400 font-medium">1 DV</span> (Bronze Tier) 
              to access the crypto market features.
            </p>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 max-w-md mx-auto">
              <p className="text-sm text-white/60 mb-2">Your Current Balance</p>
              <p className="text-2xl font-bold text-white">{formattedBalance} DV</p>
              <p className="text-xs text-white/40 mt-1">Tier: {tierName}</p>
            </div>
          </div>
        )}

        {/* Not Connected State */}
        {!isConnected && (
          <div className="text-center py-16">
            <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-6">
              <Wallet className="w-10 h-10 text-white/30" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Connect Your Wallet</h3>
            <p className="text-white/50 max-w-md mx-auto">
              Connect your MetaMask to access the Aether Web3 Platform 
              powered by Divine Vaughns on Base.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
