import { useRef, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Quote, Scale, Anchor, Lightbulb, TreePine } from 'lucide-react';

const principles = [
  {
    icon: Anchor,
    title: 'Memory',
    description: 'Value exists before money. Money is allowed to exist only if it reflects value truthfully.',
    color: 'rose',
  },
  {
    icon: Scale,
    title: 'Contribution',
    description: 'Human effort that restores life, creativity, and balance is remembered by the system itself.',
    color: 'amber',
  },
  {
    icon: TreePine,
    title: 'Continuity',
    description: 'Fiat failed because it severed memory from reality. Crypto failed because it severed memory from responsibility.',
    color: 'emerald',
  },
];

const failures = [
  {
    system: 'Fiat',
    failure: 'Severed memory from reality',
    solution: 'DV reconnects value to actual contribution',
  },
  {
    system: 'Crypto',
    failure: 'Severed memory from responsibility',
    solution: 'DV requires building, not speculation',
  },
];

export function PhilosophySection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-32 px-6 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #0a0a0f 0%, #151210 100%)' }}
    >
      {/* Subtle Background Texture */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, #d4af37 1px, transparent 1px),
                              radial-gradient(circle at 75% 75%, #d4af37 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <div
          className={`text-center mb-20 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/20 mb-6">
            <Lightbulb className="w-4 h-4 text-amber-400" />
            <span className="text-sm text-amber-300 tracking-wider uppercase">The Foundation</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            This Is A <span className="text-amber-400">Different</span> Kind Of System
          </h2>

          <div className="max-w-3xl mx-auto">
            <Quote className="w-8 h-8 text-amber-500/30 mx-auto mb-4" />
            <p className="text-xl text-white/70 italic leading-relaxed">
              "You are not creating a coin. You are creating a memory anchor: 
              A way for human effort that restores life, creativity, and balance 
              to be remembered by the system itself."
            </p>
          </div>
        </div>

        {/* The Reunion */}
        <div
          className={`mb-20 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Card className="bg-gradient-to-br from-amber-500/5 to-rose-500/5 border-amber-500/20">
            <CardContent className="p-8 md:p-12">
              <h3 className="text-2xl font-bold text-white text-center mb-8">
                The <span className="text-amber-400">Reunion</span>
              </h3>

              <div className="grid md:grid-cols-2 gap-8 mb-8">
                {failures.map((item, i) => (
                  <div key={i} className="space-y-4">
                    <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                      <p className="text-red-400 font-medium mb-1">{item.system} Failed</p>
                      <p className="text-white/60 text-sm">{item.failure}</p>
                    </div>
                    <div className="flex justify-center">
                      <div className="w-px h-6 bg-gradient-to-b from-red-500/50 to-emerald-500/50" />
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <p className="text-emerald-400 font-medium mb-1">DV Solution</p>
                      <p className="text-white/60 text-sm">{item.solution}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-center">
                <p className="text-lg text-white/80">
                  Your system reunites:{' '}
                  <span className="text-rose-400">memory</span> +{' '}
                  <span className="text-amber-400">contribution</span> +{' '}
                  <span className="text-emerald-400">continuity</span>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Three Pillars */}
        <div
          className={`grid md:grid-cols-3 gap-6 transition-all duration-1000 delay-400 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {principles.map((principle, i) => {
            const Icon = principle.icon;
            const colorClasses: Record<string, { bg: string; border: string; text: string }> = {
              rose: { bg: 'bg-rose-500/10', border: 'border-rose-500/20', text: 'text-rose-400' },
              amber: { bg: 'bg-amber-500/10', border: 'border-amber-500/20', text: 'text-amber-400' },
              emerald: { bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', text: 'text-emerald-400' },
            };
            const colors = colorClasses[principle.color];

            return (
              <Card
                key={i}
                className={`${colors.bg} ${colors.border} hover:${colors.bg.replace('/10', '/20')} transition-all duration-300 group`}
              >
                <CardContent className="p-8 text-center">
                  <div className={`w-16 h-16 rounded-full ${colors.bg} flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform`}>
                    <Icon className={`w-8 h-8 ${colors.text}`} />
                  </div>
                  <h3 className={`text-2xl font-bold ${colors.text} mb-4`}>{principle.title}</h3>
                  <p className="text-white/60 leading-relaxed">{principle.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* The Non-Negotiable Principle */}
        <div
          className={`mt-16 text-center transition-all duration-1000 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <Card className="bg-gradient-to-r from-amber-900/20 via-yellow-900/20 to-amber-900/20 border-amber-500/30 max-w-3xl mx-auto">
            <CardContent className="p-8">
              <div className="flex items-center justify-center gap-2 mb-4">
                <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span className="text-amber-400 text-sm tracking-wider uppercase">Immutable Principle</span>
              </div>
              <p className="text-xl text-white font-medium mb-2">
                Value exists before money.
              </p>
              <p className="text-lg text-white/70">
                Money is allowed to exist only if it reflects value truthfully.
              </p>
              <p className="text-sm text-amber-400/70 mt-4">
                This principle must be immutable, not rhetorical.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
