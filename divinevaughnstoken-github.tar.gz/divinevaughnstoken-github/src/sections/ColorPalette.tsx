import { useEffect, useRef, useState } from 'react';
import { Copy, Check } from 'lucide-react';

const colorGroups = [
  {
    name: 'Primary',
    colors: [
      { name: 'Blue 50', hex: '#eff6ff', value: '#eff6ff' },
      { name: 'Blue 100', hex: '#dbeafe', value: '#dbeafe' },
      { name: 'Blue 200', hex: '#bfdbfe', value: '#bfdbfe' },
      { name: 'Blue 300', hex: '#93c5fd', value: '#93c5fd' },
      { name: 'Blue 400', hex: '#60a5fa', value: '#60a5fa' },
      { name: 'Blue 500', hex: '#3b82f6', value: '#3b82f6' },
      { name: 'Blue 600', hex: '#2563eb', value: '#2563eb' },
      { name: 'Blue 700', hex: '#1d4ed8', value: '#1d4ed8' },
      { name: 'Blue 800', hex: '#1e40af', value: '#1e40af' },
      { name: 'Blue 900', hex: '#1e3a8a', value: '#1e3a8a' },
    ],
  },
  {
    name: 'Accent',
    colors: [
      { name: 'Purple 50', hex: '#faf5ff', value: '#faf5ff' },
      { name: 'Purple 100', hex: '#f3e8ff', value: '#f3e8ff' },
      { name: 'Purple 200', hex: '#e9d5ff', value: '#e9d5ff' },
      { name: 'Purple 300', hex: '#d8b4fe', value: '#d8b4fe' },
      { name: 'Purple 400', hex: '#c084fc', value: '#c084fc' },
      { name: 'Purple 500', hex: '#a855f7', value: '#a855f7' },
      { name: 'Purple 600', hex: '#9333ea', value: '#9333ea' },
      { name: 'Purple 700', hex: '#7c3aed', value: '#7c3aed' },
      { name: 'Purple 800', hex: '#6b21a8', value: '#6b21a8' },
      { name: 'Purple 900', hex: '#581c87', value: '#581c87' },
    ],
  },
  {
    name: 'Secondary',
    colors: [
      { name: 'Pink 50', hex: '#fdf2f8', value: '#fdf2f8' },
      { name: 'Pink 100', hex: '#fce7f3', value: '#fce7f3' },
      { name: 'Pink 200', hex: '#fbcfe8', value: '#fbcfe8' },
      { name: 'Pink 300', hex: '#f9a8d4', value: '#f9a8d4' },
      { name: 'Pink 400', hex: '#f472b6', value: '#f472b6' },
      { name: 'Pink 500', hex: '#ec4899', value: '#ec4899' },
      { name: 'Pink 600', hex: '#db2777', value: '#db2777' },
      { name: 'Pink 700', hex: '#be185d', value: '#be185d' },
      { name: 'Pink 800', hex: '#9d174d', value: '#9d174d' },
      { name: 'Pink 900', hex: '#831843', value: '#831843' },
    ],
  },
];

const semanticColors = [
  { name: 'Success', bg: 'bg-emerald-500', text: 'text-emerald-400', hex: '#10b981' },
  { name: 'Warning', bg: 'bg-amber-500', text: 'text-amber-400', hex: '#f59e0b' },
  { name: 'Error', bg: 'bg-red-500', text: 'text-red-400', hex: '#ef4444' },
  { name: 'Info', bg: 'bg-sky-500', text: 'text-sky-400', hex: '#0ea5e9' },
];

const gradients = [
  { name: 'Ocean', from: '#3b82f6', to: '#06b6d4', class: 'from-blue-500 to-cyan-500' },
  { name: 'Sunset', from: '#f97316', to: '#ec4899', class: 'from-orange-500 to-pink-500' },
  { name: 'Aurora', from: '#8b5cf6', to: '#06b6d4', class: 'from-purple-500 to-cyan-500' },
  { name: 'Berry', from: '#ec4899', to: '#8b5cf6', class: 'from-pink-500 to-purple-500' },
];

export function ColorPalette() {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const copyColor = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    setTimeout(() => setCopiedColor(null), 2000);
  };

  return (
    <section
      id="colors"
      ref={sectionRef}
      className="relative w-full py-32 px-6 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-aether-dark via-aether-gray/30 to-aether-dark" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-aether-blue/10 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div
          className={`text-center mb-20 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-sm text-blue-400 mb-6">
            Color System
          </span>
          <h2 className="text-display-sm md:text-display-md font-bold text-white mb-6">
            A palette built for
            <span className="text-gradient"> consistency</span>
          </h2>
          <p className="text-lg text-white/50 max-w-2xl mx-auto">
            Carefully selected colors that work harmoniously together, 
            with full accessibility compliance and dark mode support.
          </p>
        </div>

        {/* Color Groups */}
        <div className="space-y-20">
          {colorGroups.map((group, groupIndex) => (
            <div
              key={group.name}
              className={`transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${(groupIndex + 1) * 150}ms` }}
            >
              <h3 className="text-xl font-semibold text-white mb-6">{group.name} Scale</h3>
              <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                {group.colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => copyColor(color.hex)}
                    className="group relative aspect-square rounded-xl overflow-hidden transition-transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-white/30"
                    style={{ backgroundColor: color.value }}
                    title={`${color.name}: ${color.hex}`}
                  >
                    {/* Copy Overlay */}
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      {copiedColor === color.hex ? (
                        <Check className="w-5 h-5 text-white" />
                      ) : (
                        <Copy className="w-5 h-5 text-white" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}

          {/* Semantic Colors */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '450ms' }}
          >
            <h3 className="text-xl font-semibold text-white mb-6">Semantic Colors</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {semanticColors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => copyColor(color.hex)}
                  className="group relative p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all"
                >
                  <div className={`w-12 h-12 rounded-xl ${color.bg} mb-4`} />
                  <p className="text-white font-medium">{color.name}</p>
                  <p className={`text-sm ${color.text}`}>{color.hex}</p>
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    {copiedColor === color.hex ? (
                      <Check className="w-4 h-4 text-white/60" />
                    ) : (
                      <Copy className="w-4 h-4 text-white/40" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Gradients */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '600ms' }}
          >
            <h3 className="text-xl font-semibold text-white mb-6">Gradient Presets</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {gradients.map((gradient) => (
                <div
                  key={gradient.name}
                  className="group relative rounded-2xl overflow-hidden"
                >
                  <div className={`h-24 bg-gradient-to-r ${gradient.class}`} />
                  <div className="p-4 bg-white/5 border border-white/10 border-t-0 rounded-b-2xl">
                    <p className="text-white font-medium">{gradient.name}</p>
                    <p className="text-sm text-white/40">{gradient.from} → {gradient.to}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
