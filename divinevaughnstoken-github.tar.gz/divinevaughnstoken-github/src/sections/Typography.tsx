import { useEffect, useRef, useState } from 'react';

const typeScale = [
  { name: 'Display XL', size: 'text-[6rem] md:text-[8rem]', lineHeight: 'leading-none', weight: 'font-bold', sample: 'Aa' },
  { name: 'Display LG', size: 'text-[4rem] md:text-[6rem]', lineHeight: 'leading-none', weight: 'font-bold', sample: 'Aa' },
  { name: 'Display MD', size: 'text-[3rem] md:text-[4.5rem]', lineHeight: 'leading-tight', weight: 'font-bold', sample: 'H1 Heading' },
  { name: 'Display SM', size: 'text-[2rem] md:text-[3rem]', lineHeight: 'leading-tight', weight: 'font-semibold', sample: 'H2 Heading' },
  { name: 'Display XS', size: 'text-[1.5rem] md:text-[2rem]', lineHeight: 'leading-snug', weight: 'font-semibold', sample: 'H3 Heading' },
  { name: 'Body Large', size: 'text-lg md:text-xl', lineHeight: 'leading-relaxed', weight: 'font-normal', sample: 'Body text for important paragraphs and descriptions.' },
  { name: 'Body', size: 'text-base', lineHeight: 'leading-relaxed', weight: 'font-normal', sample: 'Standard body text for most content and paragraphs.' },
  { name: 'Body Small', size: 'text-sm', lineHeight: 'leading-relaxed', weight: 'font-normal', sample: 'Smaller text for captions, labels, and secondary info.' },
  { name: 'Caption', size: 'text-xs', lineHeight: 'leading-normal', weight: 'font-medium', sample: 'CAPTIONS & LABELS' },
];

const fontWeights = [
  { weight: 'font-light', name: 'Light', value: '300', sample: 'Inter Light' },
  { weight: 'font-normal', name: 'Regular', value: '400', sample: 'Inter Regular' },
  { weight: 'font-medium', name: 'Medium', value: '500', sample: 'Inter Medium' },
  { weight: 'font-semibold', name: 'Semibold', value: '600', sample: 'Inter Semibold' },
  { weight: 'font-bold', name: 'Bold', value: '700', sample: 'Inter Bold' },
  { weight: 'font-extrabold', name: 'Extrabold', value: '800', sample: 'Inter Extrabold' },
];

const letterSpacing = [
  { name: 'Tighter', value: 'tracking-tighter', sample: 'Aether Design' },
  { name: 'Tight', value: 'tracking-tight', sample: 'Aether Design' },
  { name: 'Normal', value: 'tracking-normal', sample: 'Aether Design' },
  { name: 'Wide', value: 'tracking-wide', sample: 'Aether Design' },
  { name: 'Wider', value: 'tracking-wider', sample: 'Aether Design' },
];

export function Typography() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeTab, setActiveTab] = useState<'scale' | 'weights' | 'spacing'>('scale');
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="typography"
      ref={sectionRef}
      className="relative w-full py-32 px-6 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-aether-dark via-purple-500/5 to-aether-dark" />
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-aether-purple/10 rounded-full blur-[150px] -translate-y-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-sm text-purple-400 mb-6">
            Typography
          </span>
          <h2 className="text-display-sm md:text-display-md font-bold text-white mb-6">
            Type that speaks
            <span className="text-gradient"> volumes</span>
          </h2>
          <p className="text-lg text-white/50 max-w-2xl mx-auto">
            Inter font family with a carefully crafted type scale for optimal 
            readability and visual hierarchy across all screen sizes.
          </p>
        </div>

        {/* Font Showcase */}
        <div
          className={`mb-20 transition-all duration-700 delay-150 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="p-8 md:p-16 rounded-3xl bg-white/[0.02] border border-white/10">
            <p className="text-sm text-white/40 mb-4 tracking-widest uppercase">Inter Font Family</p>
            <p className="text-[4rem] md:text-[8rem] font-bold text-white leading-none tracking-tighter">
              Aa
            </p>
            <div className="mt-8 flex flex-wrap gap-8 text-white/60">
              <div>
                <p className="text-sm text-white/40">Font Family</p>
                <p className="font-medium">Inter</p>
              </div>
              <div>
                <p className="text-sm text-white/40">Weights</p>
                <p className="font-medium">300 - 900</p>
              </div>
              <div>
                <p className="text-sm text-white/40">Styles</p>
                <p className="font-medium">Normal, Italic</p>
              </div>
              <div>
                <p className="text-sm text-white/40">Designed by</p>
                <p className="font-medium">Rasmus Andersson</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div
          className={`flex justify-center gap-2 mb-12 transition-all duration-700 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {(['scale', 'weights', 'spacing'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 rounded-xl text-sm font-medium capitalize transition-all ${
                activeTab === tab
                  ? 'bg-white/10 text-white'
                  : 'text-white/50 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div
          className={`transition-all duration-700 delay-450 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {activeTab === 'scale' && (
            <div className="space-y-8">
              {typeScale.map((item) => (
                <div
                  key={item.name}
                  className="flex flex-col md:flex-row md:items-center gap-4 md:gap-8 p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-colors"
                >
                  <div className="w-32 shrink-0">
                    <p className="text-sm text-white/40">{item.name}</p>
                  </div>
                  <div className={`${item.size} ${item.lineHeight} ${item.weight} text-white`}>
                    {item.sample}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'weights' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {fontWeights.map((item) => (
                <div
                  key={item.name}
                  className="p-8 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-colors"
                >
                  <p className="text-sm text-white/40 mb-2">{item.name} ({item.value})</p>
                  <p className={`text-3xl ${item.weight} text-white`}>{item.sample}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'spacing' && (
            <div className="space-y-6">
              {letterSpacing.map((item) => (
                <div
                  key={item.name}
                  className="flex flex-col md:flex-row md:items-center gap-4 md:gap-8 p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-colors"
                >
                  <div className="w-32 shrink-0">
                    <p className="text-sm text-white/40">{item.name}</p>
                  </div>
                  <div className={`text-2xl font-semibold text-white ${item.value}`}>
                    {item.sample}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Font Pairing Example */}
        <div
          className={`mt-20 p-8 md:p-12 rounded-3xl bg-gradient-to-br from-purple-500/10 to-transparent border border-purple-500/20 transition-all duration-700 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <p className="text-sm text-purple-400 mb-8 tracking-widest uppercase">Live Preview</p>
          <h3 className="text-3xl md:text-5xl font-bold text-white mb-4 leading-tight">
            Design is not just what it looks like
          </h3>
          <p className="text-lg md:text-xl text-white/60 leading-relaxed max-w-3xl">
            Design is how it works. Great typography establishes hierarchy, 
            creates rhythm, and guides users through your content with ease.
          </p>
          <div className="mt-8 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-aether-blue to-aether-purple" />
            <div>
              <p className="text-white font-medium">Steve Jobs</p>
              <p className="text-sm text-white/40">Co-founder, Apple Inc.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
