import { createConfig, http } from 'wagmi';
import { base, mainnet } from 'wagmi/chains';
import { 
  injected, 
  walletConnect, 
  coinbaseWallet
} from 'wagmi/connectors';

// ============================================
// DIVINE VAUGHNS PLATFORM CONFIGURATION
// ============================================

// Domain Configuration
export const PLATFORM_DOMAIN = 'divinevaughnstoken.net';
export const PLATFORM_URL = `https://${PLATFORM_DOMAIN}`;

// Logo Assets
export const DV_LOGO_URL = '/logos/dv-logo.png';
export const AIC_LOGO_URL = '/logos/aic-logo.png';
export const STDV_LOGO_URL = '/logos/stdv-logo.png';
export const STDV3_LOGO_URL = '/logos/stdv3-logo.png';

// Token Contracts (Base Chain)
export const DV_TOKEN_ADDRESS = '0x804Ed08fd4f33570DF8d1b69E4FC2da12f14f8B6';
export const AIC_TOKEN_ADDRESS = '0x3B62b6b3958C128574b3dAd6cC94d41432617B60'; // Updated

// DV/AIC Uniswap V3 Pool (Base)
export const DV_AIC_POOL_ADDRESS = '0xd183852247134036b07f5E1190977b291AaD6355';
export const DV_AIC_POOL_FEE = 3000; // 0.3%

// DV/WETH Uniswap V3 Pool (Base)
export const DV_WETH_POOL_ADDRESS = '0xfb7188595FB6F627E3e4E54F7ECB3F7E3F3f9a29';
export const DV_WETH_POOL_FEE = 3000; // 0.3%

// DVAIEngine - AI message processing with dynamic pricing
export const DV_AI_ENGINE_ADDRESS = '0x00a02f49fFAeF61F94Daf9b0Bd50307392b4Ed2b';

// DVStakingVault - Staking with AIC rewards (30-day lock, 90-day stDV3 rewards)
export const DV_STAKING_VAULT_ADDRESS = '0x2cE5f8dbE858Df390A06EdA02a7B379818607546';

// StDV Token - Staked DV (non-transferable)
export const STDV_TOKEN_ADDRESS = '0x55adc6f25a41a7Da59eA410d914340e96f602f1d';

// StDV3 Token - 90-day staking reward token (non-transferable)
export const STDV3_TOKEN_ADDRESS = '0xd801Ca5972a3EdD3911282B7aD1A22EC88b00413';

// DVTreasuryV3 - Buyback contract (swaps AIC for DV)
export const DV_TREASURY_V3_ADDRESS = '0x...'; // To be deployed

// DVTierGate Contract (Base)
export const DV_TIER_GATE_ADDRESS = '0x44e6C229e054381eC831B483AB0475F3C062DB01';

// DVControlledRouterV3 Contract (Base)
export const DV_ROUTER_ADDRESS = '0x463C776637632c7A1Bd8A89e11761625B1A9a17E';

// Treasury address (receives 0.30% swap fees)
export const DV_TREASURY_ADDRESS = '0xBDc4DC1f855371F29F0449b206620BD0BD24aC0C';

// AI Revenue Pool - DV/AIC paired for cloud revenue
export const AI_REVENUE_POOL_ADDRESS = '0x...'; // To be deployed

// Uniswap V3 Router on Base
export const UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';

// DV Router ABI
export const DV_ROUTER_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "_dv", "type": "address" },
      { "internalType": "address", "name": "_router", "type": "address" },
      { "internalType": "address", "name": "_treasury", "type": "address" }
    ],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "DV",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "FEE_BPS",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "router",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "treasury",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "tokenIn", "type": "address" },
      { "internalType": "address", "name": "tokenOut", "type": "address" },
      { "internalType": "uint24", "name": "poolFee", "type": "uint24" },
      { "internalType": "uint256", "name": "amountIn", "type": "uint256" },
      { "internalType": "uint256", "name": "amountOutMinimum", "type": "uint256" }
    ],
    "name": "swapDVPair",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "user", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "feeAmount", "type": "uint256" }
    ],
    "name": "SwapExecuted",
    "type": "event"
  }
] as const;

// AIC Token ABI (ERC20 with burn)
export const AIC_TOKEN_ABI = [
  {
    "inputs": [{ "internalType": "uint256", "name": "initialSupply", "type": "uint256" }],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "decimals",
    "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "recipient", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "transfer",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "spender", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "approve",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "owner", "type": "address" },
      { "internalType": "address", "name": "spender", "type": "address" }
    ],
    "name": "allowance",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "from", "type": "address" },
      { "internalType": "address", "name": "to", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "transferFrom",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }],
    "name": "burn",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "from", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "to", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }
    ],
    "name": "Transfer",
    "type": "event"
  }
] as const;

// AIC Burn Engine ABI
export const AIC_BURN_ENGINE_ABI = [
  {
    "inputs": [{ "internalType": "address", "name": "_aic", "type": "address" }],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "AIC",
    "outputs": [{ "internalType": "contract IERC20Burn", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "COST_PER_ACTION",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "useAI",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "user", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "burned", "type": "uint256" }
    ],
    "name": "AIUsed",
    "type": "event"
  }
] as const;

// DVAIEngine ABI - AI message processing with dynamic pricing
export const DV_AI_ENGINE_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "_aic", "type": "address" },
      { "internalType": "address", "name": "_dv", "type": "address" },
      { "internalType": "address", "name": "_stakingVault", "type": "address" },
      { "internalType": "address", "name": "_treasury", "type": "address" }
    ],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "AIC",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "DV",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "dvPriceUsd",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "usdTarget",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "stakingVault",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "treasury",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "price", "type": "uint256" }],
    "name": "updateDVPrice",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "processMessage",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;

// DVStakingVault ABI - Staking with AIC rewards and stDV3 90-day rewards
export const DV_STAKING_VAULT_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "_dv", "type": "address" },
      { "internalType": "address", "name": "_aic", "type": "address" },
      { "internalType": "address", "name": "_treasury", "type": "address" },
      { "internalType": "address", "name": "_stDV", "type": "address" },
      { "internalType": "address", "name": "_stDV3", "type": "address" }
    ],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "DV",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "AIC",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "treasury",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "stDV",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "stDV3",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "LOCK_PERIOD",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "REWARD_CYCLE",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "EARLY_PENALTY",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "name": "users",
    "outputs": [
      { "internalType": "uint256", "name": "staked", "type": "uint256" },
      { "internalType": "uint256", "name": "depositTime", "type": "uint256" },
      { "internalType": "uint256", "name": "lastClaimTime", "type": "uint256" }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }],
    "name": "stake",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }],
    "name": "unstake",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "claim3MonthReward",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "user", "type": "address" }],
    "name": "canClaimReward",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "user", "type": "address" }],
    "name": "calculateReward",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "user", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "stDV3Amount", "type": "uint256" }
    ],
    "name": "RewardClaimed",
    "type": "event"
  }
] as const;

// DVTreasuryV3 ABI - Buyback contract
export const DV_TREASURY_V3_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "_aic", "type": "address" },
      { "internalType": "address", "name": "_dv", "type": "address" }
    ],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "AIC",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "DV",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "poolFee",
    "outputs": [{ "internalType": "uint24", "name": "", "type": "uint24" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "buyThreshold",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "slippageBps",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "expectedOut", "type": "uint256" }],
    "name": "executeBuyback",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;

// StDV Token ABI - Staked DV (non-transferable)
export const STDV_TOKEN_ABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "decimals",
    "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "vault",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "_vault", "type": "address" }],
    "name": "setVault",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "to", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "mint",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "from", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "burn",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;

// StDV3 Token ABI - 90-day staking reward token (non-transferable)
export const STDV3_TOKEN_ABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "decimals",
    "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "vault",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "_vault", "type": "address" }],
    "name": "setVault",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "to", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "mint",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "from", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "burn",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;

// DV Tier Gate ABI
export const DV_TIER_GATE_ABI = [
  {
    "inputs": [{ "internalType": "address", "name": "_dv", "type": "address" }],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "DV",
    "outputs": [{ "internalType": "contract IERC20", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "user", "type": "address" }],
    "name": "getTier",
    "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  }
] as const;

// DV Token ABI (ERC20 standard)
export const DV_TOKEN_ABI = [
  {
    "inputs": [],
    "name": "name",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "decimals",
    "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "recipient", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "transfer",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "spender", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "approve",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "owner", "type": "address" },
      { "internalType": "address", "name": "spender", "type": "address" }
    ],
    "name": "allowance",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "from", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "to", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }
    ],
    "name": "Transfer",
    "type": "event"
  }
] as const;

// Common token addresses on Base
export const TOKENS = {
  DV: '0x804Ed08fd4f33570DF8d1b69E4FC2da12f14f8B6',
  WETH: '0x4200000000000000000000000000000000000006',
  USDC: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
  USDbC: '0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA',
  cbETH: '0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22',
} as const;

// Uniswap V3 Pool Fees
export const POOL_FEES = {
  LOWEST: 100,    // 0.01%
  LOW: 500,       // 0.05%
  MEDIUM: 3000,   // 0.3%
  HIGH: 10000,    // 1%
} as const;

// Tier definitions based on DVTierGate contract
export const TIERS = {
  0: { name: 'No Tier', minBalance: 0n, color: 'gray' },
  1: { name: 'Bronze', minBalance: 1n * 10n ** 18n, color: 'amber' },
  2: { name: 'Silver', minBalance: 100n * 10n ** 18n, color: 'slate' },
  3: { name: 'Gold', minBalance: 1000n * 10n ** 18n, color: 'yellow' },
  4: { name: 'Platinum', minBalance: 10000n * 10n ** 18n, color: 'cyan' },
} as const;

// Constants
export const CONSTANTS = {
  // Profile requirement (Tier 2 = 100 DV)
  MIN_DV_FOR_PROFILE: 100n * 10n ** 18n,
  
  // Bot access pricing (Tier 3 = 1,000 DV)
  BOT_ACCESS_TIER: 3,
  BOT_ACCESS_DV_AMOUNT: 1000n * 10n ** 18n,
  BOT_ACCESS_DURATION: 2 * 60 * 60, // 2 hours in seconds
  BOT_COOLDOWN_PERIOD: 4 * 60 * 60, // 4 hours in seconds
  
  // Storage wallet cost
  STORAGE_WALLET_COST: 500n * 10n ** 18n, // 500 DV
  
  // Swap fee (from DVControlledRouterV3)
  SWAP_FEE_BPS: 30, // 0.30%
  
  // Staking periods (in seconds)
  STAKING_PERIODS: {
    THREE_MONTHS: 90 * 24 * 60 * 60,
    SIX_MONTHS: 180 * 24 * 60 * 60,
    ONE_YEAR: 365 * 24 * 60 * 60,
  },
  
  // Reward rates (APR in basis points) - CONSERVATIVE TO PREVENT INFLATION
  REWARD_RATES: {
    THREE_MONTHS: 250, // 2.5% per 90 days = ~10% APY
    SIX_MONTHS: 500, // 5% per 180 days = ~10% APY
    ONE_YEAR: 1000, // 10% per year
  },
  
  // StDV3 Economic Safeguards - CRITICAL: Prevents runaway inflation
  STDV3_ECONOMICS: {
    // Supply cap: Maximum stDV3 that can ever exist
    MAX_SUPPLY: 10000000n * 10n ** 18n, // 10 million stDV3 hard cap
    
    // Reward rate: 2.5% per 90-day cycle (was 100% - dangerously inflationary!)
    // 100k DV staked → 2,500 stDV3 per cycle → 10,000 per year (10% APY)
    REWARD_RATE_BPS: 250, // 2.5% per cycle
    
    // Halving schedule: Rewards halve every 4 cycles (1 year)
    HALVING_CYCLES: 4,
    
    // Minimum stake to earn rewards (prevents dust spam)
    MIN_STAKE_FOR_REWARDS: 100n * 10n ** 18n, // 100 DV minimum
    
    // Emission control: Maximum rewards per cycle
    MAX_EMISSION_PER_CYCLE: 100000n * 10n ** 18n, // 100k stDV3 per cycle
    
    // Governance-controlled: Can be adjusted by DAO vote
    GOVERNANCE_CAN_ADJUST: true,
    MAX_ADJUSTMENT_BPS: 500, // Max 5% per cycle via governance
  },
  
  // USD target price
  TARGET_USD_PRICE: 1, // $1 USD
  DV_PRICE_USD: 0.001, // $0.001 per DV
  
  // AIC (AI Catalyst) Token
  AIC_INITIAL_SUPPLY: 1000000, // 1,000,000 AIC
  AIC_DECIMALS: 18,
  
  // AI Usage Cost (per message)
  AI_COST_PER_MESSAGE: 1n * 10n ** 15n, // 0.001 AIC (1e15 wei)
  
  // DV/AIC Pool Ratio for revenue sharing
  DV_AIC_POOL_RATIO: 1000, // 1000 DV = 1 AIC
};

// Wagmi Config for Base - Multi-wallet support
export const wagmiConfig = createConfig({
  chains: [base, mainnet],
  connectors: [
    // Injected wallets (MetaMask, Rabby, Brave, etc.)
    injected(),
    
    // WalletConnect - supports 100+ wallets (Rainbow, Trust, OKX, etc.)
    walletConnect({
      projectId: 'dv_ecosystem_2024',
      metadata: {
        name: 'Divine Vaughns',
        description: 'DV Coin Ecosystem Platform',
        url: 'https://divinevaughnstoken.net',
        icons: ['https://divinevaughnstoken.net/logos/dv-logo.png'],
      },
      showQrModal: true,
    }),
    
    // Coinbase Wallet
    coinbaseWallet({
      appName: 'Divine Vaughns',
      appLogoUrl: 'https://divinevaughnstoken.net/logos/dv-logo.png',
    }),
  ],
  transports: {
    [base.id]: http('https://mainnet.base.org'),
    [mainnet.id]: http('https://eth-mainnet.g.alchemy.com/v2/demo'),
  },
});

// Helper functions
export function formatDVAmount(amount: bigint): string {
  const divisor = 10n ** 18n;
  const whole = amount / divisor;
  const fraction = amount % divisor;
  const fractionStr = fraction.toString().padStart(18, '0').slice(0, 4);
  return `${whole}.${fractionStr}`;
}

export function formatTokenAmount(amount: bigint, decimals: number = 18): string {
  const divisor = 10n ** BigInt(decimals);
  const whole = amount / divisor;
  const fraction = amount % divisor;
  const fractionStr = fraction.toString().padStart(decimals, '0').slice(0, 4);
  return `${whole}.${fractionStr}`;
}

export function parseDVAmount(amount: string): bigint {
  const [whole, fraction = ''] = amount.split('.');
  const fractionPadded = fraction.padEnd(18, '0').slice(0, 18);
  return BigInt(whole) * 10n ** 18n + BigInt(fractionPadded);
}

export function calculateStakingRewards(
  amount: bigint,
  lockPeriod: number,
  rewardRate: number
): bigint {
  const timeInYears = BigInt(lockPeriod) / BigInt(365 * 24 * 60 * 60);
  return (amount * BigInt(rewardRate) * timeInYears) / 10000n;
}

// Calculate stDV3 rewards with economic safeguards
export function calculateStDV3Reward(
  stakedAmount: bigint,
  cycleCount: number // Number of 90-day cycles completed
): { reward: bigint; halvingApplied: number; warning?: string } {
  const { STDV3_ECONOMICS } = CONSTANTS;
  
  // Check minimum stake requirement
  if (stakedAmount < STDV3_ECONOMICS.MIN_STAKE_FOR_REWARDS) {
    return { 
      reward: 0n, 
      halvingApplied: 0,
      warning: `Minimum ${formatDVAmount(STDV3_ECONOMICS.MIN_STAKE_FOR_REWARDS)} DV required for rewards`
    };
  }
  
  // Calculate halving (halves every 4 cycles)
  const halvings = Math.floor(cycleCount / STDV3_ECONOMICS.HALVING_CYCLES);
  const halvingMultiplier = Math.max(1, Math.pow(2, halvings));
  
  // Base reward: 2.5% per cycle
  let reward = (stakedAmount * BigInt(STDV3_ECONOMICS.REWARD_RATE_BPS)) / 10000n;
  
  // Apply halving
  reward = reward / BigInt(halvingMultiplier);
  
  // Check max emission per cycle
  if (reward > STDV3_ECONOMICS.MAX_EMISSION_PER_CYCLE) {
    reward = STDV3_ECONOMICS.MAX_EMISSION_PER_CYCLE;
  }
  
  return { 
    reward, 
    halvingApplied: halvings,
    warning: halvings > 0 ? `Reward halved ${halvings} time(s)` : undefined
  };
}

// Calculate total potential stDV3 supply (for monitoring inflation)
export function calculateMaxStDV3Supply(
  totalStakedDV: bigint,
  cycles: number
): bigint {
  const { STDV3_ECONOMICS } = CONSTANTS;
  let totalSupply = 0n;
  let currentStaked = totalStakedDV;
  
  for (let i = 0; i < cycles; i++) {
    const halvings = Math.floor(i / STDV3_ECONOMICS.HALVING_CYCLES);
    const multiplier = Math.max(1, Math.pow(2, halvings));
    const cycleReward = (currentStaked * BigInt(STDV3_ECONOMICS.REWARD_RATE_BPS)) / 10000n / BigInt(multiplier);
    totalSupply += cycleReward;
    currentStaked += cycleReward; // Compound if rewards are restaked
  }
  
  return totalSupply > STDV3_ECONOMICS.MAX_SUPPLY ? STDV3_ECONOMICS.MAX_SUPPLY : totalSupply;
}

export function calculateSwapFee(amountIn: bigint): bigint {
  return (amountIn * BigInt(CONSTANTS.SWAP_FEE_BPS)) / 10000n;
}

export function getTierName(tier: number): string {
  return TIERS[tier as keyof typeof TIERS]?.name || 'Unknown';
}

export function getTierColor(tier: number): string {
  return TIERS[tier as keyof typeof TIERS]?.color || 'gray';
}

// Dynamic pricing hook for DV market value
export function useDynamicPricing() {
  // In production, this would fetch from a DEX or price oracle
  // For now, we use the target price with simulated fluctuations
  const basePrice = CONSTANTS.DV_PRICE_USD;
  
  // Simulate price fluctuation based on time (±10% variance)
  const now = Date.now();
  const variance = Math.sin(now / 3600000) * 0.1; // Hourly fluctuation
  const dvPriceUSD = basePrice * (1 + variance);
  
  // Simulate 24h price change (-5% to +15%)
  const priceChange24h = (Math.sin(now / 86400000) * 10) + 5;
  
  // Calculate DV amount needed for target USD value
  const calculateDVForUSD = (usdAmount: number): bigint => {
    const dvAmount = Math.ceil(usdAmount / dvPriceUSD);
    return BigInt(dvAmount) * 10n ** 18n;
  };
  
  // Calculate USD value of DV amount
  const calculateUSDForDV = (dvAmount: bigint): number => {
    const dvWhole = Number(dvAmount) / 10 ** 18;
    return dvWhole * dvPriceUSD;
  };
  
  return {
    dvPriceUSD,
    priceChange24h,
    isLoading: false,
    calculateDVForUSD,
    calculateUSDForDV,
  };
}
