# Changelog

All notable changes to Divine Vaughns Token will be documented in this file.

## [1.0.0] - 2025-02-21

### Added
- Initial release of Divine Vaughns Token platform
- Multi-wallet connection support (MetaMask, WalletConnect, Coinbase)
- DV Swap with 0.3% fee
- DEX Marketplace (100 DV + 200 AIC access)
- Token Transfer with dynamic fees (0.05% - 0.5%)
- Staking system with 30-day lock
- stDV and stDV3 reward tokens
- Gift Shop with 10+ gift types
- Live Streaming (0.5 DV/min earnings)
- Withdrawal system (Fiat + Crypto)
- Revenue Distribution (100% to DV/WETH pool)
- PWA support for mobile installation
- Netlify deployment configuration

### Smart Contracts
- DV Token: 0x804Ed08fd4f33570DF8d1b69E4FC2da12f14f8B6
- AIC Token: 0x3B62b6b3958C128574b3dAd6cC94d41432617B60
- DV Tier Gate: 0x44e6C229e054381eC831B483AB0475F3C062DB01
- DV Router: 0x463C776637632c7A1Bd8A89e11761625B1A9a17E
- DV/AIC Pool: 0xd183852247134036b07f5E1190977b291AaD6355
- DV/WETH Pool: 0xfb7188595FB6F627E3e4E54F7ECB3F7E3F3f9a29
- DV AI Engine: 0x00a02f49fFAeF61F94Daf9b0Bd50307392b4Ed2b
- DV Staking Vault: 0x2cE5f8dbE858Df390A06EdA02a7B379818607546
- StDV Token: 0x55adc6f25a41a7Da59eA410d914340e96f602f1d
- StDV3 Token: 0xd801Ca5972a3EdD3911282B7aD1A22EC88b00413
- Treasury: 0xBDc4DC1f855371F29F0449b206620BD0BD24aC0C

### Technical
- React + TypeScript + Vite
- Tailwind CSS + shadcn/ui
- Wagmi/Viem for Web3
- Ethers.js for transactions
- IndexedDB for local storage

## [Unreleased]

### Planned
- Native mobile apps (iOS/Android)
- Enhanced AI features
- Additional token pairs
- Governance system
- Cross-chain bridges
