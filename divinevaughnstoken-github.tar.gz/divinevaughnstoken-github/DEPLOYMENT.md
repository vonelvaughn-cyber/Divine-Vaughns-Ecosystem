# Deployment Guide

## Deploy to Netlify (Recommended)

### Option 1: GitHub Integration (Auto-Deploy)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Click "Add new site" → "Import an existing project"
   - Select GitHub and authorize
   - Choose your `divinevaughnstoken` repository
   - Build settings:
     - Build command: `npm run build`
     - Publish directory: `dist`
   - Click "Deploy site"

3. **Add Custom Domain**
   - Go to Site settings → Domain management
   - Click "Add custom domain"
   - Enter: `divinevaughnstoken.net`
   - Netlify will provide DNS records

4. **Update DNS (Porkbun)**
   - Log in to Porkbun
   - Go to DNS for divinevaughnstoken.net
   - Add the A records provided by Netlify
   - Wait 5-10 minutes for propagation

5. **Enable HTTPS**
   - In Netlify: Domain settings → HTTPS
   - Verify DNS configuration
   - Enable "Force HTTPS"

### Option 2: Manual Deploy (Drag & Drop)

1. **Build the app**
   ```bash
   npm run build
   ```

2. **Deploy**
   - Go to [netlify.com](https://netlify.com)
   - Click "Add new site" → "Deploy manually"
   - Drag the `dist` folder to upload
   - Site is live instantly!

3. **Add custom domain** (same as Option 1)

## Environment Variables

Create a `.env` file for local development:

```env
VITE_STORAGE_KEY=your-secure-key
VITE_WALLETCONNECT_PROJECT_ID=your-project-id
```

For production, set these in Netlify:
- Site settings → Environment variables

## GitHub Actions Auto-Deploy

The repository includes a GitHub Actions workflow (`.github/workflows/deploy.yml`) that automatically deploys to Netlify on every push to main.

**Required secrets:**
- `NETLIFY_AUTH_TOKEN`: Your Netlify personal access token
- `NETLIFY_SITE_ID`: Your Netlify site ID

## Troubleshooting

### Build fails
- Check Node.js version (requires 18+)
- Run `npm ci` to clean install dependencies

### DNS not working
- Verify DNS records in Porkbun
- Wait 5-10 minutes for propagation
- Check with `dig divinevaughnstoken.net`

### HTTPS not working
- Ensure DNS is configured correctly
- Wait for Netlify to provision certificate (can take a few minutes)

## Support

- Email: vonelvaughn@gmail.com
- GitHub Issues: [Create an issue](https://github.com/vonelvaughn-cyber/divinevaughnstoken/issues)
